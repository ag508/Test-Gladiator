package pages;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.ProductPageLocator;
import utils.ExcelHandler;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

/**
 * Actions for the Product Cart page.
 * @author Yash
 */
public class ProductCartPageAction {
	public WebDriver driver;
	public WebDriverHelper helper;
	public ProductPageLocator productLocators;
	public Screenshot screenshot;
	public HighLightActionUtil highlight;

	public ProductCartPageAction(WebDriver driver) {
		this.driver = driver;
		helper = new WebDriverHelper(driver);
		productLocators = new ProductPageLocator();
		highlight = new HighLightActionUtil(driver);
		screenshot = new Screenshot(driver);
	}

	/** Verifies the product price and clicks the 'Add to Cart' button. */
	public void verifyPriceAndAddToCart(ExtentTest test) {
		try {
			String expectedPriceKeyword = ExcelHandler.readData(0, 2, 10);
			Assert.assertTrue(driver.findElement(productLocators.productPrice).getText().contains(expectedPriceKeyword),
					"Product price verification failed. Expected to contain: " + expectedPriceKeyword);
			LoggerHandler.info("Verified product price contains expected keyword: " + expectedPriceKeyword);
			test.log(Status.PASS, "Verified product price.");

			helper.waitForElementVisible(productLocators.addToCartButton);
			LoggerHandler.info("Add to cart button is visible.");
			test.log(Status.INFO, "Add to cart button is visible.");

			helper.clickOn(productLocators.addToCartButton);
			LoggerHandler.info("Clicked on add to cart.");
			test.log(Status.PASS,"Clicked on add to cart.");
			
		} catch (Exception e) {
			LoggerHandler.error("Failed to verify price and add to cart: " + e.getMessage());
			test.log(Status.FAIL, "Failed to verify price and add to cart: " + e.getMessage());
			Reporter.attachScreenshotToReport(Reporter.captureScreenShot("AddToCart_Fail"), test, "Failed to add to cart");
		}
	}
}