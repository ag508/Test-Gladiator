package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.LocateStorePageLocators;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

/**
 * Actions for the Locate Store page.
 * @author Ashwani
 */
public class LocateStorePageActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public LocateStorePageLocators locators;
    public HighLightActionUtil highlight;

    public LocateStorePageActions(WebDriver driver){
        this.driver = driver;
        helper = new WebDriverHelper(driver);
        locators = new LocateStorePageLocators();
        highlight = new HighLightActionUtil(driver);
    }

    /** Selects a state from the state dropdown on the Locate Store page. */
    public void selectStateFromDropdown(ExtentTest test, String state){
        try {
            helper.waitForElementVisible(locators.advancedSearchSection);
            helper.clickOn(locators.advancedSearchSection);
            helper.waitForElementVisible(locators.stateDropdown);
            helper.selectFromDropdown(locators.stateDropdown, state);
            LoggerHandler.info("Selected " + state + " from state dropdown.");
            test.pass("Selected " + state);
        } catch (Exception e) {
            LoggerHandler.error("Failed to select state from dropdown: " + e.getMessage());
            test.log(Status.FAIL, "Failed to select state from dropdown: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("SelectState_Fail"), test, "Failed to select state");
        }
    }

    /** Selects a city from the city dropdown on the Locate Store page. */
    public void selectCityFromDropdown(ExtentTest test, String city){
        try {
            helper.waitForElementVisible(locators.cityDropdown);
            helper.selectFromDropdown(locators.cityDropdown, city);
            helper.clickOn(locators.searchButton);
            LoggerHandler.info("Selected " + city + " from city dropdown.");
            test.pass("Selected " + city);
        } catch (Exception e) {
            LoggerHandler.error("Failed to select city from dropdown: " + e.getMessage());
            test.log(Status.FAIL, "Failed to select city from dropdown: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("SelectCity_Fail"), test, "Failed to select city");
        }
    }

    /** Verifies if the current URL contains the store locator keyword. */
    public void verifyUrlContainsStoreLocator(ExtentTest test, String storeLocatorKeyword){
        try {
            helper.verifyLinkText(storeLocatorKeyword);
            LoggerHandler.info("Verified URL contains store locator.");
            test.pass("Verified URL contains store locator");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify URL contains store locator: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify URL contains store locator: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyStoreLocatorURL_Fail"), test, "Failed to verify URL contains store locator");
        }
    }

    /** Clicks the search button and switches to the parent window. */
    public void clickSearchButtonAndSwitchToParentWindow(ExtentTest test){
        try {
            highlight.highlightElement(locators.searchButton);
            LoggerHandler.info("Highlighted search button.");
            test.log(Status.INFO, "Highlighted search button.");
            
            helper.clickOn(locators.searchButton);
            LoggerHandler.info("Search button clicked.");
            test.pass("Search button clicked");
            
            helper.switchToParentWindow();
            LoggerHandler.info("Switched to parent window.");
            test.log(Status.INFO, "Switched to parent window.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click search button and switch window: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click search button and switch window: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickSearchButton_Fail"), test, "Failed to click search button");
        }
    }
}
