package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.RingBuyerLocator;
import uistore.ShoppingCart;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

/**
 * Actions for the Shopping Cart Page.
 * @author Aneesh
 */
public class ShoppingCartActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public HighLightActionUtil highlighter;
    public Reporter reporter;
    public RingBuyerLocator ringLoc;
    public Screenshot screenshot;
    public ExtentTest test;

    /** Constructor for ShoppingCartActions. */
    public ShoppingCartActions(WebDriver driver, ExtentTest test){
        this.driver= driver;
        this.test = test;
        helper =new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
        ringLoc=new RingBuyerLocator();
        reporter = new Reporter();
    }

    /** Verifies the text of the first product in the cart and proceeds to pay. */
    public void verifyFirstProductTextAndProceed(ExtentTest test, String cartProductText){
        try {
            helper.verifyLocatorText(ShoppingCart.firstProductInCart, cartProductText);
            highlighter.highlightElement(ShoppingCart.firstProductInCart);
            LoggerHandler.info("Highlighted Cart Item element.");
            test.pass("Highlighted Cart Item element");

            test.info("Screenshot of Cart");
            String path = Reporter.captureScreenShot("Cart");
            Reporter.attachScreenshotToReport(path, test, "Add to cart button clicked");
            highlighter.unhighlightElement(ShoppingCart.firstProductInCart);
            helper.clickOn(ringLoc.proceedToPayButton);
            test.pass("Proceed to pay button clicked");
            LoggerHandler.info("Clicked on proceed to pay.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify first product text and proceed: " + e.getMessage());
            String path = Reporter.captureScreenShot("FirstProductTextVerificationFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to verify first product text and proceed");
            test.fail("Failed to verify first product text and proceed");
        }
    }

    /** Verifies the text of the first product in the cart (alternative verification). */
    public void verifyFirstProductTextAlternative(ExtentTest test, String cartProductText){
        try {
            helper.verifyLocatorText(ShoppingCart.firstProductInCart, cartProductText);
            highlighter.highlightElement(ShoppingCart.firstProductInCart);
            LoggerHandler.info("Highlighted Cart Item element.");
            test.pass("Highlighted Cart Item element");

            String screenshotPath = Reporter.captureScreenShot("Cart");
            Reporter.attachScreenshotToReport(screenshotPath, test, "Cart Screenshot");
            LoggerHandler.info("Captured cart screenshot.");
            test.pass("Captured cart screenshot.");
            highlighter.unhighlightElement(ShoppingCart.firstProductInCart);
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify first product text (alternative): " + e.getMessage());
            String path = Reporter.captureScreenShot("FirstProductTextAlternativeVerificationFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to verify first product text (alternative)");
            test.fail("Failed to verify first product text (alternative)");
        }
    }
}
