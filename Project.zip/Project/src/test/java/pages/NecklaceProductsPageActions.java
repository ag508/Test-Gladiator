package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.NecklaceProductsPageLocators;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

/**
 * Actions for the Necklace Products page.
 * @author Dhruv
 */
public class NecklaceProductsPageActions {

    public WebDriver driver;
    public WebDriverHelper helper;

    public NecklaceProductsPageLocators neckLoc;
    public Screenshot screenshot;

    public NecklaceProductsPageActions(WebDriver driver){
        this.driver = driver;
        helper = new WebDriverHelper(driver);
        neckLoc = new NecklaceProductsPageLocators();
        screenshot = new Screenshot(driver);
    }

    /** Verifies that the page title contains the keyword 'Necklace'. */
    public void verifyPageTitleContainsNecklaceKeyword(ExtentTest test){
        try {
            String actualTitle = driver.getTitle();
            String expectedKeyword = ExcelHandler.readData(0, 2, 1);
            if(actualTitle.contains(expectedKeyword)){
                Assert.assertTrue(true, "Page title contains the keyword: " + expectedKeyword);
                LoggerHandler.info("Verified that the search page results contain the keyword Necklace.");
                test.pass("Verified the search Page Results contains the keyword Necklace.");
            } else {
                Assert.fail("Page title does not contain the keyword: " + expectedKeyword + ". Actual: " + actualTitle);
                LoggerHandler.error("Page title does not contain the keyword Necklace. Actual: " + actualTitle);
                test.log(Status.FAIL, "Page title does not contain the keyword Necklace. Actual: " + actualTitle);
                Reporter.attachScreenshotToReport(Reporter.captureScreenShot("PageTitleVerify_Fail"), test, "Page title verification failed");
            }
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify page title for Necklace keyword: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify page title for Necklace keyword: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyPageTitleNecklace_Fail"), test, "Failed to verify page title");
        }
    }

    /** Hovers over the first necklace product and clicks on the 'Quick View' button. */
    public void hoverOnFirstNecklaceAndClickQuickView(ExtentTest test){
        try {
            helper.hoverOverElement(neckLoc.firstNecklaceImage);
            LoggerHandler.info("Hovered over the first necklace product.");
            test.log(Status.INFO, "Hovered over the first necklace product.");

            helper.clickOn(neckLoc.quickViewButton);
            LoggerHandler.info("Clicked on Quick View.");
            test.pass("Clicked On quick View");
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        } catch (Exception e) {
            LoggerHandler.error("Failed to hover on first necklace and click Quick View: " + e.getMessage());
            test.log(Status.FAIL, "Failed to hover on first necklace and click Quick View: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("HoverNecklaceQuickView_Fail"), test, "Failed to hover and click Quick View");
        }
    }

    /** Clicks the cross button to close any pop-up or modal. */
    public void clickCrossButton(ExtentTest test){
        try {
            helper.clickOn(neckLoc.crossButton);
            LoggerHandler.info("Clicked on cross button.");
            test.pass("Clicked On cross Button");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click cross button: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click cross button: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickCrossButton_Fail"), test, "Failed to click cross button");
        }
    }

    /** Clicks on the first available product in the list. */
    public void clickOnFirstAvailableProduct(ExtentTest test){
        try {
            List<WebElement> necklaceList = helper.getElementsByXPath("//a[@class='tooltip_18']");
            if(!necklaceList.isEmpty()){
                necklaceList.get(0).click();
                LoggerHandler.info("Clicked on the first available product.");
                test.pass("Clicked on first product");
            } else {
                LoggerHandler.warn("No necklace products found to click.");
                test.log(Status.WARNING, "No necklace products found to click.");
            }
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on first product: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click on first product: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickFirstProduct_Fail"), test, "Failed to click on first product");
        }
    }

    /** Selects the first option from the weight dropdown. */
    public void selectFirstWeightOption(ExtentTest test){
        try {
            WebElement weightDropdown = driver.findElement(By.id("item-size"));
            Select select = new Select(weightDropdown);
            select.selectByIndex(0);
            LoggerHandler.info("Selected first weight by index.");
            test.pass("Selected first weight by index");
        } catch (Exception e) {
            LoggerHandler.error("Failed to select first weight option: " + e.getMessage());
            test.log(Status.FAIL, "Failed to select first weight option: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("SelectWeight_Fail"), test, "Failed to select weight option");
        }
    }

    /** Clicks on the 'Buy Now' button. */
    public void clickBuyNowButton(ExtentTest test){
        try {
            helper.clickOn(neckLoc.buyNowButton);
            LoggerHandler.info("Clicked on Buy Now button.");
            test.pass("Clicked On Buy Now");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Buy Now button: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Buy Now button: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickBuyNow_Fail"), test, "Failed to click Buy Now");
        }
    }

}
