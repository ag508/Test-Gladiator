package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;


import uistore.VivahamPageLocators;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

/**
 * Actions for the Vivaham Page.
 * @author Ashwani
 */
public class VivahamPageActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public VivahamPageLocators locators;
    public HighLightActionUtil highlight;
    public Screenshot screenshot;

    /** Constructor for VivahamPageActions. */
    public VivahamPageActions(WebDriver driver){
        this.driver= driver;
        helper =new WebDriverHelper(driver);
        locators = new VivahamPageLocators();
        highlight = new HighLightActionUtil(driver);
        screenshot = new Screenshot(driver);
    }

    /** Clicks on the "Locate Store" button and switches to the new window. */
    public void clickLocateStoreButton(ExtentTest test){
        try {
            helper.clickOn(locators.locateStoreLink);
            helper.switchWindow();
            LoggerHandler.info("Clicked on locate store and switched window.");
            test.pass("Clicked on Locate stores and switched window.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click locate store button: " + e.getMessage());
            String path = Reporter.captureScreenShot("LocateStoreClickFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to click Locate Store button");
            test.fail("Failed to click Locate Store button");
        }
    }

    /** Clicks on the "Delhi" option in the locate store section. */
    public void clickDelhiOption(ExtentTest test){
        try {
            highlight.highlightElement(locators.delhiStoreOption);
            helper.clickOn(locators.delhiStoreOption);
            LoggerHandler.info("Clicked on Delhi.");
            test.pass("Clicked on Delhi.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Delhi option: " + e.getMessage());
            String path = Reporter.captureScreenShot("DelhiOptionClickFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to click Delhi option");
            test.fail("Failed to click Delhi option");
        }
    }
}
