package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.HomePageLocators;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Screenshot;

import utils.ExcelHandler;
import utils.Reporter;
import utils.WebDriverHelper;

/**
 * Actions for the Home Page.
 * @author AI Assistant
 */
public class HomePageActions {

    public WebDriver driver;
    public WebDriverHelper helper;
    
    public HomePageLocators homeLoc;
    public HighLightActionUtil highlight;
    public Screenshot screenshot;

    public HomePageActions(WebDriver driver){
        this.driver= driver;
        helper =new WebDriverHelper(driver);
        highlight = new HighLightActionUtil(driver);
        homeLoc = new HomePageLocators();
        screenshot = new Screenshot(driver);
    }

    /** Scrolls to and clicks on the 'About Us' link, verifies the URL, and navigates back. @author Pragna */
    public void clickOnAboutUs(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.aboutUsLink);
            LoggerHandler.info("Scrolled to About Us link.");
            test.log(Status.PASS,"Scrolled to About Us");

            helper.clickOn(homeLoc.aboutUsLink);
            LoggerHandler.info("Clicked on About Us link.");
            test.log(Status.PASS,"Clicked on About Us");

            String expectedURL = ExcelHandler.readData(0, 1, 8);
            helper.verifyLinkText(expectedURL);
            LoggerHandler.info("Verified About Us URL: " + expectedURL);
            test.log(Status.PASS, "Verified About Us URL.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from About Us page.");
            test.log(Status.INFO, "Navigated back from About Us page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on About Us: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click on About Us: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickAboutUs_Fail"), test, "Failed to click on About Us");
        }
    }

    /** Scrolls to and clicks on 'Why Reliance Jewels', then verifies its URL and page title. @author Pragna */
    public void clickWhyRelianceAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.whyRelianceJewelsLink);
            LoggerHandler.info("Scrolled to Why Reliance Jewels link.");
            test.log(Status.PASS,"Scrolled to Why Reliance");

            helper.clickOn(homeLoc.whyRelianceJewelsLink);
            LoggerHandler.info("Clicked on Why Reliance Jewels link.");
            test.log(Status.PASS,"Clicked on Why Reliance");

            helper.verifyLinkText(ExcelHandler.readData(0, 2, 8));
            LoggerHandler.info("Verified Why Reliance Jewels URL.");
            test.log(Status.PASS, "Verified Why Reliance Jewels URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 3, 8));
            LoggerHandler.info("Verified Why Reliance Jewels page title.");
            test.log(Status.PASS, "Verified Why Reliance Jewels page title.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Why Reliance Jewels and verify URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Why Reliance Jewels and verify URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickWhyReliance_Fail"), test, "Failed to click Why Reliance Jewels");
        }
    }
    
    /** Scrolls to and clicks on 'Certifications', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickCertificationAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.certificationLink);
            LoggerHandler.info("Scrolled to Certifications link.");
            test.log(Status.PASS, "Scrolled to Certification");

            helper.clickOn(homeLoc.certificationLink);
            LoggerHandler.info("Clicked on Certifications link.");
            test.log(Status.PASS,"Clicked on Certification" );

            helper.verifyLinkText(ExcelHandler.readData(0, 4, 8));
            LoggerHandler.info("Verified Certifications URL.");
            test.log(Status.PASS, "Verified Certifications URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 5, 8));
            LoggerHandler.info("Verified Certifications page title.");
            test.log(Status.PASS, "Verified Certifications page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Certifications page.");
            test.log(Status.INFO, "Navigated back from Certifications page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Certifications and verify URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Certifications and verify URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickCertification_Fail"), test, "Failed to click Certifications");
        }
    }  
             
    /** Scrolls to and clicks on 'Our Showrooms', then verifies its URL and navigates back. @author Pragna */
    public void clickShowroomsAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.showroomsLink);
            LoggerHandler.info("Scrolled to Our Showrooms link.");
            test.log(Status.PASS, "Scrolled to ShowRooms");

            helper.clickOn(homeLoc.showroomsLink);
            LoggerHandler.info("Clicked on Our Showrooms link.");
            test.log(Status.PASS, "Clicked on ShowRooms");

            helper.verifyLinkText(ExcelHandler.readData(0, 6, 8));
            LoggerHandler.info("Verified Our Showrooms URL.");
            test.log(Status.PASS, "Verified Our Showrooms URL.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Our Showrooms page.");
            test.log(Status.INFO, "Navigated back from Our Showrooms page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Showrooms and verify URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Showrooms and verify URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickShowrooms_Fail"), test, "Failed to click Showrooms");
        }
    }
    
    /** Scrolls to and clicks on 'Media', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickMediaAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.mediaLink);
            LoggerHandler.info("Scrolled to Media link.");
            test.log(Status.PASS,"Scrolled to Media");

            helper.clickOn(homeLoc.mediaLink);
            LoggerHandler.info("Clicked on Media link.");
            test.log(Status.PASS,"Clicked on Media" );

            helper.verifyLinkText(ExcelHandler.readData(0, 7, 8));
            LoggerHandler.info("Verified Media URL.");
            test.log(Status.PASS, "Verified Media URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 8, 8));
            LoggerHandler.info("Verified Media page title.");
            test.log(Status.PASS, "Verified Media page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Media page.");
            test.log(Status.INFO, "Navigated back from Media page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Media and verify URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Media and verify URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickMedia_Fail"), test, "Failed to click Media");
        }
    }
    
    /** Scrolls to and clicks on 'Blog', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickBlogAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.blogLink);
            LoggerHandler.info("Scrolled to Blog link.");
            test.log(Status.PASS, "Scrolled to Blog");

            helper.clickOn(homeLoc.blogLink);
            LoggerHandler.info("Clicked on Blog link.");
            test.log(Status.PASS,"Clicked on Blog");

            helper.verifyLinkText(ExcelHandler.readData(0, 9,8));
            LoggerHandler.info("Verified Blog URL.");
            test.log(Status.PASS, "Verified Blog URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 10, 8));
            LoggerHandler.info("Verified Blog page title.");
            test.log(Status.PASS, "Verified Blog page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Blog page.");
            test.log(Status.INFO, "Navigated back from Blog page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Blog and verify URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Blog and verify URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickBlog_Fail"), test, "Failed to click Blog");
        }
    }
    
    /** Scrolls to and clicks on 'FAQs', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickFaqAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.faqLink);
            LoggerHandler.info("Scrolled to FAQs link.");
            test.log(Status.PASS, "Scrolled to Faq");

            helper.clickOn(homeLoc.faqLink);
            LoggerHandler.info("Clicked on FAQs link.");
            test.log(Status.PASS, "Clicked on Faq");

            helper.verifyLinkText(ExcelHandler.readData(0, 11, 8));
            LoggerHandler.info("Verified FAQs URL.");
            test.log(Status.PASS, "Verified FAQs URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 12, 8));
            LoggerHandler.info("Verified FAQs page title.");
            test.log(Status.PASS, "Verified FAQs page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from FAQs page.");
            test.log(Status.INFO, "Navigated back from FAQs page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click FAQs and verify URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click FAQs and verify URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickFaq_Fail"), test, "Failed to click FAQs");
        }
    }

    /** Scrolls to and clicks on 'Track An Order', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickTrackOrderAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.trackOrderLink);
            LoggerHandler.info("Scrolled to Track Order link.");
            test.log(Status.PASS,"Scrolled to TrackOrder");

            helper.clickOn(homeLoc.trackOrderLink);
            LoggerHandler.info("Clicked on Track Order link.");
            test.log(Status.PASS,"Clicked on TrackOrder");

            helper.verifyLinkText(ExcelHandler.readData(0, 13, 8));
            LoggerHandler.info("Verified Track Order URL.");
            test.log(Status.PASS, "Verified Track Order URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 14, 8));
            LoggerHandler.info("Verified Track Order page title.");
            test.log(Status.PASS, "Verified Track Order page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Track Order page.");
            test.log(Status.INFO, "Navigated back from Track Order page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Track Order and verify URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Track Order and verify URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickTrackOrder_Fail"), test, "Failed to click Track Order");
        }
    }      

    /** Verifies the 'Fast Shipping' text, highlights the element, captures a screenshot, and unhighlights it. @author Pragna */
    public void verifyFastShippingSection(ExtentTest test){
        try {
            helper.verifyLocatorText(homeLoc.fastShippingText, ExcelHandler.readData(0, 15, 8));
            LoggerHandler.info("Verified Fast Shipping text.");
            test.log(Status.PASS, "Verified Fast Shipping text.");

            highlight.highlightElement(homeLoc.fastShippingText);
            LoggerHandler.info("Highlighted Fast Shipping element.");
            test.log(Status.INFO, "Highlighted Fast Shipping element.");

            screenshot.captureScreenshotWithTimeStamp("FastShippingVerification");
            LoggerHandler.info("Screenshot captured for Fast Shipping verification.");
            test.log(Status.INFO, "Screenshot captured for Fast Shipping verification.");

            highlight.unhighlightElement(homeLoc.fastShippingText);
            LoggerHandler.info("Unhighlighted Fast Shipping element.");
            test.log(Status.INFO, "Unhighlighted Fast Shipping element.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify Fast Shipping section: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify Fast Shipping section: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyFastShipping_Fail"), test, "Failed to verify Fast Shipping section");
        }
    }

    /** Scrolls to and clicks on 'Return & Refund Policy', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickReturnRefundPolicy(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.returnRefundPolicyLink);
            LoggerHandler.info("Scrolled to Return & Refund Policy.");
            test.log(Status.PASS, "Scrolled to ReturnPolicy");

            helper.clickOn(homeLoc.returnRefundPolicyLink);
            LoggerHandler.info("Clicked on Return & Refund Policy.");
            test.log(Status.PASS, "Clicked on ReturnPolicy");

            helper.verifyLinkText(ExcelHandler.readData(0, 1, 9));
            LoggerHandler.info("Verified Return & Refund Policy URL.");
            test.log(Status.PASS, "Verified Return & Refund Policy URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 2, 9));
            LoggerHandler.info("Verified Return & Refund Policy page title.");
            test.log(Status.PASS, "Verified Return & Refund Policy page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Return & Refund Policy page.");
            test.log(Status.INFO, "Navigated back from Return & Refund Policy page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Return & Refund Policy: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Return & Refund Policy: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickReturnPolicy_Fail"), test, "Failed to click Return & Refund Policy");
        }
    }

    /** Scrolls to and clicks on 'Shipping Policy', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickShippingPolicy(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.shippingPolicyLink);
            LoggerHandler.info("Scrolled to Shipping Policy.");
            test.log(Status.PASS, "Scrolled to ShoppingPolicy");

            helper.clickOn(homeLoc.shippingPolicyLink);
            LoggerHandler.info("Clicked on Shipping Policy.");
            test.log(Status.PASS, "Clicked on ShoppingPolicy");

            helper.verifyLinkText(ExcelHandler.readData(0, 3, 9));
            LoggerHandler.info("Verified Shipping Policy URL.");
            test.log(Status.PASS, "Verified Shipping Policy URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 4, 9));
            LoggerHandler.info("Verified Shipping Policy page title.");
            test.log(Status.PASS, "Verified Shipping Policy page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Shipping Policy page.");
            test.log(Status.INFO, "Navigated back from Shipping Policy page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Shipping Policy: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Shipping Policy: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickShippingPolicy_Fail"), test, "Failed to click Shipping Policy");
        }
    }

    /** Scrolls to and clicks on 'Privacy Policy', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickPrivacyPolicy(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.privacyPolicyLink);
            LoggerHandler.info("Scrolled to Privacy Policy.");
            test.log(Status.PASS, "Scrolled to PrivacyPolicy");

            helper.clickOn(homeLoc.privacyPolicyLink);
            LoggerHandler.info("Clicked on Privacy Policy.");
            test.log(Status.PASS, "Clicked on PrivacyPolicy");

            helper.verifyLinkText(ExcelHandler.readData(0, 5, 9));
            LoggerHandler.info("Verified Privacy Policy URL.");
            test.log(Status.PASS, "Verified Privacy Policy URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 6, 9));
            LoggerHandler.info("Verified Privacy Policy page title.");
            test.log(Status.PASS, "Verified Privacy Policy page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Privacy Policy page.");
            test.log(Status.INFO, "Navigated back from Privacy Policy page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Privacy Policy: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Privacy Policy: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickPrivacyPolicy_Fail"), test, "Failed to click Privacy Policy");
        }
    }

    /** Scrolls to and clicks on 'Old Gold Exchange Policy', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickOldGoldExchangePolicy(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.oldGoldExchangePolicyLink);
            LoggerHandler.info("Scrolled to Old Gold Exchange Policy.");
            test.log(Status.PASS, "Scrolled to OldGoldExchangePolicy");

            helper.clickOn(homeLoc.oldGoldExchangePolicyLink);
            LoggerHandler.info("Clicked on Old Gold Exchange Policy.");
            test.log(Status.PASS, "Clicked on OldGoldExchangePolicy");

            helper.verifyLinkText(ExcelHandler.readData(0, 7, 9));
            LoggerHandler.info("Verified Old Gold Exchange Policy URL.");
            test.log(Status.PASS, "Verified Old Gold Exchange Policy URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 8, 9));
            LoggerHandler.info("Verified Old Gold Exchange Policy page title.");
            test.log(Status.PASS, "Verified Old Gold Exchange Policy page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Old Gold Exchange Policy page.");
            test.log(Status.INFO, "Navigated back from Old Gold Exchange Policy page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Old Gold Exchange Policy: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Old Gold Exchange Policy: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickOldGoldExchangePolicy_Fail"), test, "Failed to click Old Gold Exchange Policy");
        }
    }

    /** Scrolls to and clicks on 'Fees and Payments Policy', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickFeesAndPaymentsPolicy(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.feesPaymentsPolicyLink);
            LoggerHandler.info("Scrolled to Fees and Payments Policy.");
            test.log(Status.PASS, "Scrolled to FeesandPayments");

            helper.clickOn(homeLoc.feesPaymentsPolicyLink);
            LoggerHandler.info("Clicked on Fees and Payments Policy.");
            test.log(Status.PASS, "Clicked on FeesandPayments");

            helper.verifyLinkText(ExcelHandler.readData(0, 9, 9));
            LoggerHandler.info("Verified Fees and Payments Policy URL.");
            test.log(Status.PASS, "Verified Fees and Payments Policy URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 10, 9));
            LoggerHandler.info("Verified Fees and Payments Policy page title.");
            test.log(Status.PASS, "Verified Fees and Payments Policy page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Fees and Payments Policy page.");
            test.log(Status.INFO, "Navigated back from Fees and Payments Policy page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Fees and Payments Policy: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Fees and Payments Policy: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickFeesPaymentsPolicy_Fail"), test, "Failed to click Fees and Payments Policy");
        }
    }

    /** Scrolls to and clicks on 'Terms and Conditions', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickTermsAndConditions(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.termsConditionsLink);
            LoggerHandler.info("Scrolled to Terms and Conditions.");
            test.log(Status.PASS, "Scrolled to TermsandConditions");

            helper.clickOn(homeLoc.termsConditionsLink);
            LoggerHandler.info("Clicked on Terms and Conditions.");
            test.log(Status.PASS, "Clicked on TermsandConditions");

            helper.verifyLinkText(ExcelHandler.readData(0, 11, 9));
            LoggerHandler.info("Verified Terms and Conditions URL.");
            test.log(Status.PASS, "Verified Terms and Conditions URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 12, 9));
            LoggerHandler.info("Verified Terms and Conditions page title.");
            test.log(Status.PASS, "Verified Terms and Conditions page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Terms and Conditions page.");
            test.log(Status.INFO, "Navigated back from Terms and Conditions page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Terms and Conditions: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Terms and Conditions: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickTermsAndConditions_Fail"), test, "Failed to click Terms and Conditions");
        }
    }

    /** Scrolls to and clicks on 'RelianceOne Loyalty T & C', then verifies its URL and page title, and navigates back. @author Pragna */
    public void clickRelianceOneLoyaltyTermsAndConditions(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.relianceOneLoyaltyLink);
            LoggerHandler.info("Scrolled to RelianceOne Loyalty T & C.");
            test.log(Status.PASS, "Scrolled to RelianceOneLoyalty");

            helper.clickOn(homeLoc.relianceOneLoyaltyLink);
            LoggerHandler.info("Clicked on RelianceOne Loyalty T & C.");
            test.log(Status.PASS,"Clicked on RelianceOneLoyalty");

            helper.verifyLinkText(ExcelHandler.readData(0, 13, 9));
            LoggerHandler.info("Verified RelianceOne Loyalty T & C URL.");
            test.log(Status.PASS, "Verified RelianceOne Loyalty T & C URL.");

            helper.verifyPageTitle(ExcelHandler.readData(0, 14, 9));
            LoggerHandler.info("Verified RelianceOne Loyalty T & C page title.");
            test.log(Status.PASS, "Verified RelianceOne Loyalty T & C page title.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from RelianceOne Loyalty T & C page.");
            test.log(Status.INFO, "Navigated back from RelianceOne Loyalty T & C page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click RelianceOne Loyalty T & C: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click RelianceOne Loyalty T & C: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickRelianceOneLoyalty_Fail"), test, "Failed to click RelianceOne Loyalty T & C");
        }
    }

    /** Scrolls to and clicks on 'Disclaimer', then verifies its URL, and navigates back. @author Pragna */
    public void clickDisclaimerAndVerifyUrl(ExtentTest test){
        try {
            helper.scrollToElement(homeLoc.disclaimerLink);
            LoggerHandler.info("Scrolled to Disclaimer link.");
            test.log(Status.PASS, "Scrolled to Disclaimer");

            helper.clickOn(homeLoc.disclaimerLink);
            LoggerHandler.info("Clicked on Disclaimer link.");
            test.log(Status.PASS, "Clicked on Disclaimer");

            helper.verifyLinkText(ExcelHandler.readData(0, 15, 9));
            LoggerHandler.info("Verified Disclaimer URL.");
            test.log(Status.PASS, "Verified Disclaimer URL.");

            driver.navigate().back();
            LoggerHandler.info("Navigated back from Disclaimer page.");
            test.log(Status.INFO, "Navigated back from Disclaimer page.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Disclaimer: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Disclaimer: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickDisclaimer_Fail"), test, "Failed to click Disclaimer");
        }
    }

    /** Verifies the 'Call Back' text, highlights the element, captures a screenshot, and unhighlights it. @author Pragna */
    public void verifyCallBackSection(ExtentTest test){
        try {
            helper.verifyLocatorText(homeLoc.callBackLink, ExcelHandler.readData(0, 16, 9));
            LoggerHandler.info("Verified Call Back text.");
            test.log(Status.PASS, "Verified callback");

            highlight.highlightElement(homeLoc.callBackLink);
            LoggerHandler.info("Highlighted Call Back element.");
            test.log(Status.INFO, "Highlighted callback");

            screenshot.captureScreenshotWithTimeStamp("CallBackVerification");
            LoggerHandler.info("Screenshot captured for Call Back verification.");
            test.log(Status.INFO, "Screenshot captured");

            highlight.unhighlightElement(homeLoc.callBackLink);
            LoggerHandler.info("Unhighlighted Call Back element.");
            test.log(Status.INFO, "Unhighlighted callback");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify Call Back section: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify Call Back section: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyCallBack_Fail"), test, "Failed to verify Call Back section");
        }
    }

    /** Clicks on the search bar, enters the search value for rings, and performs an enter action. @author Dhruv */
    public void clickSearchBarAndEnterSearchValueRings(ExtentTest test){
        try {
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("BeforeSearchBarClick_Rings"), test, "Before clicking on search bar and entering rings search value");

            helper.clickOn(homeLoc.searchBarInput);
            LoggerHandler.info("Clicked on search Bar for rings search.");
            test.pass("Clicked on search Bar for testcase 1");

            helper.sendText(homeLoc.searchBarInput, ExcelHandler.readData(0, 1, 0));
            LoggerHandler.info("Sent data from Excel File for rings search.");
            test.pass("Sent data from Excel File for testcase 1");

            helper.enterAction(homeLoc.searchBarInput);
            LoggerHandler.info("Performed Enter action after rings search.");
            test.pass("Clicked on Enter");
        } catch (Exception e) {
            LoggerHandler.error("Failed to search for Rings: " + e.getMessage());
            test.log(Status.FAIL, "Failed to search for Rings: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("SearchRings_Fail"), test, "Failed to search for Rings");
        }
    }

    /** Clicks on the search bar, enters the search value for necklaces, and performs an enter action. @author Dhruv */
    public void clickSearchBarAndEnterSearchValueNecklace(ExtentTest test){
        try {
            helper.clickOn(homeLoc.searchBarInput);
            LoggerHandler.info("Clicked on search Bar for necklace search.");
            test.pass("Clicked on search Bar for testcase 2");

            helper.sendText(homeLoc.searchBarInput, ExcelHandler.readData(0, 1, 1));
            LoggerHandler.info("Sent data from Excel File for necklace search.");
            test.pass("Sent data from Excel File for testcase 2");

            helper.enterAction(homeLoc.searchBarInput);
            LoggerHandler.info("Performed Enter action after necklace search.");
            test.pass("Clicked on Enter");
        } catch (Exception e) {
            LoggerHandler.error("Failed to search for Necklace: " + e.getMessage());
            test.log(Status.FAIL, "Failed to search for Necklace: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("SearchNecklace_Fail"), test, "Failed to search for Necklace");
        }
    }

    /** Hovers over the Earrings category and clicks on the Drops sub-category. @author Aneesh */
    public void hoverOnEarringsAndClickDrops(ExtentTest test){
        try {
            helper.hoverOverElement(HomePageLocators.earringsCategory);
            LoggerHandler.info("Hovered over Earrings category.");
            test.log(Status.PASS, "Hovered over Earrings category.");

            helper.clickOn(HomePageLocators.dropsSubCategory);
            LoggerHandler.info("Clicked on Drops sub-category.");
            test.log(Status.PASS, "Clicked on Drops sub-category.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to hover on Earrings and click Drops: " + e.getMessage());
            test.log(Status.FAIL, "Failed to hover on Earrings and click Drops: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("HoverEarringsClickDrops_Fail"), test, "Failed to hover on Earrings and click Drops");
        }
    }

    /** Verifies the link of the main logo on the homepage. @author Aneesh */
    public void verifyMainLogoLink(ExtentTest test){
        try {
            helper.verifyLogoLink(HomePageLocators.mainLogoLocator, ExcelHandler.readData(0, 1, 7));
            LoggerHandler.info("Verified main logo link.");
            test.log(Status.PASS, "Verified main logo link.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify main logo link: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify main logo link: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyMainLogoLink_Fail"), test, "Failed to verify main logo link");
        }
    }

    /** Hovers over the Chain category and clicks on the Silver sub-category. @author Aneesh */
    public void clickSilverChain(ExtentTest test){
        try {
            helper.hoverOverElement(HomePageLocators.chainCategory);
            LoggerHandler.info("Hovered over Chain category.");
            test.log(Status.PASS, "Hovered over Chain category.");

            helper.clickOn(HomePageLocators.silverSubCategory);
            LoggerHandler.info("Clicked on Silver sub-category.");
            test.log(Status.PASS, "Clicked on Silver sub-category.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Silver Chain: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Silver Chain: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickSilverChain_Fail"), test, "Failed to click Silver Chain");
        }
    }

    /** Hovers over the 'What's Trending' section. @author Ashwani */
    public void hoverOnWhatsTrending(ExtentTest test){
        try {
            helper.hoverOverElement(homeLoc.trendingLink);
            LoggerHandler.info("Hovered on What's Trending.");
            test.pass("Hovered on What's Trending");
        } catch (Exception e) {
            LoggerHandler.error("Failed to hover on What's Trending: " + e.getMessage());
            test.log(Status.FAIL, "Failed to hover on What's Trending: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("HoverWhatsTrending_Fail"), test, "Failed to hover on What's Trending");
        }
    }

    /** Clicks on the 'Vivaham' link and switches to the new window. @author Ashwani */
    public void clickVivahamLinkAndSwitchWindow(ExtentTest test){
        try {
            helper.clickOn(homeLoc.vivahamLink);
            LoggerHandler.info("Clicked on Vivaham link.");
            test.pass("Clicked Vivaham");

            helper.switchWindow();
            LoggerHandler.info("Switched to Vivaham window.");
            test.log(Status.INFO, "Switched to Vivaham window.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Vivaham link and switch window: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Vivaham link and switch window: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickVivahamLink_Fail"), test, "Failed to click Vivaham link");
        }
    }

    /** Verifies the URL of the Vivaham page. @author Ashwani */
    public void verifyVivahamUrl(ExtentTest test){
        try {
            helper.verifyLinkText(ExcelHandler.readData(0, 1, 2));
            LoggerHandler.info("Verified Vivaham URL.");
            test.pass("Verified Vihaham URL");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify Vivaham URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify Vivaham URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyVivahamUrl_Fail"), test, "Failed to verify Vivaham URL");
        }
    }

    /** Hovers over the Earrings category on the homepage. @author Ashwani */
    public void hoverOnEarringsCategory(ExtentTest test){
        try {
            helper.hoverOverElement(homeLoc.earringsNavLink);
            LoggerHandler.info("Hovered on Earrings category.");
            test.pass("Hovered on earrrings");
        } catch (Exception e) {
            LoggerHandler.error("Failed to hover on Earrings category: " + e.getMessage());
            test.log(Status.FAIL, "Failed to hover on Earrings category: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("HoverEarringsCategory_Fail"), test, "Failed to hover on Earrings category");
        }
    }

    /** Clicks on the Diamond sub-category under Earrings. @author Ashwani */
    public void clickOnDiamondEarringsSubCategory(ExtentTest test){
        try {
            helper.clickOn(homeLoc.diamondEarringsLink);
            LoggerHandler.info("Clicked on Diamond sub-category under Earrings.");
            test.pass("Clicked on Diamond under earrrings");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on Diamond Earrings sub-category: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click on Diamond Earrings sub-category: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickDiamondEarrings_Fail"), test, "Failed to click on Diamond Earrings sub-category");
        }
    }
    
	/** Hovers over the PENDANTS navigation link and clicks on the Gifting sub-category. @author Yash */
	public void hoverOnPendantsAndClickGifting(ExtentTest test) {
	    try {
		    helper.hoverOverElement(homeLoc.pendantsNavLink);
		    LoggerHandler.info("Hovered on pendants navigation link.");
		    test.log(Status.PASS,"Hovered on pendants");
		    
		    helper.clickOn(homeLoc.giftingLink);
		    LoggerHandler.info("Clicked on gifting link.");
		    test.log(Status.PASS,"Clicked on gifting");
		    driver.manage().timeouts().pageLoadTimeout(Duration.ofMinutes(1));
	    } catch (Exception e) {
            LoggerHandler.error("Failed to hover on Pendants and click Gifting: " + e.getMessage());
            test.log(Status.FAIL, "Failed to hover on Pendants and click Gifting: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("HoverPendantsClickGifting_Fail"), test, "Failed to hover on Pendants and click Gifting");
        }
	}

	/** Hovers over the Rings navigation link and clicks on the Casual Wear sub-category. @author Yash */
	public void hoverOnRingsAndClickCasualWear(ExtentTest test) {
	    try {
		    helper.hoverOverElement(homeLoc.ringsNavLink);
		    LoggerHandler.info("Hovered on rings navigation link.");
		    test.log(Status.PASS,"Hovered on rings");

		    helper.clickOn(homeLoc.casualWearLink);
		    LoggerHandler.info("Clicked on casual wear link.");
		    test.log(Status.PASS,"Clicked on casual wear");
		    driver.manage().timeouts().pageLoadTimeout(Duration.ofMinutes(1));
	    } catch (Exception e) {
            LoggerHandler.error("Failed to hover on Rings and click Casual Wear: " + e.getMessage());
            test.log(Status.FAIL, "Failed to hover on Rings and click Casual Wear: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("HoverRingsClickCasualWear_Fail"), test, "Failed to hover on Rings and click Casual Wear");
        }
	}

}
