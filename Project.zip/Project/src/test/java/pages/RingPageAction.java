package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.RingLocator;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;
import org.testng.Assert;

/**
 * Actions for the Ring Page.
 * @author Yash
 */
public class RingPageAction {
	public WebDriver driver;
	public WebDriverHelper helper;
	public RingLocator ringloc;
	public LoggerHandler log;
	public Screenshot screenshot;

	/** Constructor for RingPageAction. */
	public RingPageAction(WebDriver driver) {
		this.driver = driver;
		helper=new WebDriverHelper(driver);
		ringloc=new RingLocator();
		screenshot = new Screenshot(driver);
	}

	/** Performs a series of actions on the ring page, including navigating, filtering, and selecting a product. */
	public void performRingPageActions(ExtentTest test) {
		try {
			Assert.assertTrue(driver.getCurrentUrl().contains(ExcelHandler.readData(0, 2, 6)));
			LoggerHandler.info("Verified current URL contains expected value.");
			test.pass("Verified current URL contains expected value.");

			helper.clickOn(ringloc.categoryFilter);
			LoggerHandler.info("Clicked on category filter.");
			test.pass("Clicked on category filter.");

			helper.clickOn(ringloc.platinumOption);
			LoggerHandler.info("Clicked on platinum category.");
			test.pass("Clicked on platinum category.");

			helper.clickOn(ringloc.moreFilterButton);
			LoggerHandler.info("Clicked on more filter.");
			test.pass("Clicked on more filter.");

			helper.clickOn(ringloc.tryOnFilter);
			LoggerHandler.info("Clicked on try on option.");
			test.pass("Clicked on try on option.");

			helper.clickOn(ringloc.yesOption);
			LoggerHandler.info("Clicked on Yes button.");
			test.pass("Clicked on Yes button.");

			helper.clickOn(ringloc.firstProduct);
			LoggerHandler.info("Clicked on the first product.");
			test.pass("Clicked on the first product.");

		} catch (Exception e) {
			LoggerHandler.error("Failed to perform ring page actions: " + e.getMessage());
			String path = Reporter.captureScreenShot("ringPageActionsFailure");
			Reporter.attachScreenshotToReport(path, test, "Failed to perform ring page actions");
			test.fail("Failed to perform ring page actions");
		}
	}
}
