package pages;

import org.openqa.selenium.WebDriver;

import uistore.ChainsLocator;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

/**
 * Actions for the Chains product category page.
 * @author Aneesh
 */
public class ChainsActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public ChainsActions(WebDriver driver){
        this.driver= driver;
        helper =new WebDriverHelper(driver);
    }

    /** Selects category filter and applies gender filter for women. */
    public void selectCategoryAndGenderFilter(ExtentTest test, String categoryFilterText){
        try {
            helper.verifyLocatorText(ChainsLocator.categoryFilter, categoryFilterText);
            LoggerHandler.info("Verified category filter text.");
            test.log(Status.PASS, "Verified category filter text.");

            helper.clickOn(ChainsLocator.genderFilter);
            LoggerHandler.info("Clicked on gender filter.");
            test.log(Status.PASS, "Clicked on gender filter.");

            helper.clickOn(ChainsLocator.womenOption);
            LoggerHandler.info("Selected women option under gender filter.");
            test.log(Status.PASS, "Selected women option under gender filter.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to select category and gender filter: " + e.getMessage());
            test.log(Status.FAIL, "Failed to select category and gender filter: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("selectCategoryAndGenderFilter_Fail"), test, "Failed to select category and gender filter");
        }
    }

    /** Clicks on more filter and applies 'Try On' filter with 'Yes' option. */
    public void applyMoreFilters(ExtentTest test){
        try {
            helper.clickOn(ChainsLocator.moreFilterButton);
            LoggerHandler.info("Clicked on more filter button.");
            test.log(Status.PASS, "Clicked on more filter button.");

            helper.clickOn(ChainsLocator.tryOnFilter);
            LoggerHandler.info("Clicked on try on filter.");
            test.log(Status.PASS, "Clicked on try on filter.");

            helper.jsClick(ChainsLocator.yesOption);
            LoggerHandler.info("Clicked on yes option under try on filter.");
            test.log(Status.PASS, "Clicked on yes option under try on filter.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to apply more filters: " + e.getMessage());
            test.log(Status.FAIL, "Failed to apply more filters: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("applyMoreFilters_Fail"), test, "Failed to apply more filters");
        }
    }

    /** Clicks on the first product displayed on the page. */
    public void clickFirstProduct(ExtentTest test){
        try {
            helper.clickOn(ChainsLocator.firstProduct);
            LoggerHandler.info("Clicked on the first product.");
            test.log(Status.PASS, "Clicked on the first product.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on first product: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click on first product: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("clickFirstProduct_Fail"), test, "Failed to click on first product");
        }
    }
}
