package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.ProductsPageLocators;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

/**
 * Actions for the Products Page.
 * @author Ashwani
 */
public class ProductsPageActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public ProductsPageLocators locators;
    public HighLightActionUtil highlight;
    public Screenshot screenshot;

    /** Constructor for ProductsPageActions. */
    public ProductsPageActions(WebDriver driver){
        this.driver= driver;
        helper =new WebDriverHelper(driver);
        locators = new ProductsPageLocators();
        highlight = new HighLightActionUtil(driver);
        screenshot = new Screenshot(driver);
    }

    /** Verifies the "Sort By" filter label on the products page. */
    public void verifySortByFilterLabel(ExtentTest test, String sortByLabel){
        try {
            highlight.highlightElement(locators.sortFilterSection);
            helper.verifyLocatorText(locators.sortFilterSection, sortByLabel);
            LoggerHandler.info("Verified Sort By filter label");
            test.pass("Verified Sort By filter label");
            String path = Reporter.captureScreenShot("sortBy");
            Reporter.attachScreenshotToReport(path, test, "Verified Sort by filter label");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify Sort By filter label: " + e.getMessage());
            String path = Reporter.captureScreenShot("sortBy");
            Reporter.attachScreenshotToReport(path, test, "Failed to verify Sort by filter label");
            test.fail("Failed to verify Sort By filter label");
        }
    }

    /** Verifies the "Diamond" keyword on the products page. */
    public void verifyDiamondKeyword(ExtentTest test, String diamondKeyword){
        try {
            highlight.highlightElement(locators.diamondBreadcrumbText);
            helper.verifyLocatorText(locators.diamondBreadcrumbText, diamondKeyword);
            LoggerHandler.info("Verified Diamond keyword");
            test.pass("Verified Diamond Keywords");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify Diamond keyword: " + e.getMessage());
            String path = Reporter.captureScreenShot("diamondKeyword");
            Reporter.attachScreenshotToReport(path, test, "Failed to verify Diamond keyword");
            test.fail("Failed to verify Diamond keyword");
        }
    }

    /** Clicks on "Women" under the "Gender" filter. */
    public void clickOnWomenUnderGender(ExtentTest test, String gender){
        try {
            helper.clickOn(locators.genderFilter);
            helper.clickOn(locators.womenOption);
            LoggerHandler.info("Clicked Women Under Gender");
            test.pass("Clicked Women under Gender");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on Women under Gender: " + e.getMessage());
            String path = Reporter.captureScreenShot("womenUnderGender");
            Reporter.attachScreenshotToReport(path, test, "Failed to click on Women under Gender");
            test.fail("Failed to click on Women under Gender");
        }
    }

    /** Hovers over the "Popularity" filter. */
    public void hoverOnPopularityFilter(ExtentTest test, String filterType){
        try {
            helper.hoverOverElement(locators.popularityOption);
            LoggerHandler.info("Hovered on Popularity");
            test.pass("Hovered on popularity");
        } catch (Exception e) {
            LoggerHandler.error("Failed to hover on Popularity filter: " + e.getMessage());
            String path = Reporter.captureScreenShot("popularityFilter");
            Reporter.attachScreenshotToReport(path, test, "Failed to hover on Popularity filter");
            test.fail("Failed to hover on Popularity filter");
        }
    }

    /** Clicks on "New Arrivals" filter. */
    public void clickOnNewArrivalsFilter(ExtentTest test, String arrivalType){
        try {
            helper.clickOn(locators.newArrivalsOption);
            LoggerHandler.info("Clicked on New Arrivals");
            test.pass("Clicked on New Arrivals");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on New Arrivals filter: " + e.getMessage());
            String path = Reporter.captureScreenShot("newArrivalsFilter");
            Reporter.attachScreenshotToReport(path, test, "Failed to click on New Arrivals filter");
            test.fail("Failed to click on New Arrivals filter");
        }
    }

    /** Clicks on the first product displayed on the page. */
    public void clickOnFirstProduct(ExtentTest test){
        try {
            helper.clickOn(locators.firstProduct);
            LoggerHandler.info("Clicked on first product");
            test.pass("Clicked on first product");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on first product: " + e.getMessage());
            String path = Reporter.captureScreenShot("firstProduct");
            Reporter.attachScreenshotToReport(path, test, "Failed to click on first product");
            test.fail("Failed to click on first product");
        }
    }

    /** Verifies the "Earring" keyword on the products page. */
    public void verifyEarringKeyword(ExtentTest test, String earringKeyword){
        try {
            helper.verifyLocatorText(locators.earringsText, earringKeyword);
            LoggerHandler.info("Verified Earrings keyword");
            test.pass("Verified Earrings keyword");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify Earring keyword: " + e.getMessage());
            String path = Reporter.captureScreenShot("earringKeyword");
            Reporter.attachScreenshotToReport(path, test, "Failed to verify Earring keyword");
            test.fail("Failed to verify Earring keyword");
        }
    }

    /** Clicks the "Add to Cart" button. */
    public void clickAddToCartButton(ExtentTest test){
        try {
            helper.clickOn(locators.addToCartButton);
            LoggerHandler.info("Clicked on Add to cart");
            test.pass("Clicked on add to cart");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on Add to cart button: " + e.getMessage());
            String path = Reporter.captureScreenShot("addToCart");
            Reporter.attachScreenshotToReport(path, test, "Failed to click on Add to cart button");
            test.fail("Failed to click on Add to cart button");
        }
    }
}
