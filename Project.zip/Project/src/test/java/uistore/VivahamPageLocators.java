package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: VivahamPageLocators
 * Author: Ashwani
 * Description: UI locators for the Vivaham page.
 */
public class VivahamPageLocators {
    /** Locator for the 'LOCATE A STORE' link. */
    public By locateStoreLink = By.xpath("//a[text()='LOCATE A STORE']");
    /** Locator for the 'Delhi' store option. */
    public By delhiStoreOption = By.xpath("(//p[text()='Delhi'])[1]");
    
}
