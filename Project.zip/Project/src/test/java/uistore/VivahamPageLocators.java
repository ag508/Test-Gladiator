package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: VivahamPageLocators
 * Author: Ashwani
 * Description: UI locators for the Vivaham page.
 */
public class VivahamPageLocators {
    public By locateStoreLink = By.xpath("//a[text()='LOCATE A STORE']");
    public By delhiStoreOption = By.xpath("(//p[text()='Delhi'])[1]");
    
}
