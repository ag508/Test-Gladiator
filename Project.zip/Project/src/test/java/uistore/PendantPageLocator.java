package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: PendantPageLocator
 * Author: Yash
 * Description: UI locators for the Pendant product page.
 */
public class PendantPageLocator {
	public By genderFilter = By.xpath("//div[@id='filter_tree' and text()='Gender']");
	public By kidsOption = By.xpath("(//a[contains(text(),'Kids')])[4]");
	public By moreFilterButton = By.xpath("//button[@id='myBtn']");
	public By typeFilter = By.id("filter_4");
	public By pendantTypeOption = By.xpath("//a[text()=' Pendant ']");
	public By firstProduct = By.xpath("//a[text()='18 Karat Gold Pendant']");
}
