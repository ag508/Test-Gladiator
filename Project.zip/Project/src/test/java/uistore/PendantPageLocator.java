package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: PendantPageLocator
 * Author: Yash
 * Description: UI locators for the Pendant product page.
 */
public class PendantPageLocator {
	/** Locator for the Gender filter section. */
	public By genderFilter = By.xpath("//div[@id='filter_tree' and text()='Gender']");
	/** Locator for the 'Kids' option within the Gender filter. */
	public By kidsOption = By.xpath("(//a[contains(text(),'Kids')])[4]");
	/** Locator for the 'More Filter' button. */
	public By moreFilterButton = By.xpath("//button[@id='myBtn']");
	/** Locator for the Type filter. */
	public By typeFilter = By.id("filter_4");
	/** Locator for the 'Pendant' type option. */
	public By pendantTypeOption = By.xpath("//a[text()=' Pendant ']");
	/** Locator for the first product displayed on the page. */
	public By firstProduct = By.xpath("//a[text()='18 Karat Gold Pendant']");
}
