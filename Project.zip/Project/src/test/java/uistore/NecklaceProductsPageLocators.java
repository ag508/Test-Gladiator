package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: NecklaceProductsPageLocators
 * Author: Dhruv
 * Description: UI locators for the Necklace Products page.
 */
public class NecklaceProductsPageLocators {

    public By firstNecklaceImage = By.xpath("//img[@title='Buy Modern Silver Bar Necklace']");
    public By quickViewButton = By.xpath("(//a[@class='quicklooklink'])[1]");
    public By crossButton = By.xpath("//a[@title='Close']");
    public By buyNowButton = By.xpath("(//a[@id='btnBuyNow'])[2]");

}
