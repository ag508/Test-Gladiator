package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: NecklaceProductsPageLocators
 * Author: Dhruv
 * Description: UI locators for the Necklace Products page.
 */
public class NecklaceProductsPageLocators {

    /** Locator for the first necklace product image. */
    public By firstNecklaceImage = By.xpath("//img[@title='Buy Modern Silver Bar Necklace']");
    /** Locator for the 'Quick View' button on a product. */
    public By quickViewButton = By.xpath("(//a[@class='quicklooklink'])[1]");
    /** Locator for the cross button to close pop-ups/modals. */
    public By crossButton = By.xpath("//a[@title='Close']");
    /** Locator for the 'Buy Now' button. */
    public By buyNowButton = By.xpath("(//a[@id='btnBuyNow'])[2]");

}
