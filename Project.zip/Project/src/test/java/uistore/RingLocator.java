package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: RingLocator
 * Author: Yash
 * Description: UI locators for the Ring product category page.
 */
public class RingLocator {
	public By categoryFilter = By.xpath("//div[text()='categories']");
	public By platinumOption = By.xpath("//li[@id='140']/a[contains(text(),'Platinum')]");
	public By moreFilterButton = By.xpath("//button[@id='myBtn']");
	public By tryOnFilter  = By.id("filter_3");
	public By yesOption = By.xpath("//a[text()=' Yes ']");
	public By firstProduct = By.xpath("(//a[@class='tooltip_18'])[1]");
}
