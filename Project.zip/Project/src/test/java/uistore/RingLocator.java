package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: RingLocator
 * Author: Yash
 * Description: UI locators for the Ring product category page.
 */
public class RingLocator {
	/** Locator for the Category filter section. */
	public By categoryFilter = By.xpath("//div[text()='categories']");
	/** Locator for the 'Platinum' option within the category filter. */
	public By platinumOption = By.xpath("//li[@id='140']/a[contains(text(),'Platinum')]");
	/** Locator for the 'More Filter' button. */
	public By moreFilterButton = By.xpath("//button[@id='myBtn']");
	/** Locator for the 'Try On' filter. */
	public By tryOnFilter  = By.id("filter_3");
	/** Locator for the 'Yes' option within the 'Try On' filter. */
	public By yesOption = By.xpath("//a[text()=' Yes ']");
	/** Locator for the first product displayed on the page. */
	public By firstProduct = By.xpath("(//a[@class='tooltip_18'])[1]");
}
