package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ShoppingCart
 * Author: Aneesh
 * Description: UI locators for the Shopping Cart page.
 */
public class ShoppingCart {
    public static final By firstProductInCart = By.id("productNameCartPage_1");
    
}
