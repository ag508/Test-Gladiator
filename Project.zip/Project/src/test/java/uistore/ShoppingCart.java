package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ShoppingCart
 * Author: Aneesh
 * Description: UI locators for the Shopping Cart page.
 */
public class ShoppingCart {
    /** Locator for the first product listed in the shopping cart. */
    public static final By firstProductInCart = By.id("productNameCartPage_1");
    
}
