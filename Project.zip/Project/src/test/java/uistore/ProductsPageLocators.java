package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ProductsPageLocators
 * Author: Ashwani
 * Description: UI locators for the Products listing page.
 */
public class ProductsPageLocators {
    /** Locator for the Sort filter section. */
    public By sortFilterSection = By.xpath("//div[@class='sortsection']/p");
    /** Locator for the Diamond text in the breadcrumb. */
    public By diamondBreadcrumbText = By.xpath("//span[@id='breadcrumbNavigationLast']");
    /** Locator for the Gender filter section. */
    public By genderFilter = By.xpath("//div[text()='Gender']");
    /** Locator for the 'Women' option within the Gender filter. */
    public By womenOption = By.xpath("//a[text()=' Women ']");
    /** Locator for the 'Popularity' sort option. */
    public By popularityOption = By.xpath("//button[text()='Popularity']");
    /** Locator for the 'New Arrivals' sort option. */
    public By newArrivalsOption = By.xpath("//a[contains(text(),'New')]");
    /** Locator for the first product displayed on the page. */
    public By firstProduct = By.xpath("(//p[@class='product_title']/a)[1]");
    /** Locator for the 'Earrings' text/category. */
    public By earringsText = By.xpath("(//span[text()='Earrings'])[1]");
    /** Locator for the 'Add to Cart' button. */
    public By addToCartButton = By.xpath("(//div[@id='btnBuyNowC']/a)[1]");
}
