package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: RingsProductsPageLocators
 * Author: Dhruv
 * Description: UI locators for the Rings Products listing page.
 */
public class RingsProductsPageLocators {

    /** Locator to verify that the page contains 'Rings' in the breadcrumb. */
    public By pageContainsRingsText = By.xpath("//span[@id='breadcrumbNavigationLast']");
    /** Locator for the Gender filter button. */
    public By genderFilterButton = By.xpath("(//div[@id='filter_tree'])[3]");
    /** Locator for the 'Men' option within the Gender filter. */
    public By menOption = By.xpath("(//li[@id='filter_0Option_1']//a)[1]");
    /** Locator for the Metal filter button. */
    public By metalFilterButton = By.xpath("(//div[@id='filter_tree'])[4]");
    // public By metalBtn = By.id("filter_tree");
    
    /** Locator for the 'Gold' option under the Metal filter. */
    public By goldUnderMetalOption = By.xpath("(//li[@id='filter_0Option_2'])[2]//a");
    /** Locator for the first product link on the page. */
    public By firstProductLink = By.xpath("//a[@class='tooltip_18']");
}
