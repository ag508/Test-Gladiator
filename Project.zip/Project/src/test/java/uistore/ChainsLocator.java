package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ChainsLocator
 * Author: Aneesh
 * Description: UI locators for the Chains product category page.
 */
public class ChainsLocator {
    /** Locator for the Category filter. */
    public static final By categoryFilter = By.id("filter_tree");
    /** Locator for the Gender filter section. */
    public static final By genderFilter = By.xpath("//div[contains(text(), 'Gender')]");
    /** Locator for the 'Women' option within the Gender filter. */
    public static final By womenOption = By.xpath("//a[contains(@title, 'Silver - Women')]");
    /** Locator to verify the 'Women' text displayed after filtering. */
    public static final By verifiedWomenText = By.xpath("//span[contains(text(), 'Women')]");
    /** Locator for the 'More Filter' button. */
    public static final By moreFilterButton = By.id("myBtn");
    /** Locator for the 'Try On' filter. */
    public static final By tryOnFilter = By.id("filter_2");
    /** Locator for the 'Yes' option within the 'Try On' filter. */
    public static final By yesOption = By.xpath("//a[contains(@title, 'Silver - Yes')]");
    /** Locator for the first product displayed on the page. */
    public static final By firstProduct = By.className("tooltip_18");

}
