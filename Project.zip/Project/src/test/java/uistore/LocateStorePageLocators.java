package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: LocateStorePageLocators
 * Author: Ashwani
 * Description: UI locators for the Locate Store page.
 */
public class LocateStorePageLocators {
    /** Locator for the 'Advanced Search' section. */
    public By advancedSearchSection = By.xpath("//div[text()='Advanced Search']");
    /** Locator for the State dropdown in the store locator. */
    public By stateDropdown = By.xpath("//select[@id='OutletState']");
    /** Locator for the City dropdown in the store locator. */
    public By cityDropdown = By.xpath("//select[@id='OutletCity']");
    /** Locator for the Search button in the store locator. */
    public By searchButton = By.xpath("(//span[text()='Search'])[2]");
}
