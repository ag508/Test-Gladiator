package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: RingBuyerLocator
 * Author: Yash
 * Description: UI locators for the Ring Buyer page, focusing on product selection and checkout initiation.
 */
public class RingBuyerLocator {
	/** Locator for the product code display. */
	public By productCodeText = By.xpath("//p[contains(text(),'Product Code')]");
	/** Locator for the size selection dropdown. */
	public By sizeDropdown = By.xpath("//select[@id='item-size']");
	/** Locator for the '17mm' option within the size dropdown. */
	public By sizeOption17mm = By.xpath("//option[text()='16.5mm']");
	/** Locator for the weight selection dropdown. */
	public By weightDropdown = By.xpath(("//select[@id='item-weight']"));
	/** Locator for the '5.43g' option within the weight dropdown. */
	public By weightOption5d43g = By.xpath("//option[text()='4.019g']");
	/** Locator for the 'Buy Now' button. */
	public By buyNowButton = By.xpath("(//a[@id='btnBuyNow'])[2]");
	/** Locator for the 'Proceed To Pay' button. */
	public By proceedToPayButton = By.xpath("(//ul[@class='btns-list']//a)[1]");
}
