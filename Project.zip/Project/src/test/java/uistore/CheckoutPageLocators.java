package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: CheckoutPageLocators
 * Author: Ashwani
 * Description: UI locators for the Checkout page.
 */
public class CheckoutPageLocators { 

    /** Locator for the 'Other' link on the checkout page. */
    public By otherLink = By.xpath("//a[text()='Other']"); 
}
