package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: DropsLocator
 * Author: Aneesh
 * Description: UI locators for the Drops product category page.
 */
public class DropsLocator {
    /** Locator for the main Drops filter category. */
    public static final By dropsCategory = By.id("filter_tree");
    /** Locator for the Gold filter option. */
    public static final By goldOption = By.id("132");
    /** Locator for the Breadcrumb navigation element. */
    public static final By breadcrumbNavigation = By.id("breadcrumbNavigationLast");
    /** Locator for the general Category filter tree. */
    public static final By categoryFilter = By.id("filter_tree");
    /** Locator for the 'More Filter' button. */
    public static final By moreFilterButton = By.id("myBtn");
    /** Locator for the Metal Purity filter section. */
    public static final By metalPurityFilter = By.id("filter_5");
    /** Locator for the '22 kt' option within the Metal Purity filter. */
    public static final By karat22Option = By.xpath("//a[contains(@title, 'Gold - 22 kt')]");
    /** Locator to verify the '22 kt' text displayed after filtering. */
    public static final By karat22VerifiedText = By.xpath("//span[contains(text(), '22 kt')]");
    /** Locator for the first product displayed on the page. */
    public static final By firstProduct = By.className("tooltip_18");
}
