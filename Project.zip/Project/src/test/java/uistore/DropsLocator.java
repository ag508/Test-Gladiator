package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: DropsLocator
 * Author: Aneesh
 * Description: UI locators for the Drops product category page.
 */
public class DropsLocator {
    public static final By dropsCategory = By.id("filter_tree");
    public static final By goldOption = By.id("132");
    public static final By breadcrumbNavigation = By.id("breadcrumbNavigationLast");
    public static final By categoryFilter = By.id("filter_tree");
    public static final By moreFilterButton = By.id("myBtn");
    public static final By metalPurityFilter = By.id("filter_5");
    public static final By karat22Option = By.xpath("//a[contains(@title, 'Gold - 22 kt')]");
    public static final By karat22VerifiedText = By.xpath("//span[contains(text(), '22 kt')]");
    public static final By firstProduct = By.className("tooltip_18");
}
