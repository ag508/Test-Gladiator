package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ProductPageLocator
 * Author: Dhruv
 * Description: UI locators for product-specific elements on a product detail page.
 */
public class ProductPageLocator {
	/** Locator for the product price display. */
	public By productPrice = By.xpath("//div[contains(text(),'Price')]");
	/** Locator for the 'Add to Cart' button. */
	public By addToCartButton = By.xpath("(//a[@id='btnBuyNow'])[1]");

}
