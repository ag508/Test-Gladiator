package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ProductPageLocators
 * Author: Dhruv
 * Description: UI locators for product-related elements on various product pages.
 */
public class ProductPageLocators {
    /** Locator for the 'Add to Cart' button. */
    public By addToCartButton = By.xpath("(//a[@id='btnBuyNow'])[1]");
}
