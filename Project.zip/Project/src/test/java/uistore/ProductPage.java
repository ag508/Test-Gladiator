package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ProductPage
 * Author: Aneesh
 * Description: UI locators for a generic Product Page.
 */
public class ProductPage {
    /** Locator for the size selection dropdown. */
    public static final By sizeDropdown = By.id("item-size");
    /** Locator for the weight selection dropdown. */
    public static final By weightDropdown = By.id("item-weight");
    /** Locator for the 'Buy Now' button. */
    public static final By buyNowButton  = By.id("btnBuyNow");

}
