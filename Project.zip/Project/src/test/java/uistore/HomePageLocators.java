package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: HomePageLocators
 * Author: Team Members
 * Description: UI locators for the Home Page of the application.
 */
public class HomePageLocators{
    /** Locator for the 'About us' link. */
    public By aboutUsLink = By.xpath("//a[text()='About us ']");
    /** Locator for the 'Why Reliance Jewels' link. */
    public By whyRelianceJewelsLink = By.xpath("(//a[text()='Why Reliance Jewels'])[1]");
    /** Locator for the 'Certifications' link. */
    public By certificationLink = By.xpath("(//a[text()='Certifications'])[1]");
    /** Locator for the 'Our Showrooms' link. */
    public By showroomsLink = By.xpath("(//a[text()='Our Showrooms'])");
    /** Locator for the 'Media' link. */
    public By mediaLink = By.xpath("//a[text()='Media']");
    /** Locator for the 'Blog' link. */
    public By blogLink = By.xpath("//a[text()='Blog']");
    /** Locator for the 'FAQs' link. */
    public By faqLink = By.xpath("(//a[text()='FAQs'])[1]");
    /** Locator for the 'Track An Order' link. */
    public By trackOrderLink = By.xpath("(//a[text()='Track An Order'])");
    /** Locator for the 'Fast Shipping' text/element. */
    public By fastShippingText = By.xpath("(//a[text()='Fast Shipping'])");
    /** Locator for the 'Return & Refund Policy' link. */
    public By returnRefundPolicyLink = By.xpath("(//a[text()='Return & Refund Policy'])");
    /** Locator for the 'Shipping Policy' link. */
    public By shippingPolicyLink = By.xpath("(//a[text()='Shipping Policy'])[1]");
    /** Locator for the 'Privacy Policy' link. */
    public By privacyPolicyLink = By.xpath("(//a[text()='Privacy Policy'])[1]");
    /** Locator for the 'Old Gold Exchange Policy' link. */
    public By oldGoldExchangePolicyLink = By.xpath("(//a[text()='Old Gold Exchange Policy'])[1]");
    /** Locator for the 'Fees and Payments Policy' link. */
    public By feesPaymentsPolicyLink = By.xpath("(//a[text()='Fees and Payments Policy'])[1]");
    /** Locator for the 'Terms and Conditions' link. */
    public By termsConditionsLink = By.xpath("(//a[text()='Terms and Conditions'])[1]");
    /** Locator for the 'RelianceOne Loyalty T & C' link. */
    public By relianceOneLoyaltyLink = By.xpath("(//a[text()='RelianceOne Loyalty T & C'])[1]");
    /** Locator for the 'Disclaimer' link. */
    public By disclaimerLink = By.xpath("(//a[text()='Disclaimer'])[1]");
    /** Locator for the 'Call Back' link. */
    public By callBackLink = By.xpath("(//a[text()='Call Back'])");
    /** Locator for the search bar input field. */
    public By searchBarInput = By.xpath("//input[@id='q']");   
	/** Locator for the main logo. */
	public By logoImage = By.className("logo");
	/** Locator for the 'PENDANTS' navigation link. */
	public By pendantsNavLink = By.xpath("//a[text()='PENDANTS']");
	/** Locator for the 'Gifting' sub-category link. */
	public By giftingLink = By.xpath("(//a[text()='Gifting'])[3]");
	/** Locator for the 'Rings' navigation link. */
	public By ringsNavLink = By.xpath("//a[text()='Rings']");
	/** Locator for the 'Casual Wear' sub-category link under Rings. */
	public By casualWearLink = By.xpath("(//a[text()='Casual Wear'])[2]");    
	/** Locator for the 'Trending' link. */
	public By trendingLink = By.xpath("//a[contains(text(),'Trending')]");
    /** Locator for the 'Vivaham' link. */
    public By vivahamLink = By.xpath("//a[text()='Vivaham']");
    /** Locator for the 'Earrings' navigation link. */
    public By earringsNavLink = By.xpath("//a[text()='Earrings']");
    /** Locator for the 'Diamond' sub-category link under Earrings. */
    public By diamondEarringsLink = By.xpath("(//a[text()='Diamond'])[1]");
    /** Static locator for the 'Earrings' main category. */
    public static final By earringsCategory = By.xpath("//a[contains(text(), 'Earrings')]");
    /** Static locator for the 'Drops' sub-category. */
    public static final By dropsSubCategory = By.xpath("//a[contains(text(), 'Drops')]");
    /** Static locator for the main logo with a specific href. */
    public static final By mainLogoLocator = By.xpath("//div[@class='logo']//a[contains(@href, 'reliancejewels.com')]");
    /** Static locator for the 'Chain' category. */
    public static final By chainCategory = By.xpath("//a[contains(text(), 'Chain')]");
    /** Static locator for the 'Silver' sub-category. */
    public static final By silverSubCategory  = By.xpath("//a[contains(@href, '/category:151/')]");
}
