package runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.ChainsActions;
import pages.CheckoutPageActions;
import pages.DropsActions;
import pages.HomePageActions;
import pages.LocateStorePageActions;
import pages.NecklaceProductsPageActions;
import pages.PendantPageAction;
import pages.ProductCartPageAction;
import pages.ProductPageActions;
import pages.ProductsPageActions;
import pages.RingBuyerPageAction;
import pages.RingPageAction;
import pages.RingsProductsPageActions;
import pages.ShoppingCartActions;
import pages.VivahamPageActions;
import utils.Base;
import utils.Reporter;


@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features",
    glue = {"stepdefinitions"},
    plugin = {"pretty", "html:target/cucumber-reports.html", "json:target/cucumber.json"},
    monochrome = true
)
public class TestRunner {
    // No code needed here for Cucumber runner
}
