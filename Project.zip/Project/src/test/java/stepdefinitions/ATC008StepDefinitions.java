package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC008StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC008");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I click on {string}")
    public void i_click_on_about_us(String link) {
        homePageActions.clickOnAboutUs(extentTest);
    }

    @When("I click {string} and verify URL")
    public void i_click_and_verify_url(String linkName) {
        switch (linkName) {
            case "Why Reliance Jewels":
                homePageActions.clickWhyRelianceAndVerifyUrl(extentTest);
                break;
            case "Certifications":
                homePageActions.clickCertificationAndVerifyUrl(extentTest);
                break;
            case "Our Showrooms":
                homePageActions.clickShowroomsAndVerifyUrl(extentTest);
                break;
            case "Media":
                homePageActions.clickMediaAndVerifyUrl(extentTest);
                break;
            case "Blog":
                homePageActions.clickBlogAndVerifyUrl(extentTest);
                break;
            case "FAQs":
                homePageActions.clickFaqAndVerifyUrl(extentTest);
                break;
            case "Track An Order":
                homePageActions.clickTrackOrderAndVerifyUrl(extentTest);
                break;
            default:
                extentTest.log(Status.FAIL, "Invalid link name: " + linkName);
                break;
        }
    }

    @Then("I verify {string} section")
    public void i_verify_fast_shipping_section(String section) {
        if (section.equals("Fast Shipping")) {
            homePageActions.verifyFastShippingSection(extentTest);
        } else {
            extentTest.log(Status.FAIL, "Invalid section name: " + section);
        }
    }
} 