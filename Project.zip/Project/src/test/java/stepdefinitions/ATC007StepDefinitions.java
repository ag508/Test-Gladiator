package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ChainsActions;
import pages.HomePageActions;
import pages.ProductPageActions;
import pages.ShoppingCartActions;
import utils.Base;
import utils.Reporter;

public class ATC007StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public ChainsActions chainsActions;
    public ProductPageActions productPageActions;
    public ShoppingCartActions shoppingCartActions;
    public ExtentTest extentTest;

    @Given("I am on the home page for silver chains")
    public void i_am_on_the_home_page_for_silver_chains() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        chainsActions = new ChainsActions(driver);
        productPageActions = new ProductPageActions(driver);
        shoppingCartActions = new ShoppingCartActions(driver, extentTest);
    }

    @When("I verify the silver chains main logo link contains {string}")
    public void i_verify_the_silver_chains_main_logo_link_contains(String mainLogoLink) {
        homePageActions.verifyMainLogoLink(extentTest, mainLogoLink);
    }

    @And("I hover on chain category and click {string}")
    public void iHoverOnChainCategoryAndClick(String silverChainCategory) {
        homePageActions.clickSilverChain(extentTest, silverChainCategory);
    }

    @And("I select category {string} and gender filter")
    public void iSelectCategoryAndGenderFilter(String categoryFilterText) {
        chainsActions.selectCategoryAndGenderFilter(extentTest, categoryFilterText);
    }

    @And("I apply more filters")
    public void iApplyMoreFilters() {
        chainsActions.applyMoreFilters(extentTest);
    }

    @And("I click the first product")
    public void i_click_the_first_product() {
        chainsActions.clickFirstProduct(extentTest);
    }

    @And("I select size {string} and weight {string} dropdowns")
    public void iSelectSizeAndWeightDropdowns(String size, String weight) {
        productPageActions.selectSizeAndWeightDropdowns(extentTest, size, weight);
    }

    @Then("I click the buy now button and verify the first product text in cart {string}")
    public void iClickBuyNowButtonAndVerifyFirstProductTextInCart(String cartProductText) {
        productPageActions.clickBuyNowButton(extentTest);
        shoppingCartActions.verifyFirstProductTextAlternative(extentTest, cartProductText);
    }
} 