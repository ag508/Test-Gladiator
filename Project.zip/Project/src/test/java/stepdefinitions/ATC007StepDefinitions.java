package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ChainsActions;
import pages.HomePageActions;
import pages.ProductPageActions;
import pages.ShoppingCartActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC007StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;
    private ChainsActions chainsActions;
    private ProductPageActions productPageActions;
    private ShoppingCartActions shoppingCartActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        chainsActions = new ChainsActions(driver);
        productPageActions = new ProductPageActions(driver);
        shoppingCartActions = new ShoppingCartActions(driver, extentTest); // extentTest needs to be initialized
        extentTest = CommonHooks.extentReports.createTest("ATC007");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I verify the main logo link")
    public void i_verify_the_main_logo_link() {
        homePageActions.verifyMainLogoLink(extentTest);
    }

    @When("I click {string}")
    public void i_click_silver_chain(String link) {
        homePageActions.clickSilverChain(extentTest);
    }

    @When("I select category and gender filter")
    public void i_select_category_and_gender_filter() {
        chainsActions.selectCategoryAndGenderFilter(extentTest);
    }

    @When("I apply more filters for chains")
    public void i_apply_more_filters_for_chains() {
        chainsActions.applyMoreFilters(extentTest);
    }

    @When("I click the first product on chains page")
    public void i_click_the_first_product_on_chains_page() {
        chainsActions.clickFirstProduct(extentTest);
    }

    @When("I select size and weight dropdowns")
    public void i_select_size_and_weight_dropdowns() {
        productPageActions.selectSizeAndWeightDropdowns(extentTest);
    }

    @When("I click the buy now button on product page")
    public void i_click_the_buy_now_button_on_product_page() {
        productPageActions.clickBuyNowButton(extentTest);
    }

    @Then("I verify the first product text alternative")
    public void i_verify_the_first_product_text_alternative() {
        shoppingCartActions.verifyFirstProductTextAlternative(extentTest);
    }
} 