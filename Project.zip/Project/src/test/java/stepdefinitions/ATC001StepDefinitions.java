package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.ProductPageActions;
import pages.RingsProductsPageActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC001StepDefinitions extends Base {

    private ExtentTest extentTest; 
    private HomePageActions homePageActions;
    private RingsProductsPageActions ringsProductsPageActions;
    private ProductPageActions productPageActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        // Browser setup and navigation is handled by hooks
        homePageActions = new HomePageActions(driver);
        ringsProductsPageActions = new RingsProductsPageActions(driver);
        productPageActions = new ProductPageActions(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC001"); 
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I search for {string}")
    public void i_search_for(String searchValue) {
        homePageActions.clickSearchBarAndEnterSearchValueRings(extentTest);
    }

    @When("I verify the page title contains {string}")
    public void i_verify_the_page_title_contains(String expectedKeyword) {
        ringsProductsPageActions.verifyPageTitleContainsRingsKeyword(extentTest);
    }

    @When("I filter by gender {string}")
    public void i_filter_by_gender(String gender) {
        ringsProductsPageActions.clickGenderFilterAndSelectMen(extentTest);
    }

    @When("I filter by metal {string}")
    public void i_filter_by_metal(String metal) {
        ringsProductsPageActions.clickMetalFilterAndSelectGold(extentTest);
    }

    @When("I click on the first ring product")
    public void i_click_on_the_first_ring_product() {
        ringsProductsPageActions.clickOnFirstRingProduct(extentTest);
    }

    @Then("I add the product to cart")
    public void i_add_the_product_to_cart() {
        productPageActions.clickOnAddToCartButton(extentTest);
    }
} 