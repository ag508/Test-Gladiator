package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.ProductPageActions;
import pages.RingsProductsPageActions;
import utils.Base;
import utils.Reporter;

public class ATC001StepDefinitions extends Base {

    public HomePageActions homePageActions;
    public RingsProductsPageActions ringsProductsPageActions;
    public ProductPageActions productPageActions;
    public ExtentTest extentTest;

    @Given("I am on the home page for rings")
    public void i_am_on_the_home_page_for_rings() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        ringsProductsPageActions = new RingsProductsPageActions(driver);
        productPageActions = new ProductPageActions(driver);
    }

    @When("I search for a ring product {string}")
    public void iSearchFor(String product) {
        homePageActions.performProductSearch(extentTest, product);
    }

    @And("I verify the rings page title contain {string}")
    public void i_verify_the_rings_page_title_contain(String ringKeyword) {
        ringsProductsPageActions.verifyPageTitleContainsRingsKeyword(extentTest, ringKeyword);
    }

    @And("I filter by gender {string}")
    public void iFilterByGender(String gender) {
        ringsProductsPageActions.clickGenderFilterAndSelectMen(extentTest, gender);
    }

    @And("I filter by metal {string}")
    public void iFilterByMetal(String metal) {
        ringsProductsPageActions.clickMetalFilterAndSelectGold(extentTest, metal);
    }

    @And("I click on the first ring product")
    public void iClickOnTheFirstRingProduct() {
        ringsProductsPageActions.clickOnFirstRingProduct(extentTest);
    }

    @Then("I click on the add to cart button")
    public void iClickOnTheAddToCartButton() {
        productPageActions.clickOnAddToCartButton(extentTest);
    }
} 