package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.HomePageActions;
import pages.LocateStorePageActions;
import pages.ProductsPageActions;
import pages.VivahamPageActions;
import utils.Base;
import utils.Reporter;

public class ATC003StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public VivahamPageActions vivahamPageActions;
    public LocateStorePageActions locateStorePageActions;
    public ProductsPageActions productsPageActions;
    public ExtentTest extentTest;

    @Given("I am on the home page for vivaham")
    public void i_am_on_the_home_page_for_vivaham() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        vivahamPageActions = new VivahamPageActions(driver);
        locateStorePageActions = new LocateStorePageActions(driver);
        productsPageActions = new ProductsPageActions(driver);
    }

    @And("I hover on What Trending")
    public void iHoverOnWhatTrending() {
        homePageActions.hoverOnWhatsTrending(extentTest);
    }

    @And("I click on the Vivaham link and switch window")
    public void iClickOnVivahamLinkAndSwitchWindow() {
        homePageActions.clickVivahamLinkAndSwitchWindow(extentTest);
    }

    @And("I verify the vivaham URL contains {string}")
    public void i_verify_the_vivaham_url_contains(String vivahamUrlKeyword) {
        homePageActions.verifyVivahamUrl(extentTest, vivahamUrlKeyword);
    }

    @And("I click the Locate Store button")
    public void iClickTheLocateStoreButton() {
        vivahamPageActions.clickLocateStoreButton(extentTest);
    }

    @And("I select {string} from the state dropdown")
    public void iSelectStateFromDropdown(String state) {
        locateStorePageActions.selectStateFromDropdown(extentTest, state);
    }

    @And("I select {string} from the city dropdown")
    public void iSelectCityFromDropdown(String city) {
        locateStorePageActions.selectCityFromDropdown(extentTest, city);
    }

    @And("I verify the URL contains {string}")
    public void iVerifyUrlContains(String storeLocatorKeyword) {
        locateStorePageActions.verifyUrlContainsStoreLocator(extentTest, storeLocatorKeyword);
    }

    @And("I click the search button and switch to parent window")
    public void iClickSearchButtonAndSwitchToParentWindow() {
        locateStorePageActions.clickSearchButtonAndSwitchToParentWindow(extentTest);
    }

    @And("I click the Delhi option")
    public void iClickDelhiOption() {
        vivahamPageActions.clickDelhiOption(extentTest);
    }

    @Then("I verify the Sort By filter label is {string}")
    public void iVerifySortByFilterLabel(String sortByLabel) {
        productsPageActions.verifySortByFilterLabel(extentTest, sortByLabel);
    }
} 