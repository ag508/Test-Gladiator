package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.VivahamPageActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC003StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;
    private VivahamPageActions vivahamPageActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        vivahamPageActions = new VivahamPageActions(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC003");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I hover on {string}")
    public void i_hover_on_whats_trending(String section) {
        homePageActions.hoverOnWhatsTrending(extentTest);
    }

    @When("I click {string} link and switch window")
    public void i_click_vivaham_link_and_switch_window(String link) {
        homePageActions.clickVivahamLinkAndSwitchWindow(extentTest);
    }

    @When("I verify the Vivaham URL")
    public void i_verify_the_vivaham_url() {
        homePageActions.verifyVivahamUrl(extentTest);
    }

    @Then("I click the {string} button")
    public void i_click_the_locate_store_button(String button) {
        vivahamPageActions.clickLocateStoreButton(extentTest);
    }
} 