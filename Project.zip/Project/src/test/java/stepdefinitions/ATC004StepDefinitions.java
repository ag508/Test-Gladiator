package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.CheckoutPageActions;
import pages.HomePageActions;
import pages.ProductsPageActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC004StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;
    private ProductsPageActions productsPageActions;
    private CheckoutPageActions checkoutPageActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        productsPageActions = new ProductsPageActions(driver);
        checkoutPageActions = new CheckoutPageActions(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC004");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I hover on {string} category")
    public void i_hover_on_earrings_category(String category) {
        homePageActions.hoverOnEarringsCategory(extentTest);
    }

    @When("I click on {string} earrings sub-category")
    public void i_click_on_diamond_earrings_sub_category(String subCategory) {
        homePageActions.clickOnDiamondEarringsSubCategory(extentTest);
    }

    @When("I verify {string} keyword")
    public void i_verify_diamond_keyword(String keyword) {
        productsPageActions.verifyDiamondKeyword(extentTest);
    }

    @When("I click on {string} under gender filter")
    public void i_click_on_women_under_gender_filter(String gender) {
        productsPageActions.clickOnWomenUnderGender(extentTest);
    }

    @When("I hover on {string} filter")
    public void i_hover_on_popularity_filter(String filter) {
        productsPageActions.hoverOnPopularityFilter(extentTest);
    }

    @When("I click on {string} filter")
    public void i_click_on_new_arrivals_filter(String filter) {
        productsPageActions.clickOnNewArrivalsFilter(extentTest);
    }

    @When("I click on the first product")
    public void i_click_on_the_first_product() {
        productsPageActions.clickOnFirstProduct(extentTest);
    }

    @When("I verify {string} keyword")
    public void i_verify_earring_keyword(String keyword) {
        productsPageActions.verifyEarringKeyword(extentTest);
    }

    @When("I click {string} button")
    public void i_click_add_to_cart_button(String button) {
        productsPageActions.clickAddToCartButton(extentTest);
    }

    @Then("I verify {string} keyword and attach screenshot")
    public void i_verify_other_keyword_and_attach_screenshot(String keyword) {
        checkoutPageActions.verifyOtherKeywordAndAttachScreenshot(extentTest);
    }
} 