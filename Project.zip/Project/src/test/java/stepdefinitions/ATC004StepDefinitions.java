package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.ProductsPageActions;
import pages.CheckoutPageActions;
import utils.Base;
import utils.Reporter;

public class ATC004StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public ProductsPageActions productsPageActions;
    public CheckoutPageActions checkoutPageActions;
    public ExtentTest extentTest;

    @Given("I am on the home page for earrings")
    public void i_am_on_the_home_page_for_earrings() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        productsPageActions = new ProductsPageActions(driver);
        checkoutPageActions = new CheckoutPageActions(driver);
    }

    @When("I hover on the {string} category")
    public void iHoverOnTheCategory(String category) {
        homePageActions.hoverOnEarringsCategory(extentTest, category);
    }

    @And("I click on the {string} sub-category")
    public void iClickOnTheSubCategory(String subcategory) {
        homePageActions.clickOnDiamondEarringsSubCategory(extentTest, subcategory);
    }

    @And("I verify the diamond {string} keyword")
    public void i_verify_the_diamond_keyword(String diamondKeyword) {
        productsPageActions.verifyDiamondKeyword(extentTest, diamondKeyword);
    }

    @And("I click on {string} under gender filter")
    public void iClickOnUnderGenderFilter(String gender) {
        productsPageActions.clickOnWomenUnderGender(extentTest, gender);
    }

    @And("I hover on the {string} filter")
    public void iHoverOnTheFilter(String filterType) {
        productsPageActions.hoverOnPopularityFilter(extentTest, filterType);
    }

    @And("I click on {string} filter")
    public void iClickOnFilter(String arrivalType) {
        productsPageActions.clickOnNewArrivalsFilter(extentTest, arrivalType);
    }

    @And("I click on the first product")
    public void iClickOnTheFirstProduct() {
        productsPageActions.clickOnFirstProduct(extentTest);
    }

    @And("I verify the earring {string} keyword")
    public void i_verify_the_earring_keyword(String earringKeyword) {
        productsPageActions.verifyEarringKeyword(extentTest, earringKeyword);
    }

    @Then("I click the add to cart button and verify {string}")
    public void iClickAddToCartButtonAndVerify(String otherKeyword) {
        productsPageActions.clickAddToCartButton(extentTest);
        checkoutPageActions.verifyOtherKeywordAndAttachScreenshot(extentTest, otherKeyword);
    }


} 