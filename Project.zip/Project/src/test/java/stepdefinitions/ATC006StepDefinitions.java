package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.RingBuyerPageAction;
import pages.RingPageAction;
import utils.Base;
import utils.Reporter;

public class ATC006StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public RingPageAction ringPageAction;
    public RingBuyerPageAction ringBuyerPageAction;
    public ExtentTest extentTest;

    @Given("I am on the home page for rings products")
    public void i_am_on_the_home_page_for_rings_products() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        ringPageAction = new RingPageAction(driver);
        ringBuyerPageAction = new RingBuyerPageAction(driver);
    }

    @When("I hover on rings {string} and click {string}")
    public void iHoverOnAndClick(String ringsCategory, String casualWearSubcategory) {
        homePageActions.hoverOnRingsAndClickCasualWear(extentTest, ringsCategory, casualWearSubcategory);
    }

    @And("I perform ring page actions with url {string}")
    public void iPerformRingPageActions(String expectedUrl) {
        ringPageAction.performRingPageActions(extentTest, expectedUrl);
    }

    @Then("I buy product with code {string}")
    public void iBuyProductWithCode(String productCode) {
        ringBuyerPageAction.buyProduct(extentTest, productCode);
    }
} 