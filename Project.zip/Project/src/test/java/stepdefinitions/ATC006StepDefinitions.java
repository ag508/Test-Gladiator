package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.RingPageAction;
import pages.RingBuyerPageAction;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC006StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;
    private RingPageAction ringPageAction;
    private RingBuyerPageAction ringBuyerPageAction;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        ringPageAction = new RingPageAction(driver);
        ringBuyerPageAction = new RingBuyerPageAction(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC006");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I hover on {string} and click {string}")
    public void i_hover_on_rings_and_click_casual_wear(String category, String subCategory) {
        homePageActions.hoverOnRingsAndClickCasualWear(extentTest);
    }

    @When("I perform ring page actions")
    public void i_perform_ring_page_actions() {
        ringPageAction.performRingPageActions(extentTest);
    }

    @Then("I buy the product")
    public void i_buy_the_product() {
        ringBuyerPageAction.buyProduct(extentTest);
    }
} 