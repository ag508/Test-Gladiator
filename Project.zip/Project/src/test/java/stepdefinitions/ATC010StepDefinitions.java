package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.PendantPageAction;
import pages.ProductCartPageAction;
import utils.Base;
import utils.Reporter;

public class ATC010StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public PendantPageAction pendantPageAction;
    public ProductCartPageAction productCartPageAction;
    public ExtentTest extentTest;

    @Given("I am on the home page for pendants")
    public void i_am_on_the_home_page_for_pendants() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        pendantPageAction = new PendantPageAction(driver);
        productCartPageAction = new ProductCartPageAction(driver);
    }

    @When("I hover on {string} and click {string}")
    public void iHoverOnAndClick(String pendantsCategory, String giftingSubcategory) {
        homePageActions.hoverOnPendantsAndClickGifting(extentTest, pendantsCategory, giftingSubcategory);
    }

    @And("I perform pendant page actions and verify URL contains {string}")
    public void iPerformPendantPageActionsAndVerifyUrlContains(String pendantPageUrlKeyword) {
        pendantPageAction.performPendantPageActions(extentTest, pendantPageUrlKeyword);
    }

    @Then("I verify the product price contains {string} and add to cart")
    public void iVerifyProductPriceContainsAndAddToCart(String productPriceKeyword) {
        productCartPageAction.verifyPriceAndAddToCart(extentTest, productPriceKeyword);
    }
} 