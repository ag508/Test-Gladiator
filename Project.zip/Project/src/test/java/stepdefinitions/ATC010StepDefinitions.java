package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.PendantPageAction;
import pages.ProductCartPageAction;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC010StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;
    private PendantPageAction pendantPageAction;
    private ProductCartPageAction productCartPageAction;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        pendantPageAction = new PendantPageAction(driver);
        productCartPageAction = new ProductCartPageAction(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC010");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I hover on {string} and click {string}")
    public void i_hover_on_pendants_and_click_gifting(String category, String subCategory) {
        homePageActions.hoverOnPendantsAndClickGifting(extentTest);
    }

    @When("I perform pendant page actions")
    public void i_perform_pendant_page_actions() {
        pendantPageAction.performPendantPageActions(extentTest);
    }

    @Then("I verify price and add product to cart")
    public void i_verify_price_and_add_product_to_cart() {
        productCartPageAction.verifyPriceAndAddToCart(extentTest);
    }
} 