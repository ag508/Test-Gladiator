package stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils.Base;
import utils.LoggerHandler;
import utils.Reporter;
import com.aventstack.extentreports.ExtentReports;

public class CommonHooks extends Base {

    public static ExtentReports extentReports;

    @Before
    public void setup() {
        if (extentReports == null) {
            extentReports = Reporter.generateReport();
        }
        openBrowser();
        LoggerHandler.info("Browser opened and initialized.");
    }

    @After
    public void teardown() {
        if (driver != null) {
            driver.quit();
            LoggerHandler.info("Browser closed.");
        }
        if (extentReports != null) {
            extentReports.flush();
            LoggerHandler.info("Extent Report flushed.");
        }
    }
} 