package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.NecklaceProductsPageActions;
import utils.Base;
import utils.Reporter;

public class ATC002StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public NecklaceProductsPageActions necklaceProductsPageActions;
    public ExtentTest extentTest;

    @Given("I am on the home page for necklaces")
    public void i_am_on_the_home_page_for_necklaces() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        necklaceProductsPageActions = new NecklaceProductsPageActions(driver);
    }

    @When("I search for a necklace product {string}")
    public void iSearchFor(String product) {
        homePageActions.performProductSearch(extentTest, product);
    }

    @And("I verify the necklaces page title contains {string}")
    public void i_verify_the_necklaces_page_title_contains(String necklaceKeyword) {
        necklaceProductsPageActions.verifyPageTitleContainsNecklaceKeyword(extentTest, necklaceKeyword);
    }

    @And("I hover on the first necklace product and click quick view")
    public void iHoverOnFirstNecklaceAndClickQuickView() {
        necklaceProductsPageActions.hoverOnFirstNecklaceAndClickQuickView(extentTest);
    }

    @And("I click the cross button")
    public void iClickTheCrossButton() {
        necklaceProductsPageActions.clickCrossButton(extentTest);
    }

    @And("I click on the first available product")
    public void iClickOnTheFirstAvailableProduct() {
        necklaceProductsPageActions.clickOnFirstAvailableProduct(extentTest);
    }

    @And("I select the first weight option")
    public void iSelectTheFirstWeightOption() {
        necklaceProductsPageActions.selectFirstWeightOption(extentTest);
    }

    @Then("I click the buy now button")
    public void iClickTheBuyNowButton() {
        necklaceProductsPageActions.clickBuyNowButton(extentTest);
    }
} 