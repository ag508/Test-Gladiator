package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import pages.NecklaceProductsPageActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC002StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;
    private NecklaceProductsPageActions necklaceProductsPageActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        necklaceProductsPageActions = new NecklaceProductsPageActions(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC002");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I search for {string}")
    public void i_search_for(String searchValue) {
        homePageActions.clickSearchBarAndEnterSearchValueNecklace(extentTest);
    }

    @When("I verify the page title contains {string}")
    public void i_verify_the_page_title_contains(String expectedKeyword) {
        necklaceProductsPageActions.verifyPageTitleContainsNecklaceKeyword(extentTest);
    }

    @When("I hover on the first necklace and click quick view")
    public void i_hover_on_the_first_necklace_and_click_quick_view() {
        necklaceProductsPageActions.hoverOnFirstNecklaceAndClickQuickView(extentTest);
    }

    @When("I click the cross button")
    public void i_click_the_cross_button() {
        necklaceProductsPageActions.clickCrossButton(extentTest);
    }

    @When("I click on the first available necklace product")
    public void i_click_on_the_first_available_necklace_product() {
        necklaceProductsPageActions.clickOnFirstAvailableProduct(extentTest);
    }

    @When("I select the first weight option")
    public void i_select_the_first_weight_option() {
        necklaceProductsPageActions.selectFirstWeightOption(extentTest);
    }

    @Then("I click the buy now button")
    public void i_click_the_buy_now_button() {
        necklaceProductsPageActions.clickBuyNowButton(extentTest);
    }
} 