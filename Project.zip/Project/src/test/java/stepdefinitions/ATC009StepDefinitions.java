package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC009StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        extentTest = CommonHooks.extentReports.createTest("ATC009");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I click {string}")
    public void i_click(String policyName) {
        switch (policyName) {
            case "Return & Refund Policy":
                homePageActions.clickReturnRefundPolicy(extentTest);
                break;
            case "Shipping Policy":
                homePageActions.clickShippingPolicy(extentTest);
                break;
            case "Privacy Policy":
                homePageActions.clickPrivacyPolicy(extentTest);
                break;
            case "Old Gold Exchange Policy":
                homePageActions.clickOldGoldExchangePolicy(extentTest);
                break;
            case "Fees and Payments Policy":
                homePageActions.clickFeesAndPaymentsPolicy(extentTest);
                break;
            case "Terms and Conditions":
                homePageActions.clickTermsAndConditions(extentTest);
                break;
            case "RelianceOne Loyalty T & C":
                homePageActions.clickRelianceOneLoyaltyTermsAndConditions(extentTest);
                break;
            default:
                extentTest.log(Status.FAIL, "Invalid policy name: " + policyName);
                break;
        }
    }

    @When("I click {string} and verify URL")
    public void i_click_disclaimer_and_verify_url(String linkName) {
        if (linkName.equals("Disclaimer")) {
            homePageActions.clickDisclaimerAndVerifyUrl(extentTest);
        } else {
            extentTest.log(Status.FAIL, "Invalid link name for URL verification: " + linkName);
        }
    }

    @Then("I verify {string} section")
    public void i_verify_call_back_section(String section) {
        if (section.equals("Call Back")) {
            homePageActions.verifyCallBackSection(extentTest);
        } else {
            extentTest.log(Status.FAIL, "Invalid section name: " + section);
        }
    }
} 