package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.DropsActions;
import pages.HomePageActions;
import pages.ProductPageActions;
import pages.ShoppingCartActions;
import utils.Base;
import utils.Reporter;

public class ATC005StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public DropsActions dropsActions;
    public ProductPageActions productPageActions;
    public ShoppingCartActions shoppingCartActions;
    public ExtentTest extentTest;

    @Given("I am on the home page for drops")
    public void i_am_on_the_home_page_for_drops() {
        extentTest = Reporter.reports.createTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        homePageActions = new HomePageActions(driver);
        dropsActions = new DropsActions(driver);
        productPageActions = new ProductPageActions(driver);
        shoppingCartActions = new ShoppingCartActions(driver, extentTest);
    }

    @When("I hover on Earrings {string} and click {string}")
    public void iHoverOnAndClick(String earringsCategory, String dropsSubcategory) {
        homePageActions.hoverOnEarringsAndClickDrops(extentTest, earringsCategory, dropsSubcategory);
    }

    @And("I verify the drops page URL contains {string}")
    public void i_verify_the_drops_page_url_contains(String pageUrlKeyword) {
        dropsActions.verifyPageUrl(extentTest, pageUrlKeyword);
    }

    @And("I click category and {string} filters")
    public void iClickCategoryAndMetalFilters(String metalFilter) {
        dropsActions.clickCategoryAndGoldFilters(extentTest, metalFilter);
    }

    @And("I verify the breadcrumb filter text is {string}")
    public void iVerifyBreadcrumbFilterTextIs(String breadcrumbText) {
        dropsActions.verifyBreadcrumbFilterText(extentTest, breadcrumbText);
    }

    @And("I apply metal purity filter {string}")
    public void iApplyMetalPurityFilter(String purityFilter) {
        dropsActions.applyMetalPurityFilter(extentTest, purityFilter);
    }

    @And("I verify the metal purity filter text is {string}")
    public void iVerifyMetalPurityFilterTextIs(String purityTextVerified) {
        dropsActions.verifyMetalPurityFilterText(extentTest, purityTextVerified);
    }

    @And("I click the first product on page")
    public void i_click_the_first_product_on_page() {
        dropsActions.clickFirstProduct(extentTest);
    }

    @And("I click the buy button")
    public void iClickTheBuyButton() {
        productPageActions.clickBuyNowButton(extentTest);
    }

    @Then("I verify the first product text in cart and proceed {string}")
    public void iVerifyFirstProductTextInCartAndProceed(String cartProductText) {
        shoppingCartActions.verifyFirstProductTextAndProceed(extentTest, cartProductText);
    }
} 