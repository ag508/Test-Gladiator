package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.DropsActions;
import pages.HomePageActions;
import pages.ProductPageActions;
import pages.ShoppingCartActions;
import utils.Base;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ATC005StepDefinitions extends Base {

    private ExtentTest extentTest;
    private HomePageActions homePageActions;
    private DropsActions dropsActions;
    private ProductPageActions productPageActions;
    private ShoppingCartActions shoppingCartActions;

    @Given("I am on the home page")
    public void i_am_on_the_home_page() {
        homePageActions = new HomePageActions(driver);
        dropsActions = new DropsActions(driver);
        productPageActions = new ProductPageActions(driver);
        shoppingCartActions = new ShoppingCartActions(driver, extentTest); // extentTest needs to be initialized
        extentTest = CommonHooks.extentReports.createTest("ATC005");
        extentTest.log(Status.INFO, "Navigated to home page.");
    }

    @When("I hover on {string} and click {string}")
    public void i_hover_on_earrings_and_click_drops(String category, String subCategory) {
        homePageActions.hoverOnEarringsAndClickDrops(extentTest);
    }

    @When("I verify the page URL for {string}")
    public void i_verify_the_page_url_for_drops(String page) {
        dropsActions.verifyPageUrl(extentTest);
    }

    @When("I click category and gold filters")
    public void i_click_category_and_gold_filters() {
        dropsActions.clickCategoryAndGoldFilters(extentTest);
    }

    @When("I verify breadcrumb filter text")
    public void i_verify_breadcrumb_filter_text() {
        dropsActions.verifyBreadcrumbFilterText(extentTest);
    }

    @When("I apply metal purity filter")
    public void i_apply_metal_purity_filter() {
        dropsActions.applyMetalPurityFilter(extentTest);
    }

    @When("I verify metal purity filter text")
    public void i_verify_metal_purity_filter_text() {
        dropsActions.verifyMetalPurityFilterText(extentTest);
    }

    @When("I click the first product on drops page")
    public void i_click_the_first_product_on_drops_page() {
        dropsActions.clickFirstProduct(extentTest);
    }

    @When("I click the buy now button on product page")
    public void i_click_the_buy_now_button_on_product_page() {
        productPageActions.clickBuyNowButton(extentTest);
    }

    @Then("I verify the first product text and proceed")
    public void i_verify_the_first_product_text_and_proceed() {
        shoppingCartActions.verifyFirstProductTextAndProceed(extentTest);
    }
} 