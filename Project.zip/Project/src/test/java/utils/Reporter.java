package utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.io.Files;

public class Reporter {
    public static ExtentReports reports;
    public static ExtentTest test;
    private static Properties properties;

    static {
        try {
            properties = new Properties();
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/config/config.properties");
            properties.load(fis);
            fis.close();
        } catch (IOException e) {
            LoggerHandler.error("Failed to load config.properties in Reporter: " + e.getMessage());
        }
    }
    
    /**
     * Method Name: generateReport
     * Author: AI Assistant
     * Short Description: Generates and initializes the ExtentReports for test reporting. The report file path is read from config.properties.
     * Return Type: ExtentReports
     * Parameter List: None
     */
    public static ExtentReports generateReport(){
        String reportPath = properties.getProperty("extentReportPath");
        File reportFile = new File(reportPath);
        ExtentSparkReporter spark = new ExtentSparkReporter(reportFile);
        reports = new ExtentReports();
        reports.attachReporter(spark);
        LoggerHandler.info("Extent Report initialized at: " + reportPath);
        return reports;
    }

    /**
     * Method Name: flushReport
     * Author: AI Assistant
     * Short Description: Flushes the ExtentReports, writing all buffered data to the report file.
     * Return Type: void
     * Parameter List: None
     */
    public void flushReport(){
        if (reports != null) {
            reports.flush();
            LoggerHandler.info("Extent Report flushed.");
        } else {
            LoggerHandler.warn("ExtentReports object is null, cannot flush report.");
        }
    }

    /**
     * Method Name: createTest
     * Author: AI Assistant
     * Short Description: Creates a new test entry in the ExtentReports.
     * Return Type: void
     * Parameter List: String testMessage (The name/description of the test)
     */
    public void createTest(String testMessage){
        test = reports.createTest(testMessage);
        LoggerHandler.info("Created new test: " + testMessage);
    }

    /**
     * Method Name: captureScreenshotWithTimeStamp
     * Author: AI Assistant
     * Short Description: Captures a screenshot with a timestamp and saves it to the reports directory. The directory path is read from config.properties.
     * Return Type: String (Absolute path of the saved screenshot)
     * Parameter List: String fileName (Base name for the screenshot file)
     */
    public static String captureScreenshotWithTimeStamp(String fileName){
        try{
            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            File screenshotFile = ((TakesScreenshot) Base.driver).getScreenshotAs(OutputType.FILE);
            String screenshotDirPath = properties.getProperty("errorScreenshotsPath");
            File screenshotDir = new File(screenshotDirPath);
            if(!screenshotDir.exists()){
                screenshotDir.mkdirs();
                LoggerHandler.info("Created screenshot directory: " + screenshotDirPath);
            }
            String screenshotPath = screenshotDirPath + fileName + "_" + timeStamp + ".png";
            File destinationFile = new File(screenshotPath);
            FileUtils.copyFile(screenshotFile, destinationFile);
            LoggerHandler.info("Screenshot captured with timestamp: " + screenshotPath);
            return destinationFile.getAbsolutePath();

        }catch(Exception e){
            LoggerHandler.error("Failed to capture screenshot with timestamp: " + e.getMessage());
            return null;
        }
    }

    /**
     * Method Name: takeScreenshot
     * Author: AI Assistant
     * Short Description: Captures a screenshot and saves it to the reports directory. The directory path is derived from config.properties.
     * Return Type: String (Relative path of the saved screenshot)
     * Parameter List: String fileName (Name for the screenshot file)
     */
    public static String takeScreenshot(String fileName){
        String screenshotDirPath = properties.getProperty("errorScreenshotsPath");
        String destinationPath = screenshotDirPath + fileName + ".png";
        try{
            File screenshotFile = ((TakesScreenshot) Base.driver).getScreenshotAs(OutputType.FILE);
            File screenshotDir = new File(screenshotDirPath);
            if(!screenshotDir.exists()){
                screenshotDir.mkdirs();
                LoggerHandler.info("Created screenshot directory: " + screenshotDirPath);
            }
            File destinationFile = new File(destinationPath);
            FileUtils.copyFile(screenshotFile, destinationFile);
            LoggerHandler.info("Screenshot taken: " + destinationPath);
        }catch(Exception e){
            LoggerHandler.error("Failed to take screenshot: " + e.getMessage());
        }
        return destinationPath;
    }
    
    /**
     * Method Name: captureScreenShot
     * Author: AI Assistant
     * Short Description: Captures a screenshot with a timestamp and saves it to the reports directory.
     * Return Type: String (Relative path of the saved screenshot)
     * Parameter List: String filename (Base name for the screenshot file)
     */
    public static String captureScreenShot(String filename){
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        String name = filename + "_" + timeStamp + ".png";
        String screenshotDirPath = properties.getProperty("errorScreenshotsPath");
        File screenshotFile = ((TakesScreenshot) Base.driver).getScreenshotAs(OutputType.FILE);

        File screenshotDir = new File(screenshotDirPath);

        if(!screenshotDir.exists()){
            screenshotDir.mkdirs();
            LoggerHandler.info("Created screenshot directory: " + screenshotDirPath);
        }

        File targetFile = new File(screenshotDir, name);
        try{
            Files.copy(screenshotFile, targetFile);
            LoggerHandler.info("Screenshot captured: " + targetFile.getAbsolutePath());
        }catch(Exception e){
            LoggerHandler.error("Failed to capture screenshot: " + e.getMessage());
        }
        return targetFile.getAbsolutePath();

    }

    /**
     * Method Name: attachScreenshotToReport
     * Author: AI Assistant
     * Short Description: Attaches a screenshot to the Extent report.
     * Return Type: void
     * Parameter List: String filename (Path of the screenshot file), ExtentTest test (The ExtentTest object), String description (Description for the screenshot in the report)
     */
    public static void attachScreenshotToReport(String filename, ExtentTest test, String description){
        try{
            if (test != null) {
                test.log(Status.INFO, MediaEntityBuilder.createScreenCaptureFromPath(filename, description).build());
                LoggerHandler.info("Screenshot attached to report: " + filename + " with description: " + description);
            } else {
                LoggerHandler.warn("ExtentTest object is null, cannot attach screenshot to report.");
            }
        }catch(Exception e){
            LoggerHandler.error("Failed to attach screenshot to report: " + e.getMessage());
        }
    }
    
    /**
     * Method Name: captureScreenshotAsBase64
     * Author: AI Assistant
     * Short Description: Captures a screenshot and encodes it as a Base64 string, also saves it to a file.
     * Return Type: String (Base64 encoded string of the screenshot)
     * Parameter List: WebDriver driver (The WebDriver instance), String screenshotName (Name for the screenshot file)
     */
    public static String captureScreenshotAsBase64(WebDriver driver, String screenshotName) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
        TimeZone istTimeZone = TimeZone.getTimeZone("Asia/Kolkata"); // IST timezone
        dateFormat.setTimeZone(istTimeZone);
        String timeStamp = dateFormat.format(new Date());
 
        TakesScreenshot screenshotDriver = (TakesScreenshot) driver;
        byte[] screenshotBytes = screenshotDriver.getScreenshotAs(OutputType.BYTES);
 
        String base64Screenshot = "";
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(screenshotBytes);
            base64Screenshot = Base64.getEncoder().encodeToString(baos.toByteArray());
            LoggerHandler.info("Screenshot captured as Base64 for: " + screenshotName);
 
            // Save the screenshot to a file for reference
            saveScreenshotToFile(screenshotBytes, screenshotName + "_" + timeStamp + ".png");
        } catch (IOException e) {
            LoggerHandler.error("Failed to capture screenshot as Base64: " + e.getMessage());
        }
 
        return base64Screenshot;
    }
    
    /**
     * Method Name: saveScreenshotToFile
     * Author: AI Assistant
     * Short Description: Saves the given screenshot bytes to a file in the errorScreenshots directory. The directory path is read from config.properties.
     * Return Type: String (Absolute path of the saved screenshot file)
     * Parameter List: byte[] screenshotBytes (Byte array of the screenshot), String fileName (Name for the screenshot file)
     */
    private static String saveScreenshotToFile(byte[] screenshotBytes, String fileName) {
        String screenshotsDirPath = properties.getProperty("errorScreenshotsPath");
 
        try {
            File screenshotsDir = new File(screenshotsDirPath);
            if (!screenshotsDir.exists())
             {
                screenshotsDir.mkdirs();
                LoggerHandler.info("Created error screenshots directory: " + screenshotsDirPath);
            }
 
            String destinationScreenshotPath = screenshotsDirPath + fileName;
            FileOutputStream outputStream = new FileOutputStream(destinationScreenshotPath);
            outputStream.write(screenshotBytes);
            outputStream.close();
            LoggerHandler.info("Screenshot saved to file: " + destinationScreenshotPath);
        }
        catch (IOException e) {
            LoggerHandler.error("Failed to save screenshot to file: " + e.getMessage());
        }
        String destinationScreenshotPath = screenshotsDirPath + fileName;
 
        return destinationScreenshotPath;
    }

}
