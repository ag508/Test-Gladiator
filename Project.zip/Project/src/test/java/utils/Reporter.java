package utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class Reporter extends Base {
    public static ExtentReports reports;
    private static String reportPath;

    public static ExtentReports generateReport() {
        if (reports == null) {
            String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            reportPath = System.getProperty("user.dir") + "/reports/Reliance_Report_" + timestamp + ".html";
            
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
            sparkReporter.config().setDocumentTitle("Reliance Jewels Automation Report");
            sparkReporter.config().setReportName("Test Execution Report");
            sparkReporter.config().setTheme(Theme.STANDARD);
            
            reports = new ExtentReports();
            reports.attachReporter(sparkReporter);
            reports.setSystemInfo("Host Name", "Local Host");
            reports.setSystemInfo("Environment", "QA");
            reports.setSystemInfo("User", System.getProperty("user.name"));
        }
        return reports;
    }

    public static String captureScreenShot(String fileName) {
        String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        String screenshotPath = System.getProperty("user.dir") + "/reports/errorScreenshots/" + fileName + "_" + timestamp + ".png";
        
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            File destination = new File(screenshotPath);
            FileUtils.copyFile(source, destination);
        } catch (IOException e) {
            LoggerHandler.error("Failed to capture screenshot: " + e.getMessage());
        }
        return screenshotPath;
    }

    public static void attachScreenshotToReport(String screenshotPath, ExtentTest test, String title) {
        if (test != null && screenshotPath != null) {
            try {
                File screenshotFile = new File(screenshotPath);
                if (screenshotFile.exists()) {
                    test.info(title, MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
                } else {
                    LoggerHandler.error("Screenshot file not found: " + screenshotPath);
                }
            } catch (Exception e) {
                LoggerHandler.error("Failed to attach screenshot to report: " + e.getMessage());
            }
        } else {
            LoggerHandler.error("Cannot attach screenshot: test or screenshotPath is null");
        }
    }

    public static ExtentTest createTest(String testName) {
        if (reports == null) {
            generateReport();
        }
        return reports.createTest(testName);
    }

    public static void flushReport() {
        if (reports != null) {
            reports.flush();
        }
    }
}
