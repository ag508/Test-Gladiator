package utils;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
 
public class HighLightActionUtil {
    public  WebDriver driver;
   
    public HighLightActionUtil(WebDriver driver) {
        this.driver = driver;
        }
   
    //to call this method functionality, call the method highlightElement wherever we need to highlight,
    //then call the screenshot function,
    //then call the unhighlightElement Method
   
   
    public void highlightElement(By locators) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style', 'border: 2px solid blue;');", driver.findElement(locators));
       
    }
   
    public void unhighlightElement(By locators){
       JavascriptExecutor js = (JavascriptExecutor) driver;
       js.executeScript("arguments[0].setAttribute('style', '');", driver.findElement(locators));
    }
}