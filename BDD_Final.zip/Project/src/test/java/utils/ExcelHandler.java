package utils;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
 
public class ExcelHandler {
    public static String cellValue;
    private static Properties properties;
 
    static {
        try {
            properties = new Properties();
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/config/config.properties");
            properties.load(fis);
            fis.close();
        } catch (IOException e) {
            LoggerHandler.error("Failed to load config.properties in ExcelHandler: " + e.getMessage());
        }
    }
    public static String readData(int sheetNum, int rowNum, int cellNum)
    {
        try{
            FileInputStream fis = new FileInputStream(properties.getProperty("excelFilePath"));
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sheet = wb.getSheetAt(sheetNum);
            XSSFRow row = sheet.getRow(rowNum);
            XSSFCell cell = row.getCell(cellNum);
            cellValue = cell.getStringCellValue();
            wb.close();
            fis.close();
        }
        catch(Exception e){
            LoggerHandler.error("Failed to read Excel data: " + e.getMessage());
        }        
        return cellValue;
    }
   
    public static void writedata(String filepath, String sheetname, int rownumber, int colnumber, String data,boolean createSheetIfMissing, boolean createRowIfMissing) throws IOException {
        FileInputStream file = null;
        XSSFWorkbook workbook = null;
        FileOutputStream outFile = null;
        try {
            file = new FileInputStream(filepath);
            workbook = new XSSFWorkbook(file);
           
            XSSFSheet sheet = workbook.getSheet(sheetname);
            if (sheet == null) {
                if (createSheetIfMissing) {
                    sheet = workbook.createSheet(sheetname);
                } else {
                    throw new IllegalArgumentException("Sheet '" + sheetname + "' does not exist and createSheetIfMissing is false");
                }
            }
           
            XSSFRow row = sheet.getRow(rownumber);
            if (row == null) {
                if (createRowIfMissing) {
                    row = sheet.createRow(rownumber);
                } else {
                    throw new IllegalArgumentException("Row " + rownumber + " does not exist and createRowIfMissing is false");
                }
            }
           
            XSSFCell cell = row.createCell(colnumber);
            cell.setCellValue(data);
           
            outFile = new FileOutputStream(filepath);
            workbook.write(outFile);
        }
        catch(Exception e) {
            LoggerHandler.error("Failed to write Excel data: " + e.getMessage());
        }
        finally {
            if (file != null) {
                file.close();
            }
            if (outFile != null) {
                outFile.close();
            }
            if (workbook != null) {
                workbook.close();
            }
        }
    }
}