package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: ProductsPageLocators
 * Author: Ashwani
 * Description: UI locators for the Products listing page.
 */
public class ProductsPageLocators {
    public By sortFilterSection = By.xpath("//div[@class='sortsection']/p");
    public By diamondBreadcrumbText = By.xpath("//span[@id='breadcrumbNavigationLast']");
    public By genderFilter = By.xpath("//div[text()='Gender']");
    public By womenOption = By.xpath("//a[text()=' Women ']");
    public By popularityOption = By.xpath("//button[text()='Popularity']");
    public By newArrivalsOption = By.xpath("//a[contains(text(),'New')]");
    public By firstProduct = By.xpath("(//p[@class='product_title']/a)[1]");
    public By earringsText = By.xpath("(//span[text()='Earrings'])[1]");
    public By addToCartButton = By.xpath("(//div[@id='btnBuyNowC']/a)[1]");
}