package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: HomePageLocators
 * Author: Team Members
 * Description: UI locators for the Home Page of the application.
 */
public class HomePageLocators{
    public By aboutUsLink = By.xpath("//a[text()='About us ']");
    public By whyRelianceJewelsLink = By.xpath("(//a[text()='Why Reliance Jewels'])[1]");
    public By certificationLink = By.xpath("(//a[text()='Certifications'])[1]");
    public By showroomsLink = By.xpath("(//a[text()='Our Showrooms'])");
    public By mediaLink = By.xpath("//a[text()='Media']");
    public By blogLink = By.xpath("//a[text()='Blog']");
    public By faqLink = By.xpath("(//a[text()='FAQs'])[1]");
    public By trackOrderLink = By.xpath("(//a[text()='Track An Order'])");
    public By fastShippingText = By.xpath("(//a[text()='Fast Shipping'])");
    public By returnRefundPolicyLink = By.xpath("(//a[text()='Return & Refund Policy'])");
    public By shippingPolicyLink = By.xpath("(//a[text()='Shipping Policy'])[1]");
    public By privacyPolicyLink = By.xpath("(//a[text()='Privacy Policy'])[1]");
    public By oldGoldExchangePolicyLink = By.xpath("(//a[text()='Old Gold Exchange Policy'])[1]");
    public By feesPaymentsPolicyLink = By.xpath("(//a[text()='Fees and Payments Policy'])[1]");
    public By termsConditionsLink = By.xpath("(//a[text()='Terms and Conditions'])[1]");
    public By relianceOneLoyaltyLink = By.xpath("(//a[text()='RelianceOne Loyalty T & C'])[1]");
    public By disclaimerLink = By.xpath("(//a[text()='Disclaimer'])[1]");
    public By callBackLink = By.xpath("(//a[text()='Call Back'])");
    public By searchBarInput = By.xpath("//input[@id='q']");  
    public By logoImage = By.className("logo");
    public By pendantsNavLink = By.xpath("//a[text()='PENDANTS']");
    public By giftingLink = By.xpath("(//a[text()='Gifting'])[3]");
    public By ringsNavLink = By.xpath("//a[text()='Rings']");
    public By casualWearLink = By.xpath("(//a[text()='Casual Wear'])[2]");    
    public By trendingLink = By.xpath("//a[contains(text(),'Trending')]");
    public By vivahamLink = By.xpath("//a[text()='Vivaham']");
    public By earringsNavLink = By.xpath("//a[text()='Earrings']");
    public By diamondEarringsLink = By.xpath("(//a[text()='Diamond'])[1]");
    public static final By earringsCategory = By.xpath("//a[contains(text(), 'Earrings')]");
    public static final By dropsSubCategory = By.xpath("//a[contains(text(), 'Drops')]");
    public static final By mainLogoLocator = By.xpath("//div[@class='logo']//a[contains(@href, 'reliancejewels.com')]");
    public static final By chainCategory = By.xpath("//a[contains(text(), 'Chain')]");
    public static final By silverSubCategory  = By.xpath("//a[contains(@href, '/category:151/')]");
}