package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: LocateStorePageLocators
 * Author: Ashwani
 * Description: UI locators for the Locate Store page.
 */
public class LocateStorePageLocators {
    public By advancedSearchSection = By.xpath("//div[text()='Advanced Search']");
    public By stateDropdown = By.xpath("//select[@id='OutletState']");
    public By cityDropdown = By.xpath("//select[@id='OutletCity']");
    public By searchButton = By.xpath("(//span[text()='Search'])[2]");
}