package uistore;

import org.openqa.selenium.By;

/**
 * Class Name: ProductPage
 * Author: Aneesh
 * Description: UI locators for a generic Product Page.
 */
public class ProductPage {
    public static final By sizeDropdown = By.id("item-size");
    public static final By weightDropdown = By.id("item-weight");
    public static final By buyNowButton  = By.id("btnBuyNow");

}
