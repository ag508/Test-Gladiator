package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: ChainsLocator
 * Author: Aneesh
 * Description: UI locators for the Chains product category page.
 */
public class ChainsLocator {
    public static final By categoryFilter = By.id("filter_tree");
    public static final By genderFilter = By.xpath("//div[contains(text(), 'Gender')]");
    public static final By womenOption = By.xpath("//a[contains(@title, 'Silver - Women')]");
    public static final By verifiedWomenText = By.xpath("//span[contains(text(), 'Women')]");
    public static final By moreFilterButton = By.id("myBtn");
    public static final By tryOnFilter = By.id("filter_2");
    public static final By yesOption = By.xpath("//a[contains(@title, 'Silver - Yes')]");
    public static final By firstProduct = By.className("tooltip_18");
 
}