package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: VivahamPageLocators
 * Author: Ashwani
 * Description: UI locators for the Vivaham page.
 */
public class VivahamPageLocators {
    public By bookAnAppointment  = By.id("book-appointment");
    public By locateStoreLink = By.xpath("//a[text()='LOCATE A STORE']");
    public By delhiStoreOption = By.xpath("//*[@id=\"section3\"]/div/div/div[1]/a/p");
   
}