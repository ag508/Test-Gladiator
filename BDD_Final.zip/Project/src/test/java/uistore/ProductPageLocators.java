package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: ProductPageLocators
 * Author: Dhruv
 * Description: UI locators for product-related elements on various product pages.
 */
public class ProductPageLocators {
    public By addToCartButton = By.xpath("(//a[@id='btnBuyNow'])[1]");
    public By firstProduct = By.xpath("(//div[contains(@class,'product-item')])[1]");
}
 