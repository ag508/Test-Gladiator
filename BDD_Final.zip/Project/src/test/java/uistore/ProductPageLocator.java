package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: ProductPageLocator
 * Author: Dhruv
 * Description: UI locators for product-specific elements on a product detail page.
 */
public class ProductPageLocator {
    public By productPrice = By.xpath("//div[contains(text(),'Price')]");
    public By addToCartButton = By.xpath("(//a[@id='btnBuyNow'])[1]");
 
}
 