package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: RingLocator
 * Author: Yash
 * Description: UI locators for the Ring product category page.
 */
public class RingLocator {
    public By categoryFilter = By.xpath("//div[text()='categories']");
    public By platinumOption = By.xpath("//a[@title='Buy Platinum All Jewellery online shop']");
    public By moreFilterButton = By.xpath("//button[@id='myBtn']");
    public By tryOnFilter  = By.id("filter_3");
    public By yesOption = By.xpath("//a[text()=' Yes ']");
    public By firstProduct = By.xpath("(//a[@class='tooltip_18'])[1]");
}