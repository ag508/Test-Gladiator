package uistore;
 

import org.openqa.selenium.By;
 
/**
 * Class Name: RingsProductsPageLocators
 * Author: Dhruv
 * Description: UI locators for the Rings Products listing page.
 */

public class RingsProductsPageLocators {
 
    public By pageContainsRingsText = By.xpath("//span[@id='breadcrumbNavigationLast']");
    public By genderFilterButton = By.xpath("(//div[@id='filter_tree'])[3]");
    public By menOption = By.xpath("(//li[@id='filter_0Option_1']//a)[1]");
    public By metalFilterButton = By.xpath("(//div[@id='filter_tree'])[4]");
    // public By metalBtn = By.id("filter_tree");
   
    public By goldUnderMetalOption = By.xpath("(//li[@id='filter_0Option_2'])[2]//a");
    public By firstProductLink = By.xpath("//a[@class='tooltip_18']");
}