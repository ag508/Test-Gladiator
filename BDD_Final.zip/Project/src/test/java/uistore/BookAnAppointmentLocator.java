package uistore;

import org.openqa.selenium.By;

public class BookAnAppointmentLocator {
 public By bookAnHeading = By.xpath("//h2[text()='Book an appointment']");
 public By submitBtn = By.xpath("//button[@class='btn btn-default']");
 public By nameField = By.id("msg_name");
}
