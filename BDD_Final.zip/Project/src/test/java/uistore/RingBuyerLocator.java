package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: RingBuyerLocator
 * Author: Yash
 * Description: UI locators for the Ring Buyer page, focusing on product selection and checkout initiation.
 */
public class RingBuyerLocator {
    public By productCodeText = By.xpath("//p[contains(text(),'Product Code')]");
    public By sizeDropdown = By.xpath("//select[@id='item-size']");
    public By sizeOption17mm = By.xpath("//option[text()='17mm']");
    public By weightDropdown = By.xpath(("//select[@id='item-weight']"));
    public By weightOption5d43g = By.xpath("//option[text()='5.43g']");
    public By buyNowButton = By.xpath("(//a[@id='btnBuyNow'])[2]");
    public By proceedToPayButton = By.xpath("(//ul[@class='btns-list']//a)[1]");
}