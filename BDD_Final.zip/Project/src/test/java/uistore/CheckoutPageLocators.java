package uistore;
 
import org.openqa.selenium.By;
 
/**
 * Class Name: CheckoutPageLocators
 * Author: Ashwani
 * Description: UI locators for the Checkout page.
 */
public class CheckoutPageLocators {
 
    public By otherLink = By.xpath("//a[text()='Other']");
}
 