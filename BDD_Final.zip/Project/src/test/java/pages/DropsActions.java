package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.DropsLocator;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

/**
 * Actions for the Drops product category page.
 * @author Aneesh
 */
public class DropsActions {
    public WebDriver driver;
    public WebDriverHelper helper;

    public DropsActions(WebDriver driver){
        this.driver = driver;
        helper = new WebDriverHelper(driver);
    }

    /** Verifies if the current page URL contains the expected text from Excel. */
    public void verifyPageUrl(ExtentTest test, String pageUrlKeyword){
        try {
            helper.verifyLinkText(pageUrlKeyword);
            LoggerHandler.info("Verified Drops page URL.");
            test.log(Status.PASS, "Verified Drops page URL.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify Drops page URL: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify Drops page URL: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyDropsPageURL_Fail"), test, "Failed to verify Drops page URL");
        }
    }

    /** Clicks on the category filter and then the Gold option. */
    public void clickCategoryAndGoldFilters(ExtentTest test, String metalFilter){
        try {
            helper.clickOn(DropsLocator.categoryFilter);
            LoggerHandler.info("Clicked on category filter.");
            test.log(Status.PASS, "Clicked on category filter.");

            helper.clickOn(DropsLocator.goldOption);
            LoggerHandler.info("Clicked on Gold option.");
            test.log(Status.PASS, "Clicked on Gold option.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click category and gold filters: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click category and gold filters: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickCategoryGoldFilters_Fail"), test, "Failed to click category and gold filters");
        }
    }

    /** Verifies the text in the breadcrumb navigation. */
    public void verifyBreadcrumbFilterText(ExtentTest test, String breadcrumbText){
        try {
            helper.verifyLocatorText(DropsLocator.breadcrumbNavigation, breadcrumbText);
            LoggerHandler.info("Verified breadcrumb filter text.");
            test.log(Status.PASS, "Verified breadcrumb filter text.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify breadcrumb filter text: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify breadcrumb filter text: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyBreadcrumbFilterText_Fail"), test, "Failed to verify breadcrumb filter text");
        }
    }

    /** Clicks on more filter, then metal purity filter, and selects '22 kt' option. */
    public void applyMetalPurityFilter(ExtentTest test, String purityFilter){
        try {
            helper.clickOn(DropsLocator.moreFilterButton);
            LoggerHandler.info("Clicked on more filter button.");
            test.log(Status.PASS, "Clicked on more filter button.");

            helper.clickOn(DropsLocator.metalPurityFilter);
            LoggerHandler.info("Clicked on metal purity filter.");
            test.log(Status.PASS, "Clicked on metal purity filter.");

            helper.jsClick(DropsLocator.karat22Option);
            LoggerHandler.info("Selected 22 kt option under metal purity.");
            test.log(Status.PASS, "Selected 22 kt option under metal purity.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to apply metal purity filter: " + e.getMessage());
            test.log(Status.FAIL, "Failed to apply metal purity filter: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ApplyMetalPurityFilter_Fail"), test, "Failed to apply metal purity filter");
        }
    }

    /** Verifies the text of the 22 kt metal purity filter. */
    public void verifyMetalPurityFilterText(ExtentTest test, String purityTextVerified){
        try {
            helper.verifyLocatorText(DropsLocator.karat22VerifiedText, purityTextVerified);
            LoggerHandler.info("Verified 22 kt metal purity filter text.");
            test.log(Status.PASS, "Verified 22 kt metal purity filter text.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify metal purity filter text: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify metal purity filter text: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyMetalPurityFilterText_Fail"), test, "Failed to verify metal purity filter text");
        }
    }

    /** Clicks on the first product displayed on the page. */
    public void clickFirstProduct(ExtentTest test){
        try {
            helper.clickOn(DropsLocator.firstProduct);
            LoggerHandler.info("Clicked on the first product.");
            test.log(Status.PASS, "Clicked on the first product.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on first product: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click on first product: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("ClickFirstProduct_Fail"), test, "Failed to click on first product");
        }
    }
}
