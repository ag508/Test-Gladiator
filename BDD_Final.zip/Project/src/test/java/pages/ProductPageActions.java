package pages;
 
import org.openqa.selenium.WebDriver;
 
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
 
import uistore.ProductPage;
import uistore.ProductPageLocators;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;
 
/**
 * Actions for generic product pages.
 * @author Dhruv & Aneesh
 */
public class ProductPageActions {
 
    public WebDriver driver;
    public WebDriverHelper helper;
    public ProductPageLocators productLocators;
    public Screenshot screenshot;
 
    public ProductPageActions(WebDriver driver){
 
        this.driver = driver;
        helper = new WebDriverHelper(driver);
        productLocators = new ProductPageLocators();
        screenshot = new Screenshot(driver);
    }
 
    /** Clicks on the 'Add to Cart' button and captures a screenshot. */
    public void clickOnAddToCartButton(ExtentTest test){
        try {
            helper.clickOn(productLocators.addToCartButton);
            LoggerHandler.info("Clicked on add to cart button.");
            test.pass("Clicked on add to cart.");
           
            screenshot.captureScreenshotWithTimeStamp("AddedToCart");
            LoggerHandler.info("Screenshot captured after adding to cart.");
            test.log(Status.INFO, "Screenshot captured after adding to cart.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on Add to Cart button: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click on Add to Cart button: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("AddToCartButton_Fail"), test, "Failed to click on Add to Cart button");
        }
    }
 
    /** Clicks on the 'Buy Now' button. */
    public void clickBuyNowButton(ExtentTest test){
        try {
            helper.clickOn(ProductPage.buyNowButton);
            LoggerHandler.info("Clicked on Buy Now button.");
            test.pass("Clicked on Buy Now button.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Buy Now button: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click Buy Now button: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("BuyNowButton_Fail"), test, "Failed to click Buy Now button");
        }
    }
 
    /** Selects values from the size and weight dropdowns. */
    public void selectSizeAndWeightDropdowns(ExtentTest test, String size, String weight){
        try {
            helper.selectFromDropdown(ProductPage.sizeDropdown, size);
            LoggerHandler.info("Selected size from dropdown.");
            test.log(Status.PASS, "Selected size from dropdown.");
 
            helper.selectFromDropdown(ProductPage.weightDropdown, weight);
            LoggerHandler.info("Selected weight from dropdown.");
            test.log(Status.PASS, "Selected weight from dropdown.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to select size and weight from dropdowns: " + e.getMessage());
            test.log(Status.FAIL, "Failed to select size and weight from dropdowns: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("SelectSizeWeight_Fail"), test, "Failed to select size and weight dropdowns");
        }
    }
 
    /** Clicks on the first product in the list */
    public void clickFirstProduct(ExtentTest test) {
        try {
            helper.clickOn(productLocators.firstProduct);
            LoggerHandler.info("Clicked on the first product.");
            test.pass("Clicked on the first product.");
           
            screenshot.captureScreenshotWithTimeStamp("FirstProduct");
            LoggerHandler.info("Screenshot captured after clicking first product.");
            test.log(Status.INFO, "Screenshot captured after clicking first product.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on first product: " + e.getMessage());
            test.log(Status.FAIL, "Failed to click on first product: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("FirstProduct_Fail"), test, "Failed to click on first product");
        }
    }
}    
 