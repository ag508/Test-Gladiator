package pages;

import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import uistore.BookAnAppointmentLocator;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class BookAnAppointmentPageActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public BookAnAppointmentLocator locators;
    public HighLightActionUtil highlight;
    public Screenshot screenshot;

    public BookAnAppointmentPageActions(WebDriver driver) {
        this.driver = driver;
        helper = new WebDriverHelper(driver);
        locators = new BookAnAppointmentLocator();
        highlight = new HighLightActionUtil(driver);
        screenshot = new Screenshot(driver);
    }

    public void verifyPageLoaded(ExtentTest test) {
        try {
            helper.waitForElementVisible(locators.bookAnHeading);
            highlight.highlightElement(locators.bookAnHeading);
            test.pass("Book an appointment page loaded successfully.");
        } catch (Exception e) {
            LoggerHandler.error("Book an appointment page did not load: " + e.getMessage());
            String path = Reporter.captureScreenShot("BookAnAppointmentPageLoadFailure");
            Reporter.attachScreenshotToReport(path, test, "Book an appointment page did not load");
            test.fail("Book an appointment page did not load");
        }
    }

    public void clickSubmit(ExtentTest test) {
        try {
            helper.clickOn(locators.submitBtn);
            test.pass("Clicked on Submit button.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click Submit: " + e.getMessage());
            String path = Reporter.captureScreenShot("SubmitClickFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to click Submit");
            test.fail("Failed to click Submit");
        }
    }

    public void verifyNameCannotBeEmpty(ExtentTest test) {
        try {
            helper.waitForElementVisible(locators.nameField);
            helper.verifyLocatorText(locators.nameField, "Name cannot be empty");
            test.pass("Validation message displayed: Name cannot be empty");
        } catch (Exception e) {
            LoggerHandler.error("Validation message not found: " + e.getMessage());
            String path = Reporter.captureScreenShot("NameValidationFailure");
            Reporter.attachScreenshotToReport(path, test, "Validation message not found");
            test.fail("Validation message not found");
        }
    }
}
