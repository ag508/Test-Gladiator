package pages;
 
import java.time.Duration;
import java.util.List;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.junit.Assert;
 
import com.aventstack.extentreports.ExtentTest;
 
import uistore.RingsProductsPageLocators;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;
 
/**
 * Actions for the Rings Products Page.
 * @author Dhruv
 */
public class RingsProductsPageActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public RingsProductsPageLocators ringLoc;
    public Screenshot screenshot;
 
    /** Constructor for RingsProductsPageActions. */
    public RingsProductsPageActions(WebDriver driver){
        this.driver= driver;
        helper =new WebDriverHelper(driver);
        ringLoc = new RingsProductsPageLocators();
        screenshot = new Screenshot(driver);
    }
 
    /** Verifies that the page title contains the keyword "Rings". */
    public void verifyPageTitleContainsRingsKeyword(ExtentTest test, String expectedKeyword){
        try {
            String actualTitle = driver.getTitle();
            Assert.assertTrue(actualTitle.contains(expectedKeyword));
            LoggerHandler.info("Verified the search page results contain the keyword 'Rings'.");
            test.pass("Verified the search page results contain the keyword 'Rings'.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify page title contains 'Rings' keyword: " + e.getMessage());
            String path = Reporter.captureScreenShot("RingsPageTitleVerificationFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to verify page title contains 'Rings' keyword");
            test.fail("Failed to verify page title contains 'Rings' keyword");
        }
    }
 
    /** Clicks on the Gender filter button and then filters by "Men". */
    public void clickGenderFilterAndSelectMen(ExtentTest test, String gender){
        try {
            helper.clickOn(ringLoc.genderFilterButton);
            helper.clickOn(ringLoc.menOption);
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
            LoggerHandler.info("Clicked on gender button and filtered by men.");
            test.pass("Clicked on gender button and filtered by men.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click gender filter and select Men: " + e.getMessage());
            String path = Reporter.captureScreenShot("GenderFilterMenFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to click gender filter and select Men");
            test.fail("Failed to click gender filter and select Men");
        }
    }
 
    /** Clicks on the Metal filter and then filters by "Gold". */
    public void clickMetalFilterAndSelectGold(ExtentTest test, String metal){
        try {
            helper.clickOn(ringLoc.metalFilterButton);
            helper.clickOn(ringLoc.goldUnderMetalOption);
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
            LoggerHandler.info("Clicked on metal filter and filtered by gold.");
            test.pass("Clicked on metal filter and filtered by gold.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to click metal filter and select Gold: " + e.getMessage());
            String path = Reporter.captureScreenShot("MetalFilterGoldFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to click metal filter and select Gold");
            test.fail("Failed to click metal filter and select Gold");
        }
    }
 
    /** Clicks on the first product displayed in the rings list. */
    public void clickOnFirstRingProduct(ExtentTest test){
        try {
            List<WebElement> ringsNameList = helper.getElementsByXPath("//a[@class='tooltip_18']");
            if(!ringsNameList.isEmpty()){
                ringsNameList.get(0).click();
                LoggerHandler.info("click on the first product");
                test.pass("click on the first product");
            } else {
                LoggerHandler.warn("No rings products found to click.");
                test.skip("No rings products found to click.");
            }
        } catch (Exception e) {
            LoggerHandler.error("Failed to click on first ring product: " + e.getMessage());
            String path = Reporter.captureScreenShot("FirstRingProductClickFailure");
            Reporter.attachScreenshotToReport(path, test, "Failed to click on first ring product");
            test.fail("Failed to click on first ring product");
        }
    }
}
 