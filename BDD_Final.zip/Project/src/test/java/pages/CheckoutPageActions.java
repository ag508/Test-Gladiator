package pages;
 
import org.openqa.selenium.WebDriver;
 
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
 
import uistore.CheckoutPageLocators;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;
 
/**
 * Actions for the Checkout page.
 * @author Ashwani
 */
public class CheckoutPageActions {
    public WebDriver driver;
    public WebDriverHelper helper;
    public CheckoutPageLocators locators;
    public HighLightActionUtil highlight;
    public Screenshot screenshot;
 
    public CheckoutPageActions(WebDriver driver){
        this.driver= driver;
        helper =new WebDriverHelper(driver);
        locators = new CheckoutPageLocators();
        highlight = new HighLightActionUtil(driver);
        screenshot = new Screenshot(driver);
    }
 
    /** Verifies the text of the 'Other' keyword on the checkout page and attaches a screenshot. */
    public void verifyOtherKeywordAndAttachScreenshot(ExtentTest test, String otherKeywordText){
        try {
            highlight.highlightElement(locators.otherLink);
            LoggerHandler.info("Highlighted 'Other' keyword.");
            test.log(Status.INFO, "Highlighted 'Other' keyword.");
           
            helper.verifyLocatorText(locators.otherLink, otherKeywordText);
            LoggerHandler.info("Verified 'Other' keyword text.");
            test.log(Status.PASS, "Verified 'Other' keyword text.");
           
            String screenshotPath = Reporter.captureScreenShot("OtherKeywordVerification");
            Reporter.attachScreenshotToReport(screenshotPath, test, "Verified 'Other' keyword");
            LoggerHandler.info("Attached screenshot for 'Other' keyword verification.");
           
            highlight.unhighlightElement(locators.otherLink);
            LoggerHandler.info("Unhighlighted 'Other' keyword.");
            test.log(Status.INFO, "Unhighlighted 'Other' keyword.");
 
        } catch (Exception e) {
            LoggerHandler.error("Failed to verify 'Other' keyword: " + e.getMessage());
            test.log(Status.FAIL, "Failed to verify 'Other' keyword: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("VerifyOtherKeyword_Fail"), test, "Failed to verify 'Other' keyword");
        }
    }
}