package pages;
 
 
import org.openqa.selenium.WebDriver;
import org.junit.Assert;
 
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
 
import uistore.PendantPageLocator;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;
 
/**
 * Actions for the Pendant product page.
 * @author Yash
 */
public class PendantPageAction {
    public WebDriver driver;
    public WebDriverHelper helper;
    public PendantPageLocator pendantLocators;
   
    public PendantPageAction(WebDriver driver) {
        this.driver = driver;
        helper = new WebDriverHelper(driver);
        pendantLocators = new PendantPageLocator();
    }
 
    /** Performs a series of actions on the Pendant page including URL verification, filter application, and product selection. */
    public void performPendantPageActions(ExtentTest test, String pendantPageUrlKeyword) {
        try {
            Assert.assertTrue("Pendant page URL verification failed.", driver.getCurrentUrl().contains(pendantPageUrlKeyword));
            LoggerHandler.info("Verified current URL contains expected text for Pendant page.");
            test.log(Status.PASS,"Verified Pendant page URL.");
 
            helper.clickOn(pendantLocators.genderFilter);
            LoggerHandler.info("Clicked on gender filter.");
            test.log(Status.PASS,"Clicked on gender filter.");
 
            helper.clickOn(pendantLocators.kidsOption);
            LoggerHandler.info("Clicked on kids option.");
            test.log(Status.PASS,"Clicked on kids option.");
 
            helper.clickOn(pendantLocators.moreFilterButton);
            LoggerHandler.info("Clicked on more filter button.");
            test.log(Status.PASS,"Clicked on more filter button.");
 
            helper.clickOn(pendantLocators.typeFilter);
            LoggerHandler.info("Clicked on type filter.");
            test.log(Status.PASS,"Clicked on type filter.");
 
            helper.clickOn(pendantLocators.pendantTypeOption);
            LoggerHandler.info("Clicked on pendant type option.");
            test.log(Status.PASS,"Clicked on pendant type option.");
 
            helper.clickOn(pendantLocators.firstProduct);
            LoggerHandler.info("Clicked on the first product.");
            test.log(Status.PASS,"Clicked on the first product.");
        } catch (Exception e) {
            LoggerHandler.error("Failed to perform actions on Pendant page: " + e.getMessage());
            test.log(Status.FAIL, "Failed to perform actions on Pendant page: " + e.getMessage());
            Reporter.attachScreenshotToReport(Reporter.captureScreenShot("PendantPageActions_Fail"), test, "Failed to perform Pendant page actions");
        }
    }
}