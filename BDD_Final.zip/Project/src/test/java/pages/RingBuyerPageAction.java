package pages;
 
 
import org.openqa.selenium.WebDriver;
 
import com.aventstack.extentreports.ExtentTest;
 
import uistore.RingBuyerLocator;
import utils.HighLightActionUtil;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;
import org.junit.Assert;
import utils.WebDriverHelper;
 
/**
 * Actions for the Ring Buyer Page.
 * @author Yash
 */
public class RingBuyerPageAction {
    public WebDriver driver;
    public WebDriverHelper helper;
    public HighLightActionUtil highlight;
    public RingBuyerLocator ringloc;
    public LoggerHandler log;
    public Screenshot ss;
 
    /** Constructor for RingBuyerPageAction. */
    public RingBuyerPageAction(WebDriver driver) {
        this.driver = driver;
        helper=new WebDriverHelper(driver);
        ringloc=new RingBuyerLocator();
        highlight = new HighLightActionUtil(driver);
        ss = new Screenshot(driver);
    }
 
    /** Performs actions to buy a product on the Ring Buyer page. */
    public void buyProduct(ExtentTest test, String productCode) {
        try {
            helper.clickOn(ringloc.sizeDropdown);
            helper.clickOn(ringloc.sizeOption17mm);
            LoggerHandler.info("Choose size");
            test.pass("Choose size");
 
            helper.clickOn(ringloc.weightDropdown);
            helper.clickOn(ringloc.weightOption5d43g);
            LoggerHandler.info("Choose weight");
            test.pass("Choose weight");
 
            Assert.assertTrue(driver.findElement(ringloc.productCodeText).getText().contains(productCode));
            LoggerHandler.info("Verified product code");
            test.pass("Verified product code");
 
            helper.waitForElementVisible(ringloc.buyNowButton);
            helper.clickOn(ringloc.buyNowButton);
            LoggerHandler.info("Clicked on buy now");
            test.pass("Clicked on buy now");
 
            helper.clickOn(ringloc.proceedToPayButton);
            String screenshotPath=Reporter.captureScreenShot("reliancejewels");
            Reporter.attachScreenshotToReport(screenshotPath, test, "Screenshot taken for reliance jewels");
            LoggerHandler.info("Clicked on proceed to pay");
            test.pass("Clicked on proceed to pay");
        } catch (Exception e) {
            LoggerHandler.error("Failed to buy product: " + e.getMessage());
            String screenshotPath = Reporter.captureScreenShot("buyProductFailure");
            Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to buy product");
            test.fail("Failed to buy product");
        }
    }
}