package stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.Base;
import utils.Reporter;

public class Hooks extends Base {
    private static boolean isReportInitialized = false;

    @Before
    public void setup(Scenario scenario) {
        if (!isReportInitialized) {
            Reporter.reports = Reporter.generateReport();
            isReportInitialized = true;
        }
        openBrowser();
    }

    @After
    public void teardown(Scenario scenario) {
        try {
            if (driver != null) {
                if (scenario.isFailed()) {
                    String screenshotPath = Reporter.captureScreenShot(scenario.getName() + "_Failed");
                    Reporter.attachScreenshotToReport(screenshotPath, Reporter.reports.createTest(scenario.getName()), "Test Failed");
                }
                driver.quit();
            }
        } finally {
            // Only flush the report after all scenarios are complete
            if (Reporter.reports != null && scenario.getLine() == scenario.getLine()) {
                Reporter.reports.flush();
            }
        }
    }
}