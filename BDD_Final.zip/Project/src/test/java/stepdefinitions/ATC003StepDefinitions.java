package stepdefinitions;
 
import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.BookAnAppointmentPageActions;
import pages.HomePageActions;
import pages.LocateStorePageActions;
import pages.ProductsPageActions;
import pages.VivahamPageActions;
import utils.Base;
import utils.Reporter;
import utils.Screenshot;
 
public class ATC003StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public VivahamPageActions vivahamPageActions;
    public LocateStorePageActions locateStorePageActions;
    public ProductsPageActions productsPageActions;
    public BookAnAppointmentPageActions bookAnAppointmentPageActions;
    public ExtentTest extentTest;

    @Given("I am on the home page for vivaham")
    public void i_am_on_the_home_page_for_vivaham() {
        extentTest = Reporter.reports.createTest("ATC003");
        homePageActions = new HomePageActions(driver);
        vivahamPageActions = new VivahamPageActions(driver);
        locateStorePageActions = new LocateStorePageActions(driver);
        productsPageActions = new ProductsPageActions(driver);
    }

    @And("I maximize the browser window")
    public void iMaximizeTheBrowserWindow() {
        driver.manage().window().maximize();
    }

    @And("I verify the Reliance Jewels logo is displayed")
    public void iVerifyRelianceJewelsLogoIsDisplayed() {
        extentTest = Reporter.reports.createTest("Verify Reliance Jewels Logo");
        homePageActions.verifyMainLogoLink(extentTest, "reliancejewels.com");
    }

    @And("I hover on What Trending")
    public void iHoverOnWhatTrending() {
        homePageActions.hoverOnWhatsTrending(extentTest);
    }

    @And("I click on the Vivaham link and switch window")
    public void iClickOnVivahamLinkAndSwitchWindow() {
        homePageActions.clickVivahamLinkAndSwitchWindow(extentTest);
    }

    @And("I wait till the Vivaham page gets loaded")
    public void iWaitTillVivahamPageGetsLoaded() {
        // Implement wait logic if needed, e.g., wait for a specific element on Vivaham page
    }

    @And("I verify the vivaham URL contains {string}")
    public void i_verify_the_vivaham_url_contains(String vivahamUrlKeyword) {
        homePageActions.verifyVivahamUrl(extentTest, vivahamUrlKeyword);
    }

    @And("I click on Book an Appointment")
    public void iClickOnBookAnAppointment() {
        vivahamPageActions.helper.clickOn(vivahamPageActions.locators.bookAnAppointment);
    }

    @And("I switch to the Book an Appointment tab")
    public void iSwitchToBookAnAppointmentTab() {
        for (String handle : driver.getWindowHandles()) {
            driver.switchTo().window(handle);
        }
        bookAnAppointmentPageActions = new BookAnAppointmentPageActions(driver);
    }

    @And("I wait for the Book an Appointment page to load")
    public void iWaitForBookAnAppointmentPageToLoad() {
        bookAnAppointmentPageActions.verifyPageLoaded(extentTest);
    }

    @And("I click the Submit button on Book an Appointment")
    public void iClickSubmitButtonOnBookAnAppointment() {
        bookAnAppointmentPageActions.clickSubmit(extentTest);
    }

    @Then("I verify the Name cannot be empty validation message")
    public void iVerifyNameCannotBeEmptyValidationMessage() {
        bookAnAppointmentPageActions.verifyNameCannotBeEmpty(extentTest);
    }

    @And("I switch back to Vivaham page")
    public void iSwitchBackToVivahamPage() {
        // Switch to the Vivaham window (assume it's the first handle)
        String firstHandle = driver.getWindowHandles().iterator().next();
        driver.switchTo().window(firstHandle);
    }

    @And("I scroll down and click the Delhi option")
    public void iScrollDownAndClickDelhiOption() {
        vivahamPageActions.clickDelhiOption(extentTest);
    }

    @And("I switch to the Delhi tab")
    public void iSwitchToDelhiTab() {
        for (String handle : driver.getWindowHandles()) {
            driver.switchTo().window(handle);
        }
    }

    @And("I wait till the Delhi page gets loaded")
    public void iWaitTillDelhiPageGetsLoaded() {
        // Implement wait logic if needed, e.g., wait for a specific element on Delhi page
    }

    @And("I verify the Delhi page loads with relevant content")
    public void iVerifyDelhiPageLoadsWithRelevantContent() {
        // Implement content verification for Delhi page
    }

    @Then("I verify the Sort By filter label is {string}")
    public void iVerifySortByFilterLabel(String sortByLabel) {
        productsPageActions.verifySortByFilterLabel(extentTest, sortByLabel);
    }

    @And("I capture the screenshot")
    public void iCaptureTheScreenshot() {
        // Capture screenshot using Screenshot utility
        new Screenshot(driver).captureScreenshotWithTimeStamp("ATC003_Screenshot");
    }
}
