package stepdefinitions;
 
import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import utils.Base;
import utils.Reporter;
 
public class ATC008StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public ExtentTest extentTest;
 
    @Given("I am on the home page for about us links")
    public void iAmOnTheHomePage() {
        extentTest = Reporter.reports.createTest("ATC008");
        homePageActions = new HomePageActions(driver);
    }
 
    @When("I click on About Us and verify URL contains {string}")
    public void I_click_on_About_Us_and_verify_url(String aboutUsUrlKeyword) {
        homePageActions.clickOnAboutUs(extentTest, aboutUsUrlKeyword);
    }
 
    @And("I click Why Reliance Jewels and verify URL contains {string} and title contains {string}")
    public void iClickWhyRelianceJewelsAndVerifyUrlAndTitle(String whyRelianceUrlKeyword, String whyRelianceTitleKeyword) {
        homePageActions.clickWhyRelianceAndVerifyUrl(extentTest, whyRelianceUrlKeyword, whyRelianceTitleKeyword);
    }
 
    @And("I click Certification and verify URL contains {string} and title contains {string}")
    public void iClickCertificationAndVerifyUrlAndTitle(String certificationUrlKeyword, String certificationTitleKeyword) {
        homePageActions.clickCertificationAndVerifyUrl(extentTest, certificationUrlKeyword, certificationTitleKeyword);
    }
 
    @And("I click Showrooms and verify URL contains {string}")
    public void iClickShowroomsAndVerifyUrlContains(String showroomsUrlKeyword) {
        homePageActions.clickShowroomsAndVerifyUrl(extentTest, showroomsUrlKeyword);
    }
 
    @And("I click Media and verify URL contains {string} and title contains {string}")
    public void iClickMediaAndVerifyUrlAndTitle(String mediaUrlKeyword, String mediaTitleKeyword) {
        homePageActions.clickMediaAndVerifyUrl(extentTest, mediaUrlKeyword, mediaTitleKeyword);
    }
 
    @And("I click Blog and verify URL contains {string} and title contains {string}")
    public void iClickBlogAndVerifyUrlAndTitle(String blogUrlKeyword, String blogTitleKeyword) {
        homePageActions.clickBlogAndVerifyUrl(extentTest, blogUrlKeyword, blogTitleKeyword);
    }
 
    @And("I click Faq and verify URL contains {string} and title contains {string}")
    public void iClickFaqAndVerifyUrlAndTitle(String faqUrlKeyword, String faqTitleKeyword) {
        homePageActions.clickFaqAndVerifyUrl(extentTest, faqUrlKeyword, faqTitleKeyword);
    }
 
    @And("I click Track Order and verify URL contains {string} and title contains {string}")
    public void iClickTrackOrderAndVerifyUrlAndTitle(String trackOrderUrlKeyword, String trackOrderTitleKeyword) {
        homePageActions.clickTrackOrderAndVerifyUrl(extentTest, trackOrderUrlKeyword, trackOrderTitleKeyword);
    }
 
    @Then("I verify the {string} section")
    public void iVerifyTheSection(String shippingSectionText) {
        homePageActions.verifyFastShippingSection(extentTest, shippingSectionText);
    }
}