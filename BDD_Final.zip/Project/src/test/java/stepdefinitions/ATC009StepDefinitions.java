package stepdefinitions;
 
import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePageActions;
import utils.Base;
import utils.Reporter;
 
public class ATC009StepDefinitions extends Base {
    public HomePageActions homePageActions;
    public ExtentTest extentTest;
 
    @Given("I am on the home page for policy links")
    public void iAmOnTheHomePage() {
        extentTest = Reporter.reports.createTest("ATC009");
        homePageActions = new HomePageActions(driver);
    }
 
    @When("I click return {string} and verify its title {string}")
    public void iClickAndVerifyItsTitle(String returnRefundPolicyUrl, String returnRefundPolicyTitle) {
        homePageActions.clickReturnRefundPolicy(extentTest, returnRefundPolicyUrl, returnRefundPolicyTitle);
    }
 
    @And("I click shipping {string} and verify its title {string}")
    public void iClickShippingPolicyAndVerifyItsTitle(String shippingPolicyUrl, String shippingPolicyTitle) {
        homePageActions.clickShippingPolicy(extentTest, shippingPolicyUrl, shippingPolicyTitle);
    }
 
    @And("I click privacy {string} and verify its title {string}")
    public void iClickPrivacyPolicyAndVerifyItsTitle(String privacyPolicyUrl, String privacyPolicyTitle) {
        homePageActions.clickPrivacyPolicy(extentTest, privacyPolicyUrl, privacyPolicyTitle);
    }
 
    @And("I click old {string} and verify its title {string}")
    public void iClickOldGoldExchangePolicyAndVerifyItsTitle(String oldGoldExchangePolicyUrl, String oldGoldExchangePolicyTitle) {
        homePageActions.clickOldGoldExchangePolicy(extentTest, oldGoldExchangePolicyUrl, oldGoldExchangePolicyTitle);
    }
 
    @And("I click fees {string} and verify its title {string}")
    public void iClickFeesAndPaymentsPolicyAndVerifyItsTitle(String feesPaymentsPolicyUrl, String feesPaymentsPolicyTitle) {
        homePageActions.clickFeesAndPaymentsPolicy(extentTest, feesPaymentsPolicyUrl, feesPaymentsPolicyTitle);
    }
 
    @And("I click terms {string} and verify its title {string}")
    public void iClickTermsAndConditionsAndVerifyItsTitle(String termsConditionsUrl, String termsConditionsTitle) {
        homePageActions.clickTermsAndConditions(extentTest, termsConditionsUrl, termsConditionsTitle);
    }
 
    @And("I click loyalty {string} and verify its title {string}")
    public void iClickRelianceOneLoyaltyAndVerifyItsTitle(String relianceOneLoyaltyUrl, String relianceOneLoyaltyTitle) {
        homePageActions.clickRelianceOneLoyaltyTermsAndConditions(extentTest, relianceOneLoyaltyUrl, relianceOneLoyaltyTitle);
    }
 
    @And("I click disclaimer {string} and verify its title {string}")
    public void iClickDisclaimerAndVerifyItsTitle(String disclaimerUrl, String disclaimerTitle) {
        homePageActions.clickDisclaimerAndVerifyUrl(extentTest, disclaimerUrl);
    }
 
    @Then("I verify the callback {string} section")
    public void iVerifyTheSection(String callbackSectionText) {
        homePageActions.verifyCallBackSection(extentTest, callbackSectionText);
    }
}
 