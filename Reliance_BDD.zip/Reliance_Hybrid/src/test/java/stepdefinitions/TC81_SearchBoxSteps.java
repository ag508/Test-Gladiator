package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.SuiDhagaActions;
import utils.Base;

public class TC81_SearchBoxSteps extends Base {
    private HomePageActions homeAct;
    private SuiDhagaActions suiAct;

    public TC81_SearchBoxSteps() {
        homeAct = new HomePageActions(driver);
        suiAct = new SuiDhagaActions(driver);
    }

    @When("I click on search field")
    public void i_click_on_search_field() {
        homeAct.clickSearchField(Hooks.test);
    }

    @And("I enter search text")
    public void i_enter_search_text() {
        homeAct.enterSearchText(Hooks.test);
    }

    @And("I hover over Earrings in search results")
    public void i_hover_over_earrings_in_search_results() {
        homeAct.hoverOverEarrings(Hooks.test);
    }

    @And("I click on Sui Dhaga option")
    public void i_click_on_sui_dhaga_option() {
        suiAct.clickSuiDhaga(Hooks.test);
    }

    @Then("I verify search results display")
    public void i_verify_search_results_display() {
        suiAct.verifySearch(Hooks.test);
    }
} 