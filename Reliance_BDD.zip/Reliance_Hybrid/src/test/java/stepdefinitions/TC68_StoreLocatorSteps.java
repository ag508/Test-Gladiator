package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.StoreLocatorActions;
import utils.Base;

public class TC68_StoreLocatorSteps extends Base {
    private StoreLocatorActions storeLocatorAct;

    public TC68_StoreLocatorSteps() {
        storeLocatorAct = new StoreLocatorActions(driver);
    }

    @When("I open store locator from navigation menu")
    public void i_open_store_locator_from_navigation_menu() {
        storeLocatorAct.clickStoreLocator(Hooks.test);
    }

    @And("I scroll to store locator footer section")
    public void i_scroll_to_store_locator_footer_section() {
        storeLocatorAct.scrollToFooter(Hooks.test);
    }

    @And("I navigate to second page of store listings")
    public void i_navigate_to_second_page_of_store_listings() {
        storeLocatorAct.secondPage(Hooks.test);
    }

    @Then("I verify Assam store location presence")
    public void i_verify_assam_store_location_presence() {
        storeLocatorAct.verifyAssam(Hooks.test);
    }

    @When("I return to previous page of store listings")
    public void i_return_to_previous_page_of_store_listings() {
        storeLocatorAct.clickPrevious(Hooks.test);
    }

    @And("I click store locator search field")
    public void i_click_store_locator_search_field() {
        storeLocatorAct.clickSearchBar(Hooks.test);
    }

    @And("I enter Hyderabad in store search box")
    public void i_enter_hyderabad_in_store_search_box() {
        storeLocatorAct.enterTextInSearchBar(Hooks.test);
    }

    @And("I trigger store location search")
    public void i_trigger_store_location_search() {
        storeLocatorAct.clickSearch(Hooks.test);
    }

    @Then("I verify store search results display")
    public void i_verify_store_search_results_display() {
        storeLocatorAct.verifySearch(Hooks.test);
    }
} 