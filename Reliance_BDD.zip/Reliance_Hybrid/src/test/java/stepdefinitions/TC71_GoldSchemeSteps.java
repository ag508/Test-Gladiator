package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.GoldenSchemeActions;
import utils.Base;

public class TC71_GoldSchemeSteps extends Base {
    private GoldenSchemeActions goldSchemeAct;

    public TC71_GoldSchemeSteps() {
        goldSchemeAct = new GoldenSchemeActions(driver);
    }

    @When("I click on Golden Steps Plan link")
    public void i_click_on_golden_steps_plan_link() {
        goldSchemeAct.clickedGolden(Hooks.test);
    }

    @And("I scroll to footer section for scheme")
    public void i_scroll_to_footer_section_for_scheme() {
        goldSchemeAct.scrollToFooter(Hooks.test);
    }

    @And("I click on Terms and Conditions link for Gold Scheme")
    public void i_click_on_terms_and_conditions_link_for_gold_scheme() {
        goldSchemeAct.clickTerms(Hooks.test);
    }

    @Then("I verify Terms and Conditions page")
    public void i_verify_terms_and_conditions_page() {
        goldSchemeAct.verifyTermsAndCondition(Hooks.test);
    }

    @When("I click on Golden Steps Plan link second time")
    public void i_click_on_golden_steps_plan_link_second_time() {
        goldSchemeAct.clickGolden2(Hooks.test);
    }

    @Then("I verify login page")
    public void i_verify_login_page() {
        goldSchemeAct.verifyLogin(Hooks.test);
    }

    @And("I click on login button")
    public void i_click_on_login_button() {
        goldSchemeAct.clickLogin(Hooks.test);
    }
} 