package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.PendantAction;
import utils.Base;

public class TC82_PendantSteps extends Base {
    private HomePageActions homeAct;
    private PendantAction pendantAct;

    public TC82_PendantSteps() {
        homeAct = new HomePageActions(driver);
        pendantAct = new PendantAction(driver);
    }

    @When("I hover over Pendant menu")
    public void i_hover_over_pendant_menu() {
        homeAct.hoverPendant(Hooks.test);
    }

    @And("I click on Pendant category")
    public void i_click_on_pendant_category() {
        pendantAct.clickPendant(Hooks.test);
    }

    @And("I click on website logo")
    public void i_click_on_website_logo() {
        pendantAct.clickLogo(Hooks.test);
    }

    @Then("I verify Pendant section display")
    public void i_verify_pendant_section_display() {
        pendantAct.verifyPendant(Hooks.test);
    }

    @And("I verify Pendant page URL")
    public void i_verify_pendant_page_url() {
        pendantAct.verifyPendantUrl(Hooks.test);
    }
} 