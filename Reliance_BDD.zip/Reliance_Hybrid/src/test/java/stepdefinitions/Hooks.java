package stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.Base;
import utils.Reporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class Hooks extends Base {
    public static ExtentReports report;
    public static ExtentTest test;
    private static boolean isReportInitialized = false;

    @Before
    public void setup(Scenario scenario) {
        if (!isReportInitialized) {
            report = Reporter.generateReport("Reliance_Jewels");
            isReportInitialized = true;
        }
        test = report.createTest(scenario.getName());
        openBrowser();
    }

    @After
    public void tearDown(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                String screenshotPath = Reporter.captureScreenshotWithTimeStamp("FailureScreenshot");
                Reporter.attachScreenshotToReport(screenshotPath, test, "Test Failed");
            }
        } finally {
            if (driver != null) {
                driver.quit();
            }
            Reporter.flushReport();
        }
    }
} 