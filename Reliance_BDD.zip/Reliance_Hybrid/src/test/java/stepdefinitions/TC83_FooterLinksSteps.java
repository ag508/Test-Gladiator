package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.PendantAction;
import utils.Base;

public class TC83_FooterLinksSteps extends Base {
    private HomePageActions homeAct;
    private PendantAction pendantAct;

    public TC83_FooterLinksSteps() {
        homeAct = new HomePageActions(driver);
        pendantAct = new PendantAction(driver);
    }

    @When("I click on FAQ link in footer")
    public void i_click_on_faq_link_in_footer() {
        homeAct.clickFaqLink(Hooks.test);
    }

    @And("I click on Track Order link in footer")
    public void i_click_on_track_order_link_in_footer() {
        homeAct.clickTrackOrderLink(Hooks.test);
    }

    @And("I click on Fast Shipping text in footer")
    public void i_click_on_fast_shipping_text_in_footer() {
        homeAct.clickFastShippingText(Hooks.test);
    }

    @And("I click on website logo from footer")
    public void i_click_on_website_logo_from_footer() {
        pendantAct.clickLogo(Hooks.test);
    }

    @Then("I verify homepage URL")
    public void i_verify_homepage_url() {
        homeAct.verifyUrl(Hooks.test);
    }
} 