package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.SignUpActions;
import utils.Base;

public class TC16_EmptyFieldsLoginSteps extends Base {
    private HomePageActions homeAct;
    private SignUpActions signupAct;

    public TC16_EmptyFieldsLoginSteps() {
        homeAct = new HomePageActions(driver);
        signupAct = new SignUpActions(driver);
    }

    @When("I access sign in page for empty fields validation")
    public void i_access_sign_in_page_for_empty_fields_validation() {
        homeAct.clickonSignIn(Hooks.test);
    }

    @Then("I check login url in empty fields scenario")
    public void i_check_login_url_in_empty_fields_scenario() {
        signupAct.verifyLoginUrl(Hooks.test);
    }

    @And("I verify login with OTP option presence")
    public void i_verify_login_with_otp_option_presence() {
        signupAct.verifyLoginOtp(Hooks.test);
    }

    @When("I attempt login with empty credentials")
    public void i_attempt_login_with_empty_credentials() {
        signupAct.emptyEmailAndPasswordFields(Hooks.test);
    }

    @Then("I verify password field validation message")
    public void i_verify_password_field_validation_message() {
        signupAct.passwordError(Hooks.test);
    }

    @And("I verify email field validation message")
    public void i_verify_email_field_validation_message() {
        signupAct.emailError(Hooks.test);
    }

    @And("I confirm login form display for empty fields")
    public void i_confirm_login_form_display_for_empty_fields() {
        signupAct.verifyLogin();
    }
} 