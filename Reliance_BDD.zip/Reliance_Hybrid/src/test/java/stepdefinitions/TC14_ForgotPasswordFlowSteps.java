package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.SignUpActions;
import utils.Base;

public class TC14_ForgotPasswordFlowSteps extends Base {
    private HomePageActions homeAct;
    private SignUpActions signupAct;

    public TC14_ForgotPasswordFlowSteps() {
        homeAct = new HomePageActions(driver);
        signupAct = new SignUpActions(driver);
    }

    @When("I initiate sign in for forgot password flow")
    public void i_initiate_sign_in_for_forgot_password_flow() {
        homeAct.clickonSignIn(Hooks.test);
    }

    @Then("I validate login url in forgot password scenario")
    public void i_validate_login_url_in_forgot_password_scenario() {
        signupAct.verifyLoginUrl(Hooks.test);
    }

    @When("I submit unregistered email for password recovery")
    public void i_submit_unregistered_email_for_password_recovery() throws Exception {
        signupAct.inputUnregisteredEmail(Hooks.test);
    }

    @And("I click forgot password link for recovery attempt")
    public void i_click_forgot_password_link_for_recovery_attempt() {
        signupAct.triggerForgotPassword(Hooks.test);
    }

    @Then("I validate forgot password error notification")
    public void i_validate_forgot_password_error_notification() {
        signupAct.validateForgotPasswordError(Hooks.test);
    }

    @And("I confirm forgot password link visibility")
    public void i_confirm_forgot_password_link_visibility() {
        signupAct.verifyForgotPassword(Hooks.test);
    }

    @And("I verify error notification for unregistered email")
    public void i_verify_error_notification_for_unregistered_email() {
        signupAct.verifyErrorMsg(Hooks.test);
    }
} 