package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.WhatsTrendingActions;
import utils.Base;

public class TC78_WhatsTrendingSteps extends Base {
    private WhatsTrendingActions whatsTrendingAct;

    public TC78_WhatsTrendingSteps() {
        whatsTrendingAct = new WhatsTrendingActions(driver);
    }

    @When("I hover over What's Trending menu for Swarna Banga collection")
    public void i_hover_over_whats_trending_menu_for_swarna_banga_collection() {
        whatsTrendingAct.hoverWhatsTrending(Hooks.test);
    }

    @And("I click on Swarna Banga collection link in trending menu")
    public void i_click_on_swarna_banga_collection_link_in_trending_menu() {
        whatsTrendingAct.clickSwarnaBanga(Hooks.test);
    }

    @And("I scroll to Swarna Banga catalogue section")
    public void i_scroll_to_swarna_banga_catalogue_section() {
        whatsTrendingAct.scrollCatalogueIntoView(Hooks.test);
    }

    @And("I wait for Swarna Banga catalogue to be visible")
    public void i_wait_for_swarna_banga_catalogue_to_be_visible() {
        whatsTrendingAct.waitForCatalogueVisibility(Hooks.test);
    }

    @When("I click on Swarna Banga collection catalog link")
    public void i_click_on_swarna_banga_collection_catalog_link() {
        whatsTrendingAct.clickSwarnaBangaCatalogue(Hooks.test);
    }

    @Then("I verify Swarna Banga collection catalog page is displayed")
    public void i_verify_swarna_banga_collection_catalog_page_is_displayed() {
        whatsTrendingAct.verifySwarnaBangaUrl(Hooks.test);
    }
} 