package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.EarringsAction;
import utils.Base;

public class TC80_EarringsSteps extends Base {
    private HomePageActions homeAct;
    private EarringsAction earringsAction;

    public TC80_EarringsSteps() {
        homeAct = new HomePageActions(driver);
        earringsAction = new EarringsAction(driver);
    }

    @When("I scroll to Earrings section")
    public void i_scroll_to_earrings_section() {
        homeAct.scrollToEarrings(Hooks.test);
    }

    @And("I click on Earrings category")
    public void i_click_on_earrings_category() {
        homeAct.clickOnEarrings(Hooks.test);
    }

    @Then("I verify Earrings text is displayed")
    public void i_verify_earrings_text_is_displayed() {
        homeAct.verifyEarringsText(Hooks.test);
    }

    @When("I select second earring from the list")
    public void i_select_second_earring_from_the_list() {
        earringsAction.clickSecondEarring(Hooks.test);
    }

    @Then("I verify earring breadcrumb navigation")
    public void i_verify_earring_breadcrumb_navigation() {
        earringsAction.verifyEarringBreadcrumb(Hooks.test);
    }

    @And("I verify earring product title")
    public void i_verify_earring_product_title() {
        earringsAction.verifyTitle(Hooks.test);
    }
} 