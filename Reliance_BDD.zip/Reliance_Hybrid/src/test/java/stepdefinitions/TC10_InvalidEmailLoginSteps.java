package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.SignUpActions;
import utils.Base;

public class TC10_InvalidEmailLoginSteps extends Base {
    private HomePageActions homeAct;
    private SignUpActions signupAct;

    public TC10_InvalidEmailLoginSteps() {
        homeAct = new HomePageActions(driver);
        signupAct = new SignUpActions(driver);
    }

    @When("I click on sign in button for invalid email test")
    public void i_click_on_sign_in_button_for_invalid_email_test() {
        homeAct.clickonSignIn(Hooks.test);
    }

    @Then("I verify login url for invalid email test")
    public void i_verify_login_url_for_invalid_email_test() {
        signupAct.verifyLoginUrl(Hooks.test);
    }

    @And("I verify login page display for invalid email test")
    public void i_verify_login_page_display_for_invalid_email_test() {
        signupAct.verifyLogin();
    }

    @When("I enter invalid email for authentication")
    public void i_enter_invalid_email_for_authentication() throws Exception {
        signupAct.enterInvalidEmail(Hooks.test);
    }

    @And("I provide password and attempt sign in for invalid email")
    public void i_provide_password_and_attempt_sign_in_for_invalid_email() throws Exception {
        signupAct.enterPasswordAndSignIn(Hooks.test);
    }

    @Then("I verify error message for invalid email login")
    public void i_verify_error_message_for_invalid_email_login() {
        signupAct.verifyErrorMessage(Hooks.test);
    }

    @And("I verify register option for invalid email flow")
    public void i_verify_register_option_for_invalid_email_flow() {
        signupAct.verifyRegister();
    }
} 