package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.TermsAndCondition;
import utils.Base;

public class TC87_TermsAndConditionSteps extends Base {
    private TermsAndCondition termsAndConditionsAct;

    public TC87_TermsAndConditionSteps() {
        termsAndConditionsAct = new TermsAndCondition(driver);
    }

    @When("I click on Terms and Conditions link")
    public void i_click_on_terms_and_conditions_link() {
        termsAndConditionsAct.clickTermsAndConditionsLink(Hooks.test);
    }

    @Then("I verify Terms and Conditions heading")
    public void i_verify_terms_and_conditions_heading() {
        termsAndConditionsAct.verifyTermsHeading(Hooks.test);
    }

    @And("I verify Trademark text content")
    public void i_verify_trademark_text_content() {
        termsAndConditionsAct.verifyTrademarkText(Hooks.test);
    }

    @And("I verify Nodal Officer text content")
    public void i_verify_nodal_officer_text_content() {
        termsAndConditionsAct.verifyNodalText(Hooks.test);
    }

    @And("I verify PAN Card information")
    public void i_verify_pan_card_information() {
        termsAndConditionsAct.verifyPanCard(Hooks.test);
    }
} 