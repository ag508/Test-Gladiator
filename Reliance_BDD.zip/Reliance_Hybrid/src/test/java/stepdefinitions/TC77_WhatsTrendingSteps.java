package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.WhatsTrendingActions;
import utils.Base;

public class TC77_WhatsTrendingSteps extends Base {
    private WhatsTrendingActions whatsTrendingAct;

    public TC77_WhatsTrendingSteps() {
        whatsTrendingAct = new WhatsTrendingActions(driver);
    }

    @When("I hover over What's Trending menu for Thanjavur items")
    public void i_hover_over_whats_trending_menu_for_thanjavur_items() {
        whatsTrendingAct.hoverWhatsTrending(Hooks.test);
    }

    @And("I click on Thanjavur jewelry link in trending menu")
    public void i_click_on_thanjavur_jewelry_link_in_trending_menu() {
        whatsTrendingAct.clickThanjavur(Hooks.test);
    }

    @And("I click on explore now for Poompuhar collection")
    public void i_click_on_explore_now_for_poompuhar_collection() {
        whatsTrendingAct.clickexploreNowPoompuhar(Hooks.test);
    }

    @Then("I verify Thanjavur jewelry page URL and title")
    public void i_verify_thanjavur_jewelry_page_url_and_title() {
        whatsTrendingAct.verifyUrl(Hooks.test);
    }

    @When("I click on fourth trending jewelry item")
    public void i_click_on_fourth_trending_jewelry_item() {
        whatsTrendingAct.clickFourthItem(Hooks.test);
    }

    @And("I click on Make to Order option for trending jewelry")
    public void i_click_on_make_to_order_option_for_trending_jewelry() {
        whatsTrendingAct.clickMakeToOrder(Hooks.test);
    }

    @Then("I verify Make to Order jewelry functionality")
    public void i_verify_make_to_order_jewelry_functionality() {
        // This step needs to be implemented based on the actual verification needed
        // For now, it's a placeholder as the original implementation is not clear
    }
} 