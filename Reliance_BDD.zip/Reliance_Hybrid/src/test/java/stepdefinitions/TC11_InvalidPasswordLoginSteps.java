package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import pages.SignUpActions;
import utils.Base;

public class TC11_InvalidPasswordLoginSteps extends Base {
    private HomePageActions homeAct;
    private SignUpActions signupAct;

    public TC11_InvalidPasswordLoginSteps() {
        homeAct = new HomePageActions(driver);
        signupAct = new SignUpActions(driver);
    }

    @When("I click on sign in button for password validation")
    public void i_click_on_sign_in_button_for_password_validation() {
        homeAct.clickonSignIn(Hooks.test);
    }

    @Then("I verify login url for password test")
    public void i_verify_login_url_for_password_test() {
        signupAct.verifyLoginUrl(Hooks.test);
    }

    @And("I verify login page display for password test")
    public void i_verify_login_page_display_for_password_test() {
        signupAct.verifyLogin();
    }

    @When("I input registered email for password validation")
    public void i_input_registered_email_for_password_validation() {
        signupAct.inputEmailFromExcel(Hooks.test);
    }

    @And("I input incorrect password for validation")
    public void i_input_incorrect_password_for_validation() {
        signupAct.inputInvalidPasswordFromExcel(Hooks.test);
    }

    @And("I trigger sign in for password validation")
    public void i_trigger_sign_in_for_password_validation() {
        signupAct.performSignInClick(Hooks.test);
    }

    @Then("I verify error message for wrong password")
    public void i_verify_error_message_for_wrong_password() {
        signupAct.verifyErrorMsg(Hooks.test);
    }
} 