package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import pages.HomePageActions;
import utils.Base;

public class TC79_NavigationSteps extends Base {
    private HomePageActions homeAct;

    public TC79_NavigationSteps() {
        homeAct = new HomePageActions(driver);
    }

    @When("I hover over All Jewellery menu and click")
    public void i_hover_over_all_jewellery_menu_and_click() {
        homeAct.hoverAndClickAllJewellery(Hooks.test);
    }

    @And("I hover over Earrings menu and click")
    public void i_hover_over_earrings_menu_and_click() {
        homeAct.hoverAndClickEarrings(Hooks.test);
    }

    @And("I hover over Rings menu and click")
    public void i_hover_over_rings_menu_and_click() {
        homeAct.hoverAndClickRings(Hooks.test);
    }

    @And("I hover over Bangles and Bracelet menu and click")
    public void i_hover_over_bangles_and_bracelet_menu_and_click() {
        homeAct.hoverAndClickBanglesAndBracelet(Hooks.test);
    }

    @And("I hover over Chain menu and click")
    public void i_hover_over_chain_menu_and_click() {
        homeAct.hoverAndClickChain(Hooks.test);
    }

    @And("I hover over Pendant menu and click")
    public void i_hover_over_pendant_menu_and_click() {
        homeAct.hoverAndClickPendant(Hooks.test);
    }

    @And("I hover over Mangalsutra menu and click")
    public void i_hover_over_mangalsutra_menu_and_click() {
        homeAct.hoverAndClickMangalsutra(Hooks.test);
    }
} 