package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.ReturnPolicyActions;
import utils.Base;

public class TC89_ReturnPolicySteps extends Base {
    private ReturnPolicyActions returnPolicyAct;

    public TC89_ReturnPolicySteps() {
        returnPolicyAct = new ReturnPolicyActions(driver);
    }

    @When("I click on Return Policy link")
    public void i_click_on_return_policy_link() {
        returnPolicyAct.clickReturnPolicy(Hooks.test);
    }

    @Then("I verify Refund information")
    public void i_verify_refund_information() {
        returnPolicyAct.verifyRefund(Hooks.test);
    }

    @And("I verify Telephone contact details")
    public void i_verify_telephone_contact_details() {
        returnPolicyAct.verifyTelephone(Hooks.test);
    }

    @And("I verify Cancellation policy")
    public void i_verify_cancellation_policy() {
        returnPolicyAct.verifyCancellation(Hooks.test);
    }

    @And("I verify Email contact information")
    public void i_verify_email_contact_information() {
        returnPolicyAct.emailVerify(Hooks.test);
    }

    @And("I verify Return Policy heading")
    public void i_verify_return_policy_heading() {
        returnPolicyAct.verifyHeading(Hooks.test);
    }
} 