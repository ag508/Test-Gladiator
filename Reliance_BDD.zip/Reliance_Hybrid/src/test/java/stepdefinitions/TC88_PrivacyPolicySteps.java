package stepdefinitions;

import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import pages.PrivacyPolicyAction;
import utils.Base;

public class TC88_PrivacyPolicySteps extends Base {
    private PrivacyPolicyAction privacyAct;

    public TC88_PrivacyPolicySteps() {
        privacyAct = new PrivacyPolicyAction(driver);
    }

    @When("I click on Privacy Policy link")
    public void i_click_on_privacy_policy_link() {
        privacyAct.clickPrivacyPolicyLink(Hooks.test);
    }

    @Then("I verify Information Collection text")
    public void i_verify_information_collection_text() {
        privacyAct.verifyInfoCollectedText(Hooks.test);
    }

    @And("I verify Opt Out text content")
    public void i_verify_opt_out_text_content() {
        privacyAct.verifyOptOutText(Hooks.test);
    }

    @When("I click on Disclaimer section")
    public void i_click_on_disclaimer_section() {
        privacyAct.clickDisclaimer(Hooks.test);
    }

    @Then("I verify Disclaimer content")
    public void i_verify_disclaimer_content() {
        privacyAct.verifyDisclaimer(Hooks.test);
    }
} 