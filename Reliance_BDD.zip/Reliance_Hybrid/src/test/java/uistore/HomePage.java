package uistore;

import org.openqa.selenium.By;

public class HomePage {
	public static By signup = By.xpath("//a[text()='sign in/signup']");
	
	public static By allJewellery = By.xpath("(//a[text()='All Jewellery'])[1]");
	public static By whatsTrending = By.xpath("(//a[@class='dropdown-toggle'])[2]");
	public static By earrings = By.xpath("(//a[text()='Earrings'])");
	public static By rings = By.xpath("(//a[text()='Rings'])");
	public static By banglesAndBracelet = By.xpath("(//a[@class='dropdown-toggle'])[5]");
	public static By chain = By.xpath("(//a[@class='dropdown-toggle'])[6]");
	public static By pendant = By.xpath("(//a[text()='PENDANTS'])");
	public static By mangalsutra = By.xpath("(//a[text()='Mangalsutra'])");
	public static By other = By.xpath("(//a[text()='Other'])");	
	public static By nosepin = By.xpath("//a[text()='Nosepins']");
	public static By path = By.xpath("//span[text()='Nosepins']");
	public static By search = By.xpath("//input[@placeholder='What are you searching for?']");
	public static By faqLink = By.xpath("(//a[text()='FAQs'])[1]");
    public static By trackOrderLink = By.xpath("(//a[text()='Track An Order'])");
    public static By fastShippingText = By.xpath("(//a[text()='Fast Shipping'])");
    public static By termsConditionsLink = By.xpath("(//a[text()='Terms and Conditions'])[1]");
    public static By storeLocator = By.xpath("//a[text()='Store Locator']");
}
