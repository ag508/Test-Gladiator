package uistore;

import org.openqa.selenium.By;

public class StoreLocator {
	public static By second = By.xpath("//a[text()='2']");
	public static By assam = By.xpath("//a[text()='Assam']");
	public static By previous = By.xpath("//a[text()='Previous']");
	public static By searchBar = By.xpath("//input[@placeholder='Search nearby stores by locality']");
	public static By search = By.xpath("(//span[text()='Search'])[1]");
	

}
