package uistore;

import org.openqa.selenium.By;

public class PrivacyPolicy {
	public static By privacyPolicy = By.xpath("(//a[text()='Privacy Policy'])[1]");
	public static By infoCollected = By.xpath("(//div[@class='footer_about']//h5)[4]");
	public static By optOut = By.xpath("(//div[@class='footer_about']//h5)[7]");
	public static By disclaimer = By.xpath("(//a[text()='Disclaimer'])[1]");
}
