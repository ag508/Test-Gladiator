package uistore;

import org.openqa.selenium.By;


public class WhatsTrending {
	public static By whatsTrending = By.xpath("(//a[@class='dropdown-toggle'])[2]");
	public static By thanjavur = By.xpath("//a[text()='Thanjavur']");
	public static By pummpuhar = By.xpath("//h1[text()='POOMPUHAR']");
	public static By exploreNowPoompuhar = By.xpath(" (//a[contains(text(),'EXPLORE NOW')])[5]");
	public static By clickFourthItem = By.xpath("(//a[@class='srch_rslt_img productTitle'])[4]");
	public static By makeToOrder = By.xpath("(//a[@class='btn '])[3]");
	public static By swarnaBanga = By.xpath("//a[text()='Swarn Banga']");
	public static By swarnaBangaCatalogue = By.xpath("//a[text()='Swarn Banga Catalogue']");
	
}
