package uistore;

import org.openqa.selenium.By;

public class Pendant {
	public static By casualWear = By.xpath("(//a[text()='Casual Wear'])[5]");
	public static By logo = By.xpath("//div[@class='logo']");
	public static By pendant = By.xpath("//h1[text()='Pendants & Pendant Sets']");
	

}
