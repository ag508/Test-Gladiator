package uistore;

import org.openqa.selenium.By;

public class Earrings {
	public static By secondEarring=By.xpath("(//a[@title='Buy 18 Karat Gold & Diamond Earrings'])[1]");
	public static By verifybreadCrumb = By.xpath("//span[text()='18 Karat Gold & Diamond Earrings']");
}
