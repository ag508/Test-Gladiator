package uistore;

import org.openqa.selenium.By;

public class SuiDhaga {
	public static By suiDhaga = By.xpath("//a[text()='Sui Dhaga']");
	

}
