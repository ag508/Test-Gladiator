package uistore;

import org.openqa.selenium.By;

public class SignUp {
	public static By email = By.xpath("//input[@placeholder='Email id or mobile number']");
	public static By password = By.xpath("(//input[@placeholder='Password'])[2]");
	public static By signin = By.xpath("(//a[@class='btn signin-btn'])[1]");
	public static By errmsg =By.xpath("//ul[@class='message_box errormsg mar-top']//h5");
	public static By registerBtn = By.xpath("//a[text()='Register Now']");
	public static By login = By.xpath("//div[text()='Login']");
	public static By loginOtp = By.xpath("//a[@id='signinOtp']");
	public static By forgotPassword = By.xpath("//a[text()='Forgot Password']");
	
	public static By passwordError = By.xpath("//h4[text()='Please enter password']");
	public static By emailError = By.xpath("//h4[text()='Please enter email id or mobile number ']");
}