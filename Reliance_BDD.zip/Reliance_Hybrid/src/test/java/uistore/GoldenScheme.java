package uistore;

import org.openqa.selenium.By;

public class GoldenScheme {
	public static By goldenScheme = By.xpath("(//a[text()='Golden Steps Plan'])[1]");
	public static By termsAndCondition = By.xpath("//a[text()='Reliance Jewels Terms & Conditions']");
	public static By verifyTerms = By.xpath("//h1[text()='Terms and Conditions']");
	public static By goldenScheme2 = By.xpath("(//a[text()='Golden Steps Plan'])[2]");
	public static By login = By.xpath("//a[text()='Login to Golden Steps Scheme']");
}
