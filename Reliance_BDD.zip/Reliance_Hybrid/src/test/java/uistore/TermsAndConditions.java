package uistore;

import org.openqa.selenium.By;

public class TermsAndConditions {
	public static By termsHeading = By.xpath("//div[@class='footer_about']//h1");
	public static By trademark = By.xpath("(//div[@class='footer_about']//h5)[9]");
	public static By nodal = By.xpath("(//div[@class='footer_about']//h5)[20]");
	public static By panCard = By.xpath("//h5[text()='PAN CARD VERIFICATION']");
}
