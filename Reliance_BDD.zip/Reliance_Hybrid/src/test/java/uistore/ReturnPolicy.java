package uistore;

import org.openqa.selenium.By;

public class ReturnPolicy {
	public static By returnPolicy = By.xpath("//a[text()='Return & Refund Policy']");
	public static By returnAndRefund = By.xpath("//div[@class='footer_about']//h1");
	public static By telephone = By.xpath("(//a[text()='1800 891 0001'])[1]");
	public static By text = By.xpath("//h5[text()='2. TERMS FOR CANCELLATION, RETURN AND REFUND OF ORDERS']");
	public static By email = By.xpath("(//a[text()='customerservice@ril.com'])[1]");
	public static By heading = By.xpath("//h1[text()='Refund & Return Policy']");
}
