package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.HomePage;
import uistore.SuiDhaga;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class SuiDhagaActions {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public SuiDhagaActions(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	
	public void clickSuiDhaga(ExtentTest test) {
	    try {
	        helper.clickOn(SuiDhaga.suiDhaga);
	        test.log(Status.PASS, "Clicked on 'Sui Dhaga' successfully.");
	        LoggerHandler.info("Clicked on 'Sui Dhaga' successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on 'Sui Dhaga': " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickSuiDhagaFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on 'Sui Dhaga'");
	        test.log(Status.FAIL, "Failed to click on 'Sui Dhaga': " + e.getMessage());
	    }
	}

	public void verifySearch(ExtentTest test) {
	    try {
	        boolean isDisplayed = driver.findElement(HomePage.search).isDisplayed();
	        if (isDisplayed) {
	            test.log(Status.PASS, "Search field is displayed.");
	            LoggerHandler.info("Search field is displayed.");
	        } else {
	            test.log(Status.FAIL, "Search field is not displayed.");
	            LoggerHandler.warn("Search field is not displayed.");
	        }
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify search field visibility: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifySearchFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify search field visibility");
	        test.log(Status.FAIL, "Exception occurred while verifying search field: " + e.getMessage());
	    }
	}


}
