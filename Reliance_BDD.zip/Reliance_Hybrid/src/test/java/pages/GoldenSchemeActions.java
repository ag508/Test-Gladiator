package pages;


import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.GoldenScheme;
import uistore.HomePage;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class GoldenSchemeActions {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public GoldenSchemeActions(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void verifyEarringsText(ExtentTest test) {
	    try {
	        System.out.println(driver.findElement(HomePage.earrings).getText());
	        helper.verifyTextContains(HomePage.earrings, "EARRINGS");
	        test.log(Status.PASS, "Verified 'Earrings' text successfully.");
	        LoggerHandler.info("Verified 'Earrings' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'Earrings' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyEarringsTextFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'Earrings' text");
	        test.log(Status.FAIL, "Failed to verify 'Earrings' text: " + e.getMessage());
	    }
	}

	public void clickedGolden(ExtentTest test) {
	    try {
	        helper.clickOn(GoldenScheme.goldenScheme);
	        test.log(Status.PASS, "Clicked on Golden Scheme successfully.");
	        LoggerHandler.info("Clicked on Golden Scheme successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Golden Scheme: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickedGoldenFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Golden Scheme");
	        test.log(Status.FAIL, "Failed to click on Golden Scheme: " + e.getMessage());
	    }
	}

	public void scrollToFooter(ExtentTest test) {
	    try {
	        helper.scrollFooter();
	        test.log(Status.PASS, "Scrolled to footer successfully.");
	        LoggerHandler.info("Scrolled to footer successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to scroll to footer: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ScrollToFooterFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to scroll to footer");
	        test.log(Status.FAIL, "Failed to scroll to footer: " + e.getMessage());
	    }
	}

	public void clickTerms(ExtentTest test) {
	    try {
	        helper.clickOn(GoldenScheme.termsAndCondition);
	        test.log(Status.PASS, "Clicked on Terms and Conditions successfully.");
	        LoggerHandler.info("Clicked on Terms and Conditions successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Terms and Conditions: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickTermsFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Terms and Conditions");
	        test.log(Status.FAIL, "Failed to click on Terms and Conditions: " + e.getMessage());
	    }
	}

	public void verifyTermsAndCondition(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(GoldenScheme.verifyTerms, ExcelHandler.readData(0, 39, 0));
	        test.log(Status.PASS, "Verified Terms and Conditions text successfully.");
	        LoggerHandler.info("Verified Terms and Conditions text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify Terms and Conditions text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyTermsFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Terms and Conditions text");
	        test.log(Status.FAIL, "Failed to verify Terms and Conditions text: " + e.getMessage());
	    }
	}

	public void clickGolden2(ExtentTest test) {
	    try {
	        helper.clickOn(GoldenScheme.goldenScheme2);
	        test.log(Status.PASS, "Clicked on Golden Scheme 2 successfully.");
	        LoggerHandler.info("Clicked on Golden Scheme 2 successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Golden Scheme 2: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickGolden2Failure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Golden Scheme 2");
	        test.log(Status.FAIL, "Failed to click on Golden Scheme 2: " + e.getMessage());
	    }
	}

	public void verifyLogin(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(GoldenScheme.login, ExcelHandler.readData(0, 40, 0));
	        test.log(Status.PASS, "Verified Login text successfully.");
	        LoggerHandler.info("Verified Login text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify Login text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyLoginFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Login text");
	        test.log(Status.FAIL, "Failed to verify Login text: " + e.getMessage());
	    }
	}

	public void clickLogin(ExtentTest test) {
	    try {
	        helper.clickOn(GoldenScheme.login);
	        test.log(Status.PASS, "Clicked on Login successfully.");
	        LoggerHandler.info("Clicked on Login successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Login: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickLoginFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Login");
	        test.log(Status.FAIL, "Failed to click on Login: " + e.getMessage());
	    }
	}

}
