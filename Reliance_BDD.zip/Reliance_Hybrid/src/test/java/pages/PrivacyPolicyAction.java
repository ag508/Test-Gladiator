package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.PrivacyPolicy;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class PrivacyPolicyAction {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public PrivacyPolicyAction(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void clickPrivacyPolicyLink(ExtentTest test) {
	    try {
	        helper.clickOn(PrivacyPolicy.privacyPolicy);
	        test.log(Status.PASS, "Clicked on Privacy Policy link successfully.");
	        LoggerHandler.info("Clicked on Privacy Policy link successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Privacy Policy link: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickPrivacyPolicyFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Privacy Policy link");
	        test.log(Status.FAIL, "Failed to click on Privacy Policy link: " + e.getMessage());
	    }
	}
	public void verifyInfoCollectedText(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(PrivacyPolicy.infoCollected, ExcelHandler.readData(0, 28, 0));
	        
	        test.log(Status.PASS, "Verified 'Information Collected' text successfully.");
	        LoggerHandler.info("Verified 'Information Collected' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'Information Collected' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyInfoCollectedFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'Information Collected' text");
	        test.log(Status.FAIL, "Failed to verify 'Information Collected' text: " + e.getMessage());
	    }
	}
	public void verifyOptOutText(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(PrivacyPolicy.optOut, ExcelHandler.readData(0, 29, 0));
	        driver.navigate().back();
	        test.log(Status.PASS, "Verified 'Opt Out' text successfully.");
	        LoggerHandler.info("Verified 'Opt Out' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'Opt Out' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyOptOutFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'Opt Out' text");
	        test.log(Status.FAIL, "Failed to verify 'Opt Out' text: " + e.getMessage());
	    }
	}
	public void clickDisclaimer(ExtentTest test) {
		helper.clickOn(PrivacyPolicy.disclaimer);
		test.log(Status.PASS, "Clicked Disclaimer");
		
	}
	public void verifyDisclaimer(ExtentTest test) {
		helper.verifyLocatorText(PrivacyPolicy.disclaimer, ExcelHandler.readData(0, 30, 0));
		test.log(Status.PASS, "Disclaimer Verified");
	}

}