package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.Pendant;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class PendantAction {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public PendantAction(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void clickPendant(ExtentTest test) {
	    try {
	        helper.clickOn(Pendant.casualWear);
	        test.log(Status.PASS, "Clicked on 'Casual Wear Pendant' successfully.");
	        LoggerHandler.info("Clicked on 'Casual Wear Pendant' successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on 'Casual Wear Pendant': " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickPendantFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on 'Casual Wear Pendant'");
	        test.log(Status.FAIL, "Failed to click on 'Casual Wear Pendant': " + e.getMessage());
	    }
	}

	public void clickLogo(ExtentTest test) {
	    try {
	        helper.verifyLogoDisplayed(Pendant.logo);
	        test.log(Status.PASS, "Logo is displayed successfully.");
	        LoggerHandler.info("Logo is displayed successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify logo display: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("LogoVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify logo display");
	        test.log(Status.FAIL, "Failed to verify logo display: " + e.getMessage());
	    }
	}

	public void verifyPendant(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(Pendant.pendant, ExcelHandler.readData(0, 20, 0));
	        test.log(Status.PASS, "Verified Pendant text successfully.");
	        LoggerHandler.info("Verified Pendant text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify Pendant text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyPendantFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Pendant text");
	        test.log(Status.FAIL, "Failed to verify Pendant text: " + e.getMessage());
	    }
	}

	public void verifyPendantUrl(ExtentTest test) {
	    try {
	        helper.verifyLinkText(ExcelHandler.readData(0, 21, 0));
	        test.log(Status.PASS, "Verified Pendant URL successfully.");
	        LoggerHandler.info("Verified Pendant URL successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify Pendant URL: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyPendantUrlFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Pendant URL");
	        test.log(Status.FAIL, "Failed to verify Pendant URL: " + e.getMessage());
	    }
	}

}
