package pages;

import java.io.IOException;


import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.WebDriver;
import org.junit.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.HomePage;
import uistore.SignUp;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class SignUpActions {
	public static WebDriver driver;
	public static WebDriverHelper helper;

	public SignUpActions(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void verifyLoginUrl(ExtentTest test) {
	    try {
	        String expectedUrlFragment = ExcelHandler.readData(0, 11, 0);
	        helper.verifyLinkText(expectedUrlFragment);

	        test.log(Status.PASS, "Verified login URL contains: " + expectedUrlFragment);
	        LoggerHandler.info("Verified login URL contains: " + expectedUrlFragment);
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify login URL: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("LoginUrlVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify login URL");

	        test.log(Status.FAIL, "Failed to verify login URL: " + e.getMessage());
	    }
	}
	public void verifyLogin() {
	    try {
	    	String expectedLogin = ExcelHandler.readData(0, 12, 0);
	        helper.verifyLocatorText(SignUp.login,expectedLogin );
	        LoggerHandler.info("Login text verified successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify login text: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("LoginTextVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, null, "Failed to verify login text");
	    }
	}
	public void verifyRegister() {
	    try {
	    	String expectedRegister = ExcelHandler.readData(0, 13, 0);
	        helper.verifyLocatorText(SignUp.registerBtn, expectedRegister);
	        LoggerHandler.info("Register button text verified successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify register button text: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("RegisterTextVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, null, "Failed to verify register button text");
	    }
	}

	public void enterInvalidEmail(ExtentTest test) throws IOException {
	    try {
	        String email = ExcelHandler.readData(0, 0, 0);
	        helper.sendText(SignUp.email, email);
	        helper.enterKey(SignUp.email);

	        test.log(Status.PASS, "Entered invalid email from Excel: " + email);
	        LoggerHandler.info("Entered invalid email from Excel: " + email);
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to enter invalid email: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("InvalidEmailEntry");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to enter invalid email");

	        test.log(Status.FAIL, "Failed to enter invalid email: " + e.getMessage());
	    }
	}
	public void verifyForgotPassword(ExtentTest test) {
	    try {
	    	String expectedString = ExcelHandler.readData(0, 14, 0);
	        helper.verifyLocatorText(SignUp.forgotPassword, expectedString);
	        LoggerHandler.info("Forgot password text verified successfully.");
	        test.log(Status.PASS, "Forgot password text verified successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify forgot password text: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ForgotPasswordTextVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify forgot password text");

	        test.log(Status.FAIL, "Failed to verify forgot password text: " + e.getMessage());
	    }
	}

	public void verifyLoginOtp(ExtentTest test) {
	    try {
	    	String expectedString = ExcelHandler.readData(0, 12, 0);
	        helper.verifyLocatorText(SignUp.loginOtp, expectedString);
	        LoggerHandler.info("Login OTP text verified successfully.");
	        test.log(Status.PASS, "Login OTP text verified successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify login OTP text: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("LoginOtpTextVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify login OTP text");

	        test.log(Status.FAIL, "Failed to verify login OTP text: " + e.getMessage());
	    }
	}


	public void enterPasswordAndSignIn(ExtentTest test) throws IOException {
	    try {
	        String password = ExcelHandler.readData(0, 1, 0);
	        helper.sendText(SignUp.password, password);
	        helper.clickOn(SignUp.signin);

	        test.log(Status.PASS, "Entered password and clicked Sign In.");
	        LoggerHandler.info("Entered password and clicked Sign In.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to enter password or click Sign In: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("PasswordSignInFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to enter password or click Sign In");

	        test.log(Status.FAIL, "Failed to enter password or click Sign In: " + e.getMessage());
	    }
	}



	public void verifyErrorMessage(ExtentTest test) {
	    try {
	        String actualError = driver.findElement(SignUp.errmsg).getText();
	        String expectedError = ExcelHandler.readData(0, 2, 0);

	        Assert.assertEquals(actualError, expectedError);

	        test.log(Status.PASS, "Error message matched: " + actualError);
	        LoggerHandler.info("Error message verified successfully");
	    } catch (AssertionError | Exception e) {
	        LoggerHandler.error("Error message verification failed: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ErrorMessageVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Error message verification failed");

	        test.log(Status.FAIL, "Error message verification failed: " + e.getMessage());
	    }
	}

	
	public void inputEmailFromExcel(ExtentTest test) {
	    try {
	        String email = ExcelHandler.readData(0, 3, 0);
	        helper.sendText(SignUp.email, email);
	        helper.enterKey(SignUp.email);

	        test.log(Status.PASS, "Entered email from Excel: " + email);
	        LoggerHandler.info("Entered email from Excel: " + email);
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to enter email: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("EmailEntryFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to enter email");

	        test.log(Status.FAIL, "Failed to enter email: " + e.getMessage());
	    }
	}
	public void inputInvalidPasswordFromExcel(ExtentTest test) {
	    try {
	        String password = ExcelHandler.readData(0, 4, 0);
	        helper.sendText(SignUp.password, password);

	        test.log(Status.PASS, "Entered invalid password from Excel.");
	        LoggerHandler.info("Entered invalid password from Excel.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to enter password: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("PasswordEntryFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to enter password");

	        test.log(Status.FAIL, "Failed to enter password: " + e.getMessage());
	    }
	}
	public void performSignInClick(ExtentTest test) {
	    try {
	        helper.clickOn(SignUp.signin);

	        test.log(Status.PASS, "Clicked on Sign In button.");
	        LoggerHandler.info("Clicked on Sign In button.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click Sign In: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("SignInClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click Sign In");

	        test.log(Status.FAIL, "Failed to click Sign In: " + e.getMessage());
	    }
	}


	public void verifyErrorMsg(ExtentTest test) {
	    try {
	        String actualError = driver.findElement(SignUp.errmsg).getText();
	        String expectedError = ExcelHandler.readData(0, 6, 0);

	        if (actualError.equals(expectedError)) {
	            test.log(Status.PASS, "Error message matched: " + actualError);
	            LoggerHandler.info("Error message verified successfully");
	        } else {
	            test.log(Status.FAIL, "Expected: " + expectedError + " | Actual: " + actualError);
	            LoggerHandler.error("Mismatch in error message");

	            String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ErrorMessageMismatch");
	            Reporter.attachScreenshotToReport(screenshotPath, test, "Mismatch in error message");
	        }
	    } catch (Exception e) {
	        LoggerHandler.error("Error verifying message: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ErrorMessageVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Exception during error message verification");

	        test.log(Status.FAIL, "Exception during error message verification: " + e.getMessage());
	    }
	}

	public void inputUnregisteredEmail(ExtentTest test) {
	    try {
	        String email = ExcelHandler.readData(0, 5, 0);
	        helper.sendText(SignUp.email, email);

	        test.log(Status.PASS, "Entered unregistered email from Excel: " + email);
	        LoggerHandler.info("Entered unregistered email from Excel: " + email);
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to enter unregistered email: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("UnregisteredEmailEntryFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to enter unregistered email");

	        test.log(Status.FAIL, "Failed to enter unregistered email: " + e.getMessage());
	    }
	}
	public void triggerForgotPassword(ExtentTest test) {
	    try {
	        helper.clickOn(SignUp.forgotPassword);

	        test.log(Status.PASS, "Clicked on Forgot Password.");
	        LoggerHandler.info("Clicked on Forgot Password.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click Forgot Password: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ForgotPasswordClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click Forgot Password");

	        test.log(Status.FAIL, "Failed to click Forgot Password: " + e.getMessage());
	    }
	}
	public void validateForgotPasswordError(ExtentTest test) {
	    try {
	        String actualError = driver.findElement(SignUp.errmsg).getText();
	        String expectedError = ExcelHandler.readData(0, 6, 0); 

	        if (actualError.equals(expectedError)) {
	            test.log(Status.PASS, "Error message matched: " + actualError);
	            LoggerHandler.info("Forgot password error message verified successfully");
	        } else {
	            test.log(Status.FAIL, "Expected: " + expectedError + " | Actual: " + actualError);
	            LoggerHandler.error("Mismatch in forgot password error message");

	            String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ForgotPasswordErrorMismatch");
	            Reporter.attachScreenshotToReport(screenshotPath, test, "Mismatch in forgot password error message");
	        }
	    } catch (Exception e) {
	        LoggerHandler.error("Error verifying forgot password message: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ForgotPasswordErrorVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Exception during forgot password error verification");

	        test.log(Status.FAIL, "Exception during forgot password error verification: " + e.getMessage());
	    }
	}


	
	public void emptyEmailAndPasswordFields(ExtentTest test) {
	    try {
	        helper.clickOn(SignUp.signin);

	        test.log(Status.PASS, "Clicked on Sign In with empty email and password fields.");
	        LoggerHandler.info("Clicked on Sign In with empty email and password fields.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click Sign In: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("SignInClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click Sign In");

	        test.log(Status.FAIL, "Failed to click Sign In: " + e.getMessage());
	    }
	    
	}
	public void passwordError(ExtentTest test) {
	    try {
	    	
	    	System.out.println(driver.findElement(SignUp.passwordError).getAttribute("innerText"));
	        String expectedString = ExcelHandler.readData(0, 15, 0);
	    	helper.verifyLocatorText(SignUp.passwordError, expectedString);
	        LoggerHandler.info("Empty error message verified successfully.");
	        test.log(Status.PASS, "Empty error message verified successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify empty error message: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("EmptyErrorVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify empty error message");

	        test.log(Status.FAIL, "Failed to verify empty error message: " + e.getMessage());
	    }
	}
	public void emailError(ExtentTest test) {
	    try {
	    	System.out.println(driver.findElement(SignUp.emailError).getAttribute("innerText"));
	    	String expectedString = ExcelHandler.readData(0, 15, 0);
	        helper.verifyLocatorText(SignUp.emailError, expectedString);
	        LoggerHandler.info("Empty error message verified successfully.");
	        test.log(Status.PASS, "Empty error message verified successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify empty error message: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("EmptyErrorVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify empty error message");

	        test.log(Status.FAIL, "Failed to verify empty error message: " + e.getMessage());
	    }
	}

		
}

