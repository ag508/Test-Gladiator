package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import uistore.ReturnPolicy;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class ReturnPolicyActions {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public ReturnPolicyActions(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void clickReturnPolicy(ExtentTest test) {
	    try {
	        helper.clickOn(ReturnPolicy.returnPolicy);
	        test.log(Status.PASS, "Clicked on Return Policy link successfully.");
	        LoggerHandler.info("Clicked on Return Policy link successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Return Policy link: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickReturnPolicyFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Return Policy link");
	        test.log(Status.FAIL, "Failed to click on Return Policy link: " + e.getMessage());
	    }
	}

	public void verifyRefund(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(ReturnPolicy.returnAndRefund, ExcelHandler.readData(0, 31, 0));
	        test.log(Status.PASS, "Verified 'Return' text successfully.");
	        LoggerHandler.info("Verified 'Return' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'Return' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyRefundFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'Return' text");
	        test.log(Status.FAIL, "Failed to verify 'Return' text: " + e.getMessage());
	    }
	}

	public void verifyTelephone(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(ReturnPolicy.telephone, ExcelHandler.readData(0, 32, 0));
	        test.log(Status.PASS, "Verified telephone number successfully.");
	        LoggerHandler.info("Verified telephone number successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify telephone number: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyTelephoneFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify telephone number");
	        test.log(Status.FAIL, "Failed to verify telephone number: " + e.getMessage());
	    }
	}

	public void verifyCancellation(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(ReturnPolicy.text, ExcelHandler.readData(0, 33, 0));
	        test.log(Status.PASS, "Verified 'CANCELLATION' text successfully.");
	        LoggerHandler.info("Verified 'CANCELLATION' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'CANCELLATION' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyCancellationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'CANCELLATION' text");
	        test.log(Status.FAIL, "Failed to verify 'CANCELLATION' text: " + e.getMessage());
	    }
	}

	public void emailVerify(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(ReturnPolicy.email, ExcelHandler.readData(0, 34, 0));
	        test.log(Status.PASS, "Verified email text successfully.");
	        LoggerHandler.info("Verified email text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify email text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyEmailFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify email text");
	        test.log(Status.FAIL, "Failed to verify email text: " + e.getMessage());
	    }
	}

	public void verifyHeading(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(ReturnPolicy.heading, ExcelHandler.readData(0, 35, 0));
	        test.log(Status.PASS, "Verified heading text successfully.");
	        LoggerHandler.info("Verified heading text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify heading text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyHeadingFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify heading text");
	        test.log(Status.FAIL, "Failed to verify heading text: " + e.getMessage());
	    }
	}


}
