package pages;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.Earrings;
import uistore.HomePage;

import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class HomePageActions {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public HomePageActions(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void clickonSignIn(ExtentTest test) {
	    try {
	        helper.clickOn(HomePage.signup);
	        test.log(Status.PASS, "Clicked on Sign In successfully.");
	        LoggerHandler.info("Clicked on Sign In successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Sign In: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("SignIn_Click_Failure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Click on Sign In failed");
	        test.log(Status.FAIL, "Click on Sign In failed: " + e.getMessage());
	    }
	}
	
	

	public void hoverAndClickAllJewellery(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.allJewellery);
	        helper.clickOn(HomePage.allJewellery);

	        test.log(Status.PASS, "Hovered and clicked on All Jewellery.");
	        LoggerHandler.info("Hovered and clicked on All Jewellery.");

	        driver.navigate().back();
	        LoggerHandler.info("Navigated back after clicking All Jewellery.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover and click on All Jewellery: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("AllJewelleryClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover and click on All Jewellery");

	        test.log(Status.FAIL, "Failed to hover and click on All Jewellery: " + e.getMessage());
	    }
	}

	public void hoverAndClickEarrings(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.earrings);
	        helper.clickOn(HomePage.earrings);

	        test.log(Status.PASS, "Hovered and clicked on Earrings.");
	        LoggerHandler.info("Hovered and clicked on Earrings.");

	        driver.navigate().back();
	        LoggerHandler.info("Navigated back after clicking Earrings.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover and click on Earrings: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("EarringsClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover and click on Earrings");

	        test.log(Status.FAIL, "Failed to hover and click on Earrings: " + e.getMessage());
	    }
	}

	public void hoverAndClickRings(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.rings);
	        helper.clickOn(HomePage.rings);

	        test.log(Status.PASS, "Hovered and clicked on Rings.");
	        LoggerHandler.info("Hovered and clicked on Rings.");

	        driver.navigate().back();
	        LoggerHandler.info("Navigated back after clicking Rings.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover and click on Rings: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("RingsClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover and click on Rings");

	        test.log(Status.FAIL, "Failed to hover and click on Rings: " + e.getMessage());
	    }
	}

	public void hoverAndClickBanglesAndBracelet(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.banglesAndBracelet);
	        helper.clickOn(HomePage.banglesAndBracelet);

	        test.log(Status.PASS, "Hovered and clicked on Bangles & Bracelet.");
	        LoggerHandler.info("Hovered and clicked on Bangles & Bracelet.");

	        driver.navigate().back();
	        LoggerHandler.info("Navigated back after clicking Bangles & Bracelet.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover and click on Bangles & Bracelet: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("BanglesBraceletClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover and click on Bangles & Bracelet");

	        test.log(Status.FAIL, "Failed to hover and click on Bangles & Bracelet: " + e.getMessage());
	    }
	}

	public void hoverAndClickChain(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.chain);
	        helper.clickOn(HomePage.chain);

	        test.log(Status.PASS, "Hovered and clicked on Chain.");
	        LoggerHandler.info("Hovered and clicked on Chain.");

	        driver.navigate().back();
	        LoggerHandler.info("Navigated back after clicking Chain.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover and click on Chain: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ChainClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover and click on Chain");

	        test.log(Status.FAIL, "Failed to hover and click on Chain: " + e.getMessage());
	    }
	}

	public void hoverAndClickPendant(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.pendant);
	        helper.clickOn(HomePage.pendant);

	        test.log(Status.PASS, "Hovered and clicked on Pendant.");
	        LoggerHandler.info("Hovered and clicked on Pendant.");

	        driver.navigate().back();
	        LoggerHandler.info("Navigated back after clicking Pendant.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover and click on Pendant: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("PendantClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover and click on Pendant");

	        test.log(Status.FAIL, "Failed to hover and click on Pendant: " + e.getMessage());
	    }
	}

	public void hoverAndClickMangalsutra(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.mangalsutra);
	        helper.clickOn(HomePage.mangalsutra);

	        test.log(Status.PASS, "Hovered and clicked on Mangalsutra.");
	        LoggerHandler.info("Hovered and clicked on Mangalsutra.");

	        driver.navigate().back();
	        LoggerHandler.info("Navigated back after clicking Mangalsutra.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover and click on Mangalsutra: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("MangalsutraClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover and click on Mangalsutra");

	        test.log(Status.FAIL, "Failed to hover and click on Mangalsutra: " + e.getMessage());
	    }
	}

	public void hoverAndClickOther(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.other);
	        helper.clickOn(HomePage.nosepin);
	        helper.verifyTextContains(HomePage.path, "Nosepins");

	        test.log(Status.PASS, "Hovered on 'Other', clicked on 'Nosepin', and verified text 'Nosepins'.");
	        LoggerHandler.info("Hovered on 'Other', clicked on 'Nosepin', and verified text 'Nosepins'.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover/click/verify Nosepin: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("OtherNosepinClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover/click/verify Nosepin");

	        test.log(Status.FAIL, "Failed to hover/click/verify Nosepin: " + e.getMessage());
	    }
	}

	public void scrollToEarrings(ExtentTest test) {
	    try {
	        helper.scrollIntoView(HomePage.earrings);
	        test.log(Status.PASS, "Scrolled to 'Earrings' element successfully.");
	        LoggerHandler.info("Scrolled to 'Earrings' element successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to scroll to 'Earrings': " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ScrollToEarringsFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to scroll to 'Earrings'");
	        test.log(Status.FAIL, "Failed to scroll to 'Earrings': " + e.getMessage());
	    }
	}
	public void clickOnEarrings(ExtentTest test) {
	    try {
	        helper.jsClick(HomePage.earrings);
	        test.log(Status.PASS, "Clicked on 'Earrings' successfully.");
	        LoggerHandler.info("Clicked on 'Earrings' successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on 'Earrings': " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickOnEarringsFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on 'Earrings'");
	        test.log(Status.FAIL, "Failed to click on 'Earrings': " + e.getMessage());
	    }
	}
	public void verifyEarringsText(ExtentTest test) {
	    try {
	        System.out.println(driver.findElement(HomePage.earrings).getText());
	        String expectedString = ExcelHandler.readData(0, 17, 0);
	        helper.verifyTextContains(HomePage.earrings, expectedString);
	        test.log(Status.PASS, "Verified 'Earrings' text successfully.");
	        LoggerHandler.info("Verified 'Earrings' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'Earrings' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyEarringsTextFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'Earrings' text");
	        test.log(Status.FAIL, "Failed to verify 'Earrings' text: " + e.getMessage());
	    }
	}

	public void clickSearchField(ExtentTest test) {
	    try {
	        helper.clickOn(HomePage.search);
	        test.log(Status.PASS, "Clicked on the search field successfully.");
	        LoggerHandler.info("Clicked on the search field successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on the search field: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickSearchFieldFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on the search field");
	        test.log(Status.FAIL, "Failed to click on the search field: " + e.getMessage());
	    }
	}
	public void enterSearchText(ExtentTest test) {
	    try {
	        String text = ExcelHandler.readData(0, 10, 0);
	        helper.sendText(HomePage.search, text);
	        test.log(Status.PASS, "Entered search text successfully: " + text);
	        LoggerHandler.info("Entered search text successfully: " + text);
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to enter search text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("EnterSearchTextFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to enter search text");
	        test.log(Status.FAIL, "Failed to enter search text: " + e.getMessage());
	    }
	}
	public void hoverOverEarrings(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.earrings);
	        test.log(Status.PASS, "Hovered over 'Earrings' element successfully.");
	        LoggerHandler.info("Hovered over 'Earrings' element successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover over 'Earrings': " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("HoverOverEarringsFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover over 'Earrings'");
	        test.log(Status.FAIL, "Failed to hover over 'Earrings': " + e.getMessage());
	    }
	}


	public void hoverPendant(ExtentTest test) {
	    try {
	        helper.hoverOverElement(HomePage.pendant);
	        test.log(Status.PASS, "Hovered over 'Pendant' successfully.");
	        LoggerHandler.info("Hovered over 'Pendant' successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover over 'Pendant': " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("HoverPendantFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover over 'Pendant'");
	        test.log(Status.FAIL, "Failed to hover over 'Pendant': " + e.getMessage());
	    }
	}

	public void clickFaqLink(ExtentTest test) {
	    try {
	        helper.clickOn(HomePage.faqLink);
	        
	        helper.verifyLocatorText(HomePage.faqLink, ExcelHandler.readData(0, 22, 0));
			driver.navigate().back();
	        test.log(Status.PASS, "Clicked on FAQ link successfully.");
	        LoggerHandler.info("Clicked on FAQ link successfully.");
	        driver.navigate().back();
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on FAQ link: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickFaqLinkFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on FAQ link");
	        test.log(Status.FAIL, "Failed to click on FAQ link: " + e.getMessage());
	    }
	}
	public void clickTrackOrderLink(ExtentTest test) {
	    try {
	        helper.clickOn(HomePage.trackOrderLink);
	        test.log(Status.PASS, "Clicked on Track Order link successfully.");
	        LoggerHandler.info("Clicked on Track Order link successfully.");
	        driver.navigate().back();
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Track Order link: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickTrackOrderLinkFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Track Order link");
	        test.log(Status.FAIL, "Failed to click on Track Order link: " + e.getMessage());
	    }
	}
	public void clickFastShippingText(ExtentTest test) {
	    try {
	        helper.clickOn(HomePage.fastShippingText);
	        test.log(Status.PASS, "Clicked on Fast Shipping text successfully.");
	        LoggerHandler.info("Clicked on Fast Shipping text successfully.");
	        driver.navigate().back();
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Fast Shipping text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickFastShippingTextFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Fast Shipping text");
	        test.log(Status.FAIL, "Failed to click on Fast Shipping text: " + e.getMessage());
	    }
	}
	public void verifyUrl(ExtentTest test) {
		helper.verifyLinkText(ExcelHandler.readData(0, 23, 0));
		test.log(Status.PASS, "Url Verified");
	}

	
	
	
}
	
