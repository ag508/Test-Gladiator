package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.Earrings;
import uistore.HomePage;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class EarringsAction {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	public static ExtentTest test;
	
	public EarringsAction(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	
	public void clickSecondEarring(ExtentTest test) {
	    try {
	        helper.clickOn(Earrings.secondEarring);
	        test.log(Status.PASS, "Clicked on the second earring successfully.");
	        LoggerHandler.info("Clicked on the second earring successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on the second earring: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickSecondEarringFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on the second earring");
	        test.log(Status.FAIL, "Failed to click on the second earring: " + e.getMessage());
	    }
	}
	public void verifyEarringBreadcrumb(ExtentTest test) {
	    try {
	    	String expectedString = ExcelHandler.readData(0, 18, 0);
	        helper.verifyLocatorText(Earrings.verifybreadCrumb,expectedString );
	        test.log(Status.PASS, "Breadcrumb text verified successfully.");
	        LoggerHandler.info("Breadcrumb text verified successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify breadcrumb text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyBreadcrumbFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify breadcrumb text");
	        test.log(Status.FAIL, "Failed to verify breadcrumb text: " + e.getMessage());
	    }
	}


	public void verifyTitle(ExtentTest test) {
	    try {
	    	System.out.println(driver.getTitle());
	        helper.verifyPageTitle(ExcelHandler.readData(0, 19, 0));
	        test.log(Status.PASS, "Page title verified successfully: 'earrings'");
	        LoggerHandler.info("Page title verified successfully: 'earrings'");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify page title: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("PageTitleVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify page title");

	        test.log(Status.FAIL, "Failed to verify page title: " + e.getMessage());
	    }
	}

	

}
