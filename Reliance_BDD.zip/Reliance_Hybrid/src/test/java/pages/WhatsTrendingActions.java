package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.WhatsTrending;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class WhatsTrendingActions {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public WhatsTrendingActions(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void hoverWhatsTrending(ExtentTest test) {
	    try {
	        helper.hoverOverElement(WhatsTrending.whatsTrending);
	        test.log(Status.PASS, "Hovered over 'What's Trending' section.");
	        LoggerHandler.info("Hovered over 'What's Trending' section.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to hover over 'What's Trending': " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("WhatsTrendingHoverFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to hover over 'What's Trending'");

	        test.log(Status.FAIL, "Failed to hover over 'What's Trending': " + e.getMessage());
	    }
	}

	public void clickThanjavur(ExtentTest test) {
	    try {
	        helper.clickOn(WhatsTrending.thanjavur);

	        test.log(Status.PASS, "Clicked on 'Thanjavur' in What's Trending.");
	        LoggerHandler.info("Clicked on 'Thanjavur' in What's Trending.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on 'Thanjavur': " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ThanjavurClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on 'Thanjavur'");

	        test.log(Status.FAIL, "Failed to click on 'Thanjavur': " + e.getMessage());
	    }
	}

	public void clickexploreNowPoompuhar(ExtentTest test) {
	    try {
	        helper.scrollToElement(WhatsTrending.exploreNowPoompuhar);
	        helper.waitForElementClickable(WhatsTrending.exploreNowPoompuhar);
	        helper.jsClick(WhatsTrending.exploreNowPoompuhar);

	        test.log(Status.PASS, "Clicked on 'Explore Now - Poompuhar'.");
	        LoggerHandler.info("Clicked on 'Explore Now - Poompuhar'.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on 'Explore Now - Poompuhar': " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ExploreNowPoompuharClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on 'Explore Now - Poompuhar'");

	        test.log(Status.FAIL, "Failed to click on 'Explore Now - Poompuhar': " + e.getMessage());
	    }
	}

	public void verifyUrl(ExtentTest test) {
	  
	    try {
	    	System.out.println(driver.getTitle());
	        String expectedTitle = ExcelHandler.readData(0, 7, 0);
	        System.out.println(expectedTitle);
	        
	        helper.verifyPageTitle(expectedTitle);

	        test.log(Status.PASS, "Page title verified successfully: " + expectedTitle);
	        LoggerHandler.info("Page title verified successfully: " + expectedTitle);
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify page title: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("PageTitleVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify page title");

	        test.log(Status.FAIL, "Failed to verify page title: " + e.getMessage());
	    }

	    try {
	        String expectedLinkText = ExcelHandler.readData(0, 8, 0);
	        helper.verifyLinkText(expectedLinkText);
	        System.out.println(expectedLinkText);
	        System.out.println(driver.getCurrentUrl());
	        test.log(Status.PASS, "Link text verified successfully: " + expectedLinkText);
	        LoggerHandler.info("Link text verified successfully: " + expectedLinkText);
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify link text: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("LinkTextVerificationFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify link text");

	        test.log(Status.FAIL, "Failed to verify link text: " + e.getMessage());
	    }
	}

	public void clickFourthItem(ExtentTest test) {
	    try {
	        helper.scrollIntoView(WhatsTrending.clickFourthItem);
	        helper.clickOn(WhatsTrending.clickFourthItem);

	        test.log(Status.PASS, "Clicked on the fourth item in What's Trending.");
	        LoggerHandler.info("Clicked on the fourth item in What's Trending.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on the fourth item: " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickFourthItemFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on the fourth item");

	        test.log(Status.FAIL, "Failed to click on the fourth item: " + e.getMessage());
	    }
	}
	public void clickMakeToOrder(ExtentTest test) {
	    try {
	    	System.out.println(driver.findElement(WhatsTrending.makeToOrder).getText());
	    	String expectedString = ExcelHandler.readData(0, 16, 0);
	        helper.verifyLocatorText(WhatsTrending.makeToOrder,expectedString );
	        helper.clickOn(WhatsTrending.makeToOrder);

	        test.log(Status.PASS, "Clicked on 'Make to Order' successfully.");
	        LoggerHandler.info("Clicked on 'Make to Order' successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on 'Make to Order': " + e.getMessage());

	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("MakeToOrderClickFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Click failure on 'Make to Order'");

	        test.log(Status.FAIL, "Exception occurred while clicking 'Make to Order': " + e.getMessage());
	    }
	}



	

	public void scrollCatalogueIntoView(ExtentTest test) {
	    try {
	    	helper.scrollFooter();
	        helper.scrollIntoView(WhatsTrending.swarnaBangaCatalogue);
	        test.log(Status.PASS, "Scrolled Swarna Banga Catalogue into view.");
	        LoggerHandler.info("Scrolled Swarna Banga Catalogue into view.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to scroll element into view: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ScrollIntoViewFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to scroll element into view");
	        test.log(Status.FAIL, "Failed to scroll element into view: " + e.getMessage());
	    }
	}
	public void waitForCatalogueVisibility(ExtentTest test) {
		
	    try {
	        helper.waitForElementVisible(WhatsTrending.swarnaBangaCatalogue);
	        test.log(Status.PASS, "Swarna Banga Catalogue is visible.");
	        LoggerHandler.info("Swarna Banga Catalogue is visible.");
	    } catch (Exception e) {
	        LoggerHandler.error("Element not visible: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ElementVisibilityFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Element not visible");
	        test.log(Status.FAIL, "Element not visible: " + e.getMessage());
	    }
	}



public void clickSwarnaBanga(ExtentTest test) {
    try {
        helper.clickOn(WhatsTrending.swarnaBanga);

        test.log(Status.PASS, "Clicked on 'Swarna Banga' in What's Trending.");
        LoggerHandler.info("Clicked on 'Swarna Banga' in What's Trending.");
    } catch (Exception e) {
        LoggerHandler.error("Failed to click on 'Swarna Banga': " + e.getMessage());

        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("SwarnaBangaClickFailure");
        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on 'Swarna Banga'");

        test.log(Status.FAIL, "Failed to click on 'Swarna Banga': " + e.getMessage());
    }
}
public void clickSwarnaBangaCatalogue(ExtentTest test) {
    try {
        helper.scrollFooter();
        helper.scrollIntoView(WhatsTrending.swarnaBangaCatalogue);
        helper.waitForElementVisible(WhatsTrending.swarnaBangaCatalogue);
        helper.hoverOverElement(WhatsTrending.swarnaBangaCatalogue);
        helper.clickOn(WhatsTrending.swarnaBangaCatalogue);

        test.log(Status.PASS, "Successfully clicked on Swarna Banga Catalogue.");
        LoggerHandler.info("Successfully clicked on Swarna Banga Catalogue.");
    } catch (Exception e) {
        LoggerHandler.error("Failed to click on Swarna Banga Catalogue: " + e.getMessage());

        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("SwarnaBangaCatalogueClickFailure");
        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Swarna Banga Catalogue");

        test.log(Status.FAIL, "Failed to click on Swarna Banga Catalogue: " + e.getMessage());
    }
}



public void verifySwarnaBangaUrl(ExtentTest test) {
    try {
    	
        String expectedUrlFragment = ExcelHandler.readData(0, 9, 0);
        System.out.println(expectedUrlFragment);
        System.out.println(driver.getCurrentUrl());
        helper.verifyLinkText(expectedUrlFragment);

        test.log(Status.PASS, "Verified Swarna Banga URL contains: " + expectedUrlFragment);
        LoggerHandler.info("Verified Swarna Banga URL contains: " + expectedUrlFragment);

        driver.navigate().back();
        LoggerHandler.info("Navigated back after URL verification.");
    } catch (Exception e) {
        LoggerHandler.error("Failed to verify Swarna Banga URL: " + e.getMessage());

        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("SwarnaBangaUrlVerificationFailure");
        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Swarna Banga URL");

        test.log(Status.FAIL, "Failed to verify Swarna Banga URL: " + e.getMessage());
    }
}


		
	
}