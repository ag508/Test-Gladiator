package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.HomePage;
import uistore.StoreLocator;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class StoreLocatorActions {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public StoreLocatorActions(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void clickStoreLocator(ExtentTest test) {
	    try {
	        helper.clickOn(HomePage.storeLocator);
	        test.log(Status.PASS, "Clicked on Store Locator successfully.");
	        LoggerHandler.info("Clicked on Store Locator successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Store Locator: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickStoreLocatorFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Store Locator");
	        test.log(Status.FAIL, "Failed to click on Store Locator: " + e.getMessage());
	    }
	}

	public void scrollToFooter(ExtentTest test) {
	    try {
	        helper.scrollFooter();
	        test.log(Status.PASS, "Scrolled to footer successfully.");
	        LoggerHandler.info("Scrolled to footer successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to scroll to footer: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ScrollToFooterFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to scroll to footer");
	        test.log(Status.FAIL, "Failed to scroll to footer: " + e.getMessage());
	    }
	}

	public void secondPage(ExtentTest test) {
	    try {
	    	helper.waitForElementClickable(StoreLocator.second);
	        helper.jsClick(StoreLocator.second);
	        test.log(Status.PASS, "Navigated to second page successfully.");
	        LoggerHandler.info("Navigated to second page successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to navigate to second page: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("SecondPageFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to navigate to second page");
	        test.log(Status.FAIL, "Failed to navigate to second page: " + e.getMessage());
	    }
	}

	public void verifyAssam(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(StoreLocator.assam, ExcelHandler.readData(0, 36, 0));
	        test.log(Status.PASS, "Verified 'Assam' text successfully.");
	        LoggerHandler.info("Verified 'Assam' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'Assam' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyAssamFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'Assam' text");
	        test.log(Status.FAIL, "Failed to verify 'Assam' text: " + e.getMessage());
	    }
	}

	public void clickPrevious(ExtentTest test) {
	    try {
	    	helper.waitForElementClickable(StoreLocator.previous);
	        helper.jsClick(StoreLocator.previous);
	        test.log(Status.PASS, "Clicked on Previous button successfully.");
	        LoggerHandler.info("Clicked on Previous button successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Previous button: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickPreviousFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Previous button");
	        test.log(Status.FAIL, "Failed to click on Previous button: " + e.getMessage());
	    }
	}

	public void clickSearchBar(ExtentTest test) {
	    try {
	    	helper.waitForElementClickable(StoreLocator.searchBar);
	        helper.jsClick(StoreLocator.searchBar);
	        test.log(Status.PASS, "Clicked on Search Bar successfully.");
	        LoggerHandler.info("Clicked on Search Bar successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Search Bar: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickSearchBarFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Search Bar");
	        test.log(Status.FAIL, "Failed to click on Search Bar: " + e.getMessage());
	    }
	}

	public void enterTextInSearchBar(ExtentTest test) {
	    try {
	        helper.sendText(StoreLocator.searchBar, ExcelHandler.readData(0, 37, 0));
	        test.log(Status.PASS, "Entered text 'Hyderabad' in Search Bar successfully.");
	        LoggerHandler.info("Entered text 'Hyderabad' in Search Bar successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to enter text in Search Bar: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("EnterTextSearchBarFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to enter text in Search Bar");
	        test.log(Status.FAIL, "Failed to enter text in Search Bar: " + e.getMessage());
	    }
	}

	public void clickSearch(ExtentTest test) {
	    try {
	    	helper.waitForElementClickable(StoreLocator.search);
	        helper.clickOn(StoreLocator.search);
	        test.log(Status.PASS, "Clicked on Search button successfully.");
	        LoggerHandler.info("Clicked on Search button successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Search button: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickSearchFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Search button");
	        test.log(Status.FAIL, "Failed to click on Search button: " + e.getMessage());
	    }
	}

	public void verifySearch(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(StoreLocator.search, ExcelHandler.readData(0, 38, 0));
	        test.log(Status.PASS, "Verified 'Search' text successfully.");
	        LoggerHandler.info("Verified 'Search' text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify 'Search' text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifySearchFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify 'Search' text");
	        test.log(Status.FAIL, "Failed to verify 'Search' text: " + e.getMessage());
	    }
	}

	
}
