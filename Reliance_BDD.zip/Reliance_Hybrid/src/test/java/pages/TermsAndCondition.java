package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.HomePage;
import uistore.TermsAndConditions;
import utils.ExcelHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.WebDriverHelper;

public class TermsAndCondition {
	public static WebDriver driver;
	public static WebDriverHelper helper;
	
	public TermsAndCondition(WebDriver driver) {
		this.driver =driver;
		helper = new WebDriverHelper(driver);
	}
	public void clickTermsAndConditionsLink(ExtentTest test) {
	    try {
	        helper.clickOn(HomePage.termsConditionsLink);
	        test.log(Status.PASS, "Clicked on Terms & Conditions link successfully.");
	        LoggerHandler.info("Clicked on Terms & Conditions link successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to click on Terms & Conditions link: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("ClickTermsConditionsLinkFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to click on Terms & Conditions link");
	        test.log(Status.FAIL, "Failed to click on Terms & Conditions link: " + e.getMessage());
	    }
	}
	public void verifyTermsHeading(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(TermsAndConditions.termsHeading, ExcelHandler.readData(0, 24, 0));
	        test.log(Status.PASS, "Verified Terms heading successfully.");
	        LoggerHandler.info("Verified Terms heading successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify Terms heading: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyTermsHeadingFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Terms heading");
	        test.log(Status.FAIL, "Failed to verify Terms heading: " + e.getMessage());
	    }
	}

	public void verifyTrademarkText(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(TermsAndConditions.trademark, ExcelHandler.readData(0, 25, 0));
	        test.log(Status.PASS, "Verified Trademark text successfully.");
	        LoggerHandler.info("Verified Trademark text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify Trademark text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyTrademarkTextFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Trademark text");
	        test.log(Status.FAIL, "Failed to verify Trademark text: " + e.getMessage());
	    }
	}

	public void verifyNodalText(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(TermsAndConditions.nodal, ExcelHandler.readData(0, 26, 0));
	        test.log(Status.PASS, "Verified Nodal text successfully.");
	        LoggerHandler.info("Verified Nodal text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify Nodal text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyNodalTextFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify Nodal text");
	        test.log(Status.FAIL, "Failed to verify Nodal text: " + e.getMessage());
	    }
	}
	public void verifyPanCard(ExtentTest test) {
	    try {
	        helper.verifyLocatorText(TermsAndConditions.panCard, ExcelHandler.readData(0, 27, 0));
	        test.log(Status.PASS, "Verified PAN CARD text successfully.");
	        LoggerHandler.info("Verified PAN CARD text successfully.");
	    } catch (Exception e) {
	        LoggerHandler.error("Failed to verify PAN CARD text: " + e.getMessage());
	        String screenshotPath = Reporter.captureScreenshotWithTimeStamp("VerifyPanCardFailure");
	        Reporter.attachScreenshotToReport(screenshotPath, test, "Failed to verify PAN CARD text");
	        test.log(Status.FAIL, "Failed to verify PAN CARD text: " + e.getMessage());
	    }
	}
	



}