package utils;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverHelper {
    WebDriver driver;
    Actions action;

    public WebDriverHelper(WebDriver driver){
        this.driver = driver;
        action = new Actions(driver);
    }

    // Basic Actions
    public void clickOn(By loc){
        driver.findElement(loc).click();
    }

    public void jsClick(By loc){
        WebElement elem = driver.findElement(loc);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", elem);
    }

    public void sendText(By loc, String text){
        driver.findElement(loc).sendKeys(text);
    }

    public void enterKey(By loc){
        driver.findElement(loc).sendKeys(Keys.ENTER);
    }

    public void switchWindow() {
        String parent = driver.getWindowHandle();
        Set<String> allWindowSet = driver.getWindowHandles();
        for (String child : allWindowSet) {
            if (!parent.equalsIgnoreCase(child)) {
                driver.switchTo().window(child);
                break;
            }
        }
    }


    public void switchToParentWindow(){
        String parent = driver.getWindowHandle();
        Set<String> allWindowSet = driver.getWindowHandles();
        for(String child: allWindowSet){
            if(!parent.equalsIgnoreCase(child)){
                driver.switchTo().window(parent);
                break;
            }
        }
    }

    // Frame Handling
    public void switchFrame(By loc){
        WebElement frameElement = driver.findElement(loc);
        driver.switchTo().frame(frameElement);
    }

    // Mouse Actions
    public void hoverOverElement(By loc){
        WebElement elem = driver.findElement(loc);
        action.moveToElement(elem).perform();
    }

    // Dropdown
    public void selectFromDropdown(By locator, String value) {
        WebElement dropdown = driver.findElement(locator);
        dropdown.click();
        dropdown.sendKeys(value);
        dropdown.sendKeys(Keys.ENTER);
    }

    // Scrolling
    public void scrollToElement(By locator) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(locator));
    }

    public void scrollToTop() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, 0)");
    }

    public void scrollByPixel(int pixels) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, " + pixels + ");");
    }

    // Highlighting
    public void highlightElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style', 'border: 2px solid red;');", element);
        try {
            Thread.sleep(1000); // Highlight for 1 second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        js.executeScript("arguments[0].setAttribute('style', '');", element);
    }
    public void scrollIntoView(By loc) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement ele = wait.until(ExpectedConditions.presenceOfElementLocated(loc));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", ele);
        js.executeScript("window.scrollBy(0, -500)"); // Adjust offset if needed

        // Optional: wait until element is clickable
        wait.until(ExpectedConditions.elementToBeClickable(ele));
    }
   public void scrollFooter() {
	   JavascriptExecutor  js =(JavascriptExecutor)driver;
	   js.executeScript("window.scrollTo(0,document.body.scrollHeight);");
   }

    // Waits
    public void waitForElementVisible(By locator) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    // Verifications
    public void verifyTextContains(By locator, String expectedText) {
        String actualText = driver.findElement(locator).getText();
        Assert.assertTrue("Expected text not found: " + expectedText, actualText.contains(expectedText));
    }

    public void verifyPageTitle(String expectedTitle) {
        String actualTitle = driver.getTitle();
        Assert.assertTrue("Expected title not found: " + expectedTitle, actualTitle.contains(expectedTitle));
    }

    public void verifyLinkText(String expectedLinkText) {
        String actualLinkText = driver.getCurrentUrl();
        Assert.assertTrue("Expected link text not found: " + expectedLinkText, actualLinkText.contains(expectedLinkText));
    }

    public void verifyLogoLink(By logoLocator, String expectedHref) {
        WebElement logoLink = driver.findElement(logoLocator);
        String actualHref = logoLink.getAttribute("href");
        Assert.assertTrue("Expected href not found: " + expectedHref, actualHref != null && actualHref.contains(expectedHref));
    }

    public void verifyLocatorText(By locator, String expectedText) {
        String actualText = driver.findElement(locator).getText();
        Assert.assertTrue("Expected text not found: " + expectedText, actualText.contains(expectedText));
    }

    // Utility
    public List<WebElement> getElementsByXPath(String xpath) {
        return driver.findElements(By.xpath(xpath));
    }

    public String getErrorMessage(By locator) {
        return driver.findElement(locator).getText();
    }
    
    
    public boolean verifyLogoDisplayed(By locator) {
        try {
            WebElement element = driver.findElement(locator);
            return element.isDisplayed();
        } catch (Exception e) {
            LoggerHandler.error("verifyLogoDisplayed failed: " + e.getClass().getSimpleName());
            return false;
        }
    }
    public void waitForElementClickable(By locator) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait.until(ExpectedConditions.elementToBeClickable(locator));
    }
}