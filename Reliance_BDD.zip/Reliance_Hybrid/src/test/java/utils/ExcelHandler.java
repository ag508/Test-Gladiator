package utils;
import java.io.FileInputStream;
import utils.LoggerHandler;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelHandler {
    public static String cellValue;
    public static String readData(int sheetNum, int rowNum, int cellNum)
    {
        try{
	        FileInputStream fis = new FileInputStream("./testdata/data.xlsx");
	        XSSFWorkbook wb = new XSSFWorkbook(fis);
	        XSSFSheet sheet = wb.getSheetAt(sheetNum);
	        XSSFRow row = sheet.getRow(rowNum);
	        XSSFCell cell = row.getCell(cellNum);
	        cellValue = cell.getStringCellValue();
	        wb.close();
	        fis.close();
        }
        
        catch(Exception e){
            e.printStackTrace();
            LoggerHandler.error(e.getMessage());
        }        
        return cellValue;
    }
    
    public static void writedata(String filepath, String sheetname, int rownumber, int colnumber, String data,boolean createSheetIfMissing, boolean createRowIfMissing) throws IOException {
    	FileInputStream file = new FileInputStream(filepath);
    	XSSFWorkbook workbook = new XSSFWorkbook(file);
    	try {
    		
        	XSSFSheet sheet = workbook.getSheet(sheetname);
        	 if (sheet == null && createSheetIfMissing) {
        		 sheet = workbook.createSheet(sheetname);
        	 }
        	 XSSFRow row = sheet.getRow(rownumber);        	 
        	 if (row != null) {
        		 XSSFCell cell = row.createCell(colnumber);
        		 cell.setCellValue(data);
        	 }
        	 file.close(); 
        	 FileOutputStream outFile = new FileOutputStream(filepath);
        	 workbook.write(outFile);
        	 outFile.close();
        	 workbook.close();
    	}
    	catch(Exception e) {
    		LoggerHandler.error(e.getMessage());
	       	 file.close(); 
	       	 FileOutputStream outFile = new FileOutputStream(filepath);
	       	 workbook.write(outFile);
	       	 outFile.close();
	       	 workbook.close();
    	}
    }
}