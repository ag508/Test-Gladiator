package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC005L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC005 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC005(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC05(){
        reporter.testReturn("TC005 - Register Negative Test - OTP Invalid");
        helper.clickOn(TC005L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.clickOn(TC005L.Register); Reporter.test.info("Clicked on Register");
        helper.sendText(TC005L.mobileNum, ExcelReader.readData(0, 1, 8)); Reporter.test.info("Entered Mobile Number");
        helper.sendText(TC005L.emailId, ExcelReader.readData(0, 2, 8)); Reporter.test.info("Entered Email ID");
        helper.sendText(TC005L.password, ExcelReader.readData(0, 3, 8)); Reporter.test.info("Entered Password");
        helper.clickOn(TC005L.ContinueBtn); Reporter.test.info("Clicked on Continue Button");
        helper.sendText(TC005L.MobileOTP, ExcelReader.readData(0, 4, 8)); Reporter.test.info("Entered Invalid OTP");
        helper.sendText(TC005L.EmailOTP, ExcelReader.readData(0, 4, 8)); Reporter.test.info("Entered Invalid Email OTP");
        helper.clickOn(TC005L.Continue2Btn); Reporter.test.info("Clicked on Continue Button for OTP");
        helper.waitForElementVisible(TC005L.OTP);
        helper.verifyTextContains(TC005L.OTP, ExcelReader.readData(0, 5, 8)); Reporter.test.pass("Invalid OTP verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC005L.OTP); Reporter.test.info("Highlighted OTP element"); String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC005_OTP_Verification");
        Reporter.test.info("Invalid OTP verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC005_OTP_Verification");
        highlighter.unhighlightElement(TC005L.OTP);
    }    
}
