package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC003L;
import uistore.TC006L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC006 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC006(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC06(){
        reporter.testReturn("TC006 - Register as Guest User (Negative Weak Password Test)");
        helper.clickOn(TC006L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.clickOn(TC006L.Register); Reporter.test.info("Clicked on Register");
        helper.sendText(TC006L.mobileNum, ExcelReader.readData(0, 1, 6)); Reporter.test.info("Entered Mobile Number");
        helper.sendText(TC003L.emailId, ExcelReader.readData(0, 2, 6)); Reporter.test.info("Entered Email ID");
        helper.sendText(TC006L.password, ExcelReader.readData(0, 3, 6)); Reporter.test.info("Entered Weak Password");
        helper.clickOn(TC006L.ContinueBtn); Reporter.test.info("Clicked on Continue Button");
        helper.waitForElementVisible(TC006L.Invalid);
        helper.verifyTextContains(TC006L.Invalid, ExcelReader.readData(0, 4, 6)); Reporter.test.pass("verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC006L.Invalid); Reporter.test.info("Highlighted INVALID element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC006_Verification");
        Reporter.test.info("verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC006_Verification");
        highlighter.unhighlightElement(TC006L.Invalid);

    }
}
