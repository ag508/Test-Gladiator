package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC013L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC013 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC013(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }

    public void TC13() {
        reporter.testReturn("TC013 - Forgot Password Invalid OTP Test");
        helper.clickOn(TC013L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.sendText(TC013L.id, ExcelReader.readData(0, 1, 0)); Reporter.test.info("Entered Login ID");
        helper.clickOn(TC013L.forgotPassword); Reporter.test.info("Clicked on Forgot Password");
        helper.sendText(TC013L.OTP, ExcelReader.readData(0, 1, 14)); Reporter.test.info("Entered OTP");
        helper.sendText(TC013L.NewPassword, ExcelReader.readData(0, 2, 14)); Reporter.test.info("Entered New Password");
        helper.clickOn(TC013L.Submit); Reporter.test.info("Clicked on Submit Button");
        helper.waitForElementVisible(TC013L.Invalid);
        helper.verifyTextContains(TC013L.Invalid, ExcelReader.readData(0, 3, 14)); Reporter.test.pass("Invalid OTP verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC013L.Invalid); Reporter.test.info("Highlighted INVALID element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC013_Verification");
        Reporter.test.info("verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC013_Verification");
        highlighter.unhighlightElement(TC013L.Invalid);
    }
}
