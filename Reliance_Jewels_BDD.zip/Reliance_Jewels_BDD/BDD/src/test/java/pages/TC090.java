package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC090L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC090 {
WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC090(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC90(){
        reporter.testReturn("TC090 - Scroll Footer and Click NACH Cancellation");
        helper.scrollToElement(TC090L.Footer); Reporter.test.info("Scrolled to Footer");
        helper.clickOn(TC090L.NachBtn); Reporter.test.info("Clicked on NACH Cancellation Button");
        helper.sendText(TC090L.GssInput, ExcelReader.readData(0, 1, 9)); Reporter.test.info("Entered GSS Number");
        helper.clickOn(TC090L.GssSubmit); Reporter.test.info("Clicked on Submit Button");
        helper.waitForElementVisible(TC090L.GssMsg);
        helper.verifyTextContains(TC090L.GssMsg, ExcelReader.readData(0, 2, 9)); Reporter.test.pass("GSS Msg validation successful");
        highlighter.highlightElement(TC090L.GssMsg); Reporter.test.info("Highlighted Msg element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC090_Msg_Verification");
        Reporter.test.info("Msg verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC090_Msg_Verification");
        highlighter.unhighlightElement(TC090L.GssMsg);
    }    
}
