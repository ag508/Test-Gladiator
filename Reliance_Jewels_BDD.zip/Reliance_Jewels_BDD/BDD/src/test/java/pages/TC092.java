package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC092L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC092 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC092(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }

    public void TC92() {
        reporter.testReturn("TC092 - Verify Page Title");
        helper.scrollToElement(TC092L.Footer); Reporter.test.info("Scrolled to Footer");
        helper.clickOn(TC092L.Youtube); Reporter.test.info("Clicked on Social Media Button");
        helper.verifyLinkText(ExcelReader.readData(0, 1, 11)); Reporter.test.pass("Verified Link Text");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC092_Social_Media_Verification");
        Reporter.test.info("Social Media verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC092_Social_Media_Verification");
        helper.navigateBack();
        helper.scrollToTop();
        String base64Screenshot1 = Reporter.captureScreenshotAsBase64(driver, "TC092_Back_To_Main_Verification");
        Reporter.test.info("Main Page verification screenshot").addScreenCaptureFromBase64String(base64Screenshot1, "TC092_Back_To_Main_Verification");

    }
        

}
