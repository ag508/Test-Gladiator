package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC001L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC001 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC001(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC01(){
        reporter.testReturn("TC001 - Register as Guest User");
        helper.clickOn(TC001L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.clickOn(TC001L.Register); Reporter.test.info("Clicked on Register");
        helper.sendText(TC001L.mobileNum, ExcelReader.readData(0, 1, 3)); Reporter.test.info("Entered Mobile Number");
        helper.sendText(TC001L.emailId, ExcelReader.readData(0, 2, 2)); Reporter.test.info("Entered Email ID");
        helper.sendText(TC001L.password, ExcelReader.readData(0, 3, 2)); Reporter.test.info("Entered Password");
        helper.clickOn(TC001L.ContinueBtn); Reporter.test.info("Clicked on Continue Button");
        helper.waitForElementVisible(TC001L.OTP);
        helper.verifyTextContains(TC001L.OTP, ExcelReader.readData(0, 4, 2)); Reporter.test.pass("OTP verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC001L.OTP); Reporter.test.info("Highlighted OTP element"); String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC001_OTP_Verification");
        Reporter.test.info("OTP verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC001_OTP_Verification");
        highlighter.unhighlightElement(TC001L.OTP);
    }
}
