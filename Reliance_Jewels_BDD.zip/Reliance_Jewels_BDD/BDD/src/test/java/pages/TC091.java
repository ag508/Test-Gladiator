package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC091L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC091 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC091(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }

    public void TC91() {
        reporter.testReturn("TC091 - Track Order with Invalid Order ID");
        helper.scrollToElement(TC091L.Footer); Reporter.test.info("Scrolled to Footer");
        helper.clickOn(TC091L.TrackBtn); Reporter.test.info("Clicked on Track An Order Button");
        helper.sendText(TC091L.OrderIdInput, ExcelReader.readData(0, 1, 10)); Reporter.test.info("Entered Invalid Order ID");
        helper.clickOn(TC091L.GoBtn); Reporter.test.info("Clicked on Go Button");
        helper.waitForElementVisible(TC091L.InvalidMsg);
        helper.verifyTextContains(TC091L.InvalidMsg, ExcelReader.readData(0, 2, 10)); Reporter.test.pass("Invalid Order ID verification successful");
        highlighter.highlightElement(TC091L.InvalidMsg); Reporter.test.info("Highlighted Invalid Message element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC091_Invalid_OrderID_Verification");
        Reporter.test.info("Invalid Order ID verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC091_Invalid_OrderID_Verification");
        highlighter.unhighlightElement(TC091L.InvalidMsg);
    }
}
