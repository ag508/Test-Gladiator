package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC050L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC050 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC050(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC50() throws InterruptedException {
        reporter.testReturn("TC050 - Anklet Store locator (Positive Test)");
        helper.hoverOverElement(TC050L.Other); Reporter.test.info("Clicked on Other");
        helper.clickOn(TC050L.Anklet); Reporter.test.info("Clicked on Anklet");
        helper.clickOn(TC050L.Anklet_1stProd); Reporter.test.info("Clicked on 1st Anklet Product");
        helper.clickOn(TC050L.LocateStore); Reporter.test.info("Clicked on Locate Store");
        Thread.sleep(1500);
        helper.switchWindow();
        helper.waitForElementVisible(TC050L.StoreInput);
        helper.sendText(TC050L.StoreInput, ExcelReader.readData(0, 1, 7)); Reporter.test.info("Entered Store Name");
        // helper.waitForElementVisible(TC050L.StoreSuggestion);
        helper.enterAction(TC050L.StoreInput); 
        helper.jsClick(TC050L.SearchBtn); Reporter.test.info("Clicked on Search");
        helper.waitForElementVisible(TC050L.StoreName);
        helper.verifyTextContains(TC050L.StoreName, ExcelReader.readData(0, 1, 7)); Reporter.test.pass("Store locator verification successful");
        highlighter.highlightElement(TC050L.StoreName); Reporter.test.info("Highlighted Store Name element");
        helper.scrollToElement(TC050L.StoreName); 
        Thread.sleep(1500);
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC050_Store_Locator_Verification");
        Reporter.test.info("Store locator verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC050_Store_Locator_Verification");
        highlighter.unhighlightElement(TC050L.StoreName);
    }    
}
