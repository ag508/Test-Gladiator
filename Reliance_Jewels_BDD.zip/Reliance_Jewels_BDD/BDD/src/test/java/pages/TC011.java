package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC011L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC011 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC011(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }

    public void TC11() {
        reporter.testReturn("TC011 - Register as Guest User (Negative Invalid Password Test)");
        helper.clickOn(TC011L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.sendText(TC011L.id, ExcelReader.readData(0, 1, 0)); Reporter.test.info("Entered Login ID");
        helper.sendText(TC011L.password, ExcelReader.readData(0, 2, 0)); Reporter.test.info("Entered Password");
        helper.clickOn(TC011L.signIn); Reporter.test.info("Clicked on Sign In Button");
        helper.waitForElementVisible(TC011L.Invalid);
        helper.verifyTextContains(TC011L.Invalid, ExcelReader.readData(0, 1, 13)); Reporter.test.pass("Invalid email verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC011L.Invalid); Reporter.test.info("Highlighted INVALID element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC011_Verification");
        Reporter.test.info("verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC011_Verification");
        highlighter.unhighlightElement(TC011L.Invalid);
    }

}
