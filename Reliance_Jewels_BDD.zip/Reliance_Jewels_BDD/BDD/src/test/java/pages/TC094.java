package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC094L;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC094 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC094(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }

    public void TC94(){
        reporter.testReturn("TC094 - Verify Media Section");
        helper.scrollToElement(TC094L.Footer); Reporter.test.info("Scrolled to Footer");
        helper.clickOn(TC094L.Media); Reporter.test.info("Clicked on Media Button");
        helper.clickOn(TC094L.Yr); Reporter.test.info("Clicked on Year Button");
        helper.clickOn(TC094L.MediaImg); Reporter.test.info("Clicked on Media Image");
        helper.clickOn(TC094L.NextBtn); Reporter.test.info("Clicked on Next Button");
        helper.waitForElementVisible(TC094L.MediaImg_1st);
        highlighter.highlightElement(TC094L.MediaImg_1st); Reporter.test.info("Highlighted Media Title element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC094__Media_Verification");
        Reporter.test.info("Media verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC094_Media_Verification");
        highlighter.unhighlightElement(TC094L.MediaImg_1st);
        helper.clickOn(TC094L.PreviousBtn); Reporter.test.info("Clicked on Previous Button");
        helper.waitForElementVisible(TC094L.MediaImg_2nd);
        highlighter.highlightElement(TC094L.MediaImg_2nd); Reporter.test.info("Highlighted Media Image element");
        String base64Screenshot1 = Reporter.captureScreenshotAsBase64(driver, "TC094_Main_Verification");
        Reporter.test.info("Media verification screenshot").addScreenCaptureFromBase64String(base64Screenshot1, "TC094_Main_Verification");
        highlighter.unhighlightElement(TC094L.MediaImg_2nd);
    }
}
