package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC002L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC002 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC002(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC02(){
        reporter.testReturn("TC002 - Register as Guest User (Negative Test)");
        helper.clickOn(TC002L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.clickOn(TC002L.Register); Reporter.test.info("Clicked on Register");
        helper.sendText(TC002L.mobileNum, ExcelReader.readData(0, 1, 3)); Reporter.test.info("Entered Mobile Number");
        helper.sendText(TC002L.emailId, ExcelReader.readData(0, 2, 3)); Reporter.test.info("Entered Incorrect Email ID");
        helper.sendText(TC002L.password, ExcelReader.readData(0, 3, 3)); Reporter.test.info("Entered Password");
        helper.clickOn(TC002L.ContinueBtn); Reporter.test.info("Clicked on Continue Button");
        helper.waitForElementVisible(TC002L.Invalid);
        helper.verifyTextContains(TC002L.Invalid, ExcelReader.readData(0, 4, 3)); Reporter.test.pass("verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC002L.Invalid); Reporter.test.info("Highlighted INVALID element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC002_Verification");
        Reporter.test.info("verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC002_Verification");
        highlighter.unhighlightElement(TC002L.Invalid);

    }
}
