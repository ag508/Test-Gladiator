package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC003L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC003 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC003(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC03(){
        reporter.testReturn("TC003 - Register as Guest User (Negative Mob Number Test)");
        helper.clickOn(TC003L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.clickOn(TC003L.Register); Reporter.test.info("Clicked on Register");
        helper.sendText(TC003L.mobileNum, ExcelReader.readData(0, 1, 4)); Reporter.test.info("Entered Incorrect Mobile Number");
        helper.sendText(TC003L.emailId, ExcelReader.readData(0, 2, 4)); Reporter.test.info("Entered Email ID");
        helper.sendText(TC003L.password, ExcelReader.readData(0, 3, 4)); Reporter.test.info("Entered Password");
        helper.clickOn(TC003L.ContinueBtn); Reporter.test.info("Clicked on Continue Button");
        helper.waitForElementVisible(TC003L.Invalid);
        helper.verifyTextContains(TC003L.Invalid, ExcelReader.readData(0, 4, 4)); Reporter.test.pass("verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC003L.Invalid); Reporter.test.info("Highlighted INVALID element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC003_Verification");
        Reporter.test.info("verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC003_Verification");
        highlighter.unhighlightElement(TC003L.Invalid);

    }
}
