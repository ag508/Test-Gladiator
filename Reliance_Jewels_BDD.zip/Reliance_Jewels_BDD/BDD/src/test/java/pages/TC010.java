package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC010L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC010 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC010(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }

    public void TC10(){
        reporter.testReturn("TC010 - Register as Guest User (Negative Invalid Email Test)");
        helper.clickOn(TC010L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.sendText(TC010L.id, ExcelReader.readData(0, 2, 3)); Reporter.test.info("Entered Login ID");
        helper.sendText(TC010L.password, ExcelReader.readData(0, 1, 1)); Reporter.test.info("Entered Password");
        helper.clickOn(TC010L.signIn); Reporter.test.info("Clicked on Sign In Button");
        helper.waitForElementVisible(TC010L.Invalid);
        helper.verifyTextContains(TC010L.Invalid, ExcelReader.readData(0, 1, 12)); Reporter.test.pass("Invalid email verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC010L.Invalid); Reporter.test.info("Highlighted INVALID element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC010_Verification");
        Reporter.test.info("verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC010_Verification");
        highlighter.unhighlightElement(TC010L.Invalid);
    }
}
