package pages;

import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import uistore.TC077L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC077 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC077(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }

    public void TC77() {
        reporter.testReturn("TC077 - Verify Poompuhar Product Page");
        helper.hoverOverElement(TC077L.WhatDropdown); Reporter.test.info("Clicked on What's Trending dropdown");
        helper.clickOn(TC077L.Thanjavur); Reporter.test.info("Selected Thanjavur option");
        helper.scrollToElement(TC077L.POOMPUHAR); Reporter.test.info("Scrolled down to Poompuhar");
        Reporter.test.info("Highlighted Poompuhar element");
        helper.scrollToElement(TC077L.exploreBtn);
        helper.jsClick(TC077L.exploreBtn); Reporter.test.info("Clicked Explore Now button");
        helper.verifyUrlContains(ExcelReader.readData(0, 1, 15)); Reporter.test.pass("Verified Poompuhar from URL");
        helper.clickOn(TC077L.FirstProduct); Reporter.test.info("Clicked on the first product");
        helper.waitForElementVisible(TC077L.verifyProduct);
        helper.verifyTextContains(TC077L.verifyProduct, ExcelReader.readData(0, 2, 15)); Reporter.test.pass("Verified Poompuhar in product page");
        highlighter.highlightElement(TC077L.verifyProduct); Reporter.test.info("Highlighted product verification element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC077_Product_Verification");
        Reporter.test.info("Product verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC077_Product_Verification");
        highlighter.unhighlightElement(TC077L.verifyProduct);
    }
}
