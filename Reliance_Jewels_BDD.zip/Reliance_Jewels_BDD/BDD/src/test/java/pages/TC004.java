package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC004L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC004 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC004(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC04(){
        reporter.testReturn("TC004 - Register as Guest User (Negative No Email Test)");
        helper.clickOn(TC004L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.clickOn(TC004L.Register); Reporter.test.info("Clicked on Register");
        helper.sendText(TC004L.mobileNum, ExcelReader.readData(0, 1, 5)); Reporter.test.info("Entered Mobile Number");
        Reporter.test.info("Entered  No Email ID");
        helper.sendText(TC004L.password, ExcelReader.readData(0, 3, 5)); Reporter.test.info("Entered Password");
        helper.clickOn(TC004L.ContinueBtn); Reporter.test.info("Clicked on Continue Button");
        helper.waitForElementVisible(TC004L.Invalid);
        helper.verifyTextContains(TC004L.Invalid, ExcelReader.readData(0, 4, 5)); Reporter.test.pass("verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC004L.Invalid); Reporter.test.info("Highlighted INVALID element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC004_Verification");
        Reporter.test.info("verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC004_Verification");
        highlighter.unhighlightElement(TC004L.Invalid);

    }
}
