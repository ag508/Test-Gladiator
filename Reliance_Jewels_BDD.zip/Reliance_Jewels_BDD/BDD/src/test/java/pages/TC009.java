package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import uistore.TC009L;
import utils.ExcelReader;
import utils.HighLightActionUtil;
import utils.Reporter;
import utils.Screenshot;
import utils.WebDriverHelper;

public class TC009 {
    WebDriver driver;
    WebDriverHelper helper;
    Reporter reporter = new Reporter();
    ExtentTest test;
    HighLightActionUtil highlighter;
    Screenshot screenshot;

    public TC009(WebDriver driver) {
        this.driver = driver;
        this.helper = new WebDriverHelper(driver);
        this.highlighter = new HighLightActionUtil(driver);
        this.screenshot = new Screenshot(driver);
    }
    
    public void TC09(){
        reporter.testReturn("TC009 - Login as Guest User");
        helper.clickOn(TC009L.Guest); Reporter.test.info("Clicked on Guest User");
        helper.sendText(TC009L.id, ExcelReader.readData(0, 1, 0)); Reporter.test.info("Entered Login ID");
        helper.sendText(TC009L.password, ExcelReader.readData(0, 1, 1)); Reporter.test.info("Entered Password");
        helper.clickOn(TC009L.signIn); Reporter.test.info("Clicked on Sign In Button");
        helper.waitForElementVisible(TC009L.LoginName);
        helper.verifyTextContains(TC009L.LoginName, ExcelReader.readData(0, 2, 0)); Reporter.test.pass("Login verification successful");
        helper.scrollToTop();
        highlighter.highlightElement(TC009L.LoginName); Reporter.test.info("Highlighted Login Name element");
        String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "TC009_Login_Verification");
        Reporter.test.info("Login verification screenshot").addScreenCaptureFromBase64String(base64Screenshot, "TC009_Login_Verification");
        highlighter.unhighlightElement(TC009L.LoginName);
    }
}
