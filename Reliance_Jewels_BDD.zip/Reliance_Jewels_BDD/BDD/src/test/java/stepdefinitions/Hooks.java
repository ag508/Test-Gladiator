package stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import utils.Base;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;

public class Hooks extends Base {
    private static boolean isReporterInitialized = false;

    @Before
    public void setup(Scenario scenario) {
        try {
            if (!isReporterInitialized) {
                LoggerHandler.info("Test Suite execution started");
                Reporter.generateReport();
                isReporterInitialized = true;
            }
            LoggerHandler.info("Starting scenario: " + scenario.getName());
            openBrowser();
        } catch (Exception e) {
            LoggerHandler.error("Failed to setup scenario: " + e.getMessage());
            throw e;
        }
    }

    @After
    public void tearDown(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                LoggerHandler.error("Scenario failed: " + scenario.getName());
                String screenshotPath = new Screenshot(driver).captureFailureScreenshot(scenario.getName());
                Reporter.test.fail("Test failed. Screenshot: " + screenshotPath);
            }
            
            if (driver != null) {
                driver.quit();
                LoggerHandler.info("Browser closed successfully");
            }
        } catch (Exception e) {
            LoggerHandler.error("Failed to tear down scenario: " + e.getMessage());
        }
    }
} 