package stepdefinitions;

import io.cucumber.java.en.*;
import pages.*;
import utils.*;

public class TC009_TC010_TC011_TC013_LoginSteps extends Base {
    private TC009 tc009;
    private TC010 tc010;
    private TC011 tc011;
    private TC013 tc013;

    // TC009 - Positive Login
    @When("I enter login ID {string}")
    public void i_enter_login_id(String id) {
        tc009 = new TC009(driver);
        tc009.TC09();
    }

    // TC010 - Invalid Email Login
    @When("I enter invalid login ID {string}")
    public void i_enter_invalid_login_id(String id) {
        tc010 = new TC010(driver);
        tc010.TC10();
    }

    // TC011 - Invalid Password Login
    @When("I enter invalid login password {string}")
    public void i_enter_invalid_login_password(String password) {
        tc011 = new TC011(driver);
        tc011.TC11();
    }

    // TC013 - Forgot Password Invalid OTP
    @When("I click Forgot Password")
    public void i_click_forgot_password() {
        tc013 = new TC013(driver);
        tc013.TC13();
    }
} 