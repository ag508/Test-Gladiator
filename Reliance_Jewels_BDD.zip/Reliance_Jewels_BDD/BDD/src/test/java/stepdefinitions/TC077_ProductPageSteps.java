package stepdefinitions;

import io.cucumber.java.en.*;
import pages.*;
import utils.*;

public class TC077_ProductPageSteps extends Base {
    private TC077 tc077;

    @When("I verify Poompuhar product")
    public void i_verify_poompuhar_product() {
        tc077 = new TC077(driver);
        tc077.TC77();
    }
} 