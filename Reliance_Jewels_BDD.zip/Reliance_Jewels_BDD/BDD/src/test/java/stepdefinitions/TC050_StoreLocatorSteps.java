package stepdefinitions;

import io.cucumber.java.en.*;
import pages.*;
import utils.*;

public class TC050_StoreLocatorSteps extends Base {
    private TC050 tc050;

    @When("I search for Anklet store")
    public void i_search_for_anklet_store() throws InterruptedException {
        tc050 = new TC050(driver);
        tc050.TC50();
    }
} 