package stepdefinitions;

import io.cucumber.java.en.*;
import pages.*;
import utils.*;

public class TC090_TC091_TC092_TC094_FooterSteps extends Base {
    private TC090 tc090;
    private TC091 tc091;
    private TC092 tc092;
    private TC094 tc094;

    // TC090 - NACH Cancellation
    @When("I verify NACH cancellation")
    public void i_verify_nach_cancellation() {
        tc090 = new TC090(driver);
        tc090.TC90();
    }

    // TC091 - Track Order
    @When("I verify invalid order tracking")
    public void i_verify_invalid_order_tracking() {
        tc091 = new TC091(driver);
        tc091.TC91();
    }

    // TC092 - Social Media Links
    @When("I verify social media links")
    public void i_verify_social_media_links() {
        tc092 = new TC092(driver);
        tc092.TC92();
    }

    // TC094 - Media Section
    @When("I verify media section")
    public void i_verify_media_section() {
        tc094 = new TC094(driver);
        tc094.TC94();
    }
} 