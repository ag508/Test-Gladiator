package stepdefinitions;

import io.cucumber.java.en.*;
import utils.Base;

public class CommonSteps extends Base {
    @Given("I am on the Reliance Jewels homepage")
    public void i_am_on_the_reliance_jewels_homepage() {
        // Base class handles browser initialization
    }
} 