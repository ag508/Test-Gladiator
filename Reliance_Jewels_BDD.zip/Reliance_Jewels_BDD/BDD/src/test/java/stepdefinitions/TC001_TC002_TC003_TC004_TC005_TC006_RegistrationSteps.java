package stepdefinitions;

import io.cucumber.java.en.*;
import pages.*;
import utils.*;

public class TC001_TC002_TC003_TC004_TC005_TC006_RegistrationSteps extends Base {
    private TC001 tc001;
    private TC002 tc002;
    private TC003 tc003;
    private TC004 tc004;
    private TC005 tc005;
    private TC006 tc006;

    // TC001 - Positive Registration
    @When("I click on Guest User")
    public void i_click_on_guest_user() {
        tc001 = new TC001(driver);
        tc001.TC01();
    }

    // TC002 - Invalid Email
    @When("I enter invalid email {string}")
    public void i_enter_invalid_email(String email) {
        tc002 = new TC002(driver);
        tc002.TC02();
    }

    // TC003 - Invalid Mobile
    @When("I enter invalid mobile number {string}")
    public void i_enter_invalid_mobile_number(String mobile) {
        tc003 = new TC003(driver);
        tc003.TC03();
    }

    // TC004 - Missing Email
    @When("I enter no email")
    public void i_enter_no_email() {
        tc004 = new TC004(driver);
        tc004.TC04();
    }

    // TC005 - Invalid OTP
    @When("I enter invalid mobile OTP {string}")
    public void i_enter_invalid_mobile_otp(String otp) {
        tc005 = new TC005(driver);
        tc005.TC05();
    }

    // TC006 - Weak Password
    @When("I enter weak password {string}")
    public void i_enter_weak_password(String password) {
        tc006 = new TC006(driver);
        tc006.TC06();
    }
} 