package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import utils.*;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features",
    glue = {"stepdefinitions"},
    plugin = {
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
        "pretty",
        "html:reports/cucumber-reports.html",
        "json:reports/cucumber-reports.json",
        "junit:reports/cucumber-reports.xml"
    },
    monochrome = true,
    publish = true
)
public class TestRunner {
    private static final int TOTAL_TESTS = 16;
    private static ProgressBarUtil progressBar;

    static {
        try {
            LoggerHandler.info("Test Suite execution started");
            Reporter.generateReport();
            progressBar = new ProgressBarUtil("Automation Test Progress", TOTAL_TESTS);
            progressBar.start("Starting test execution...");
        } catch (Exception e) {
            LoggerHandler.error("Failed to initialize test suite: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public static void incrementProgress(String testName) {
        if (progressBar != null) {
            progressBar.incrementProgress(testName);
        }
    }

    @AfterClass
    public static void completeProgress() {
        if (progressBar != null) {
            progressBar.complete("All tests finished.");
            progressBar.close();
        }
        Reporter.flushReport();
    }
}
