package utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
    private final WebDriver driver;
    
    public Screenshot(WebDriver driver) {
        this.driver = driver;
    }

    public String captureScreenshot(String testName, boolean isFailure) {
        try {
            String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            String fileName = testName + "_" + timestamp + ".png";
            String directory = isFailure ? PropertiesReader.errorScreenshotPath : PropertiesReader.screenshotPath;
            
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destinationPath = new File(directory + fileName);
            
            // Create directory if it doesn't exist
            File parent = destinationPath.getParentFile();
            if (!parent.exists()) {
                parent.mkdirs();
            }
            
            FileUtils.copyFile(screenshot, destinationPath);
            LoggerHandler.info("Screenshot captured: " + destinationPath.getAbsolutePath());
            return destinationPath.getAbsolutePath();
            
        } catch (IOException e) {
            LoggerHandler.error("Failed to capture screenshot: " + e.getMessage());
            return null;
        }
    }

    public String captureFailureScreenshot(String testName) {
        return captureScreenshot(testName, true);
    }

    public String captureScreenshotAsBase64() {
        try {
            return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
        } catch (Exception e) {
            LoggerHandler.error("Failed to capture base64 screenshot: " + e.getMessage());
            return null;
        }
    }
}
