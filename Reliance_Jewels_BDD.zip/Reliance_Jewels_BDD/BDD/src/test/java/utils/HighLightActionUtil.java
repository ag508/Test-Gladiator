package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;


public class HighLightActionUtil {
	public WebDriver driver;
	
	public HighLightActionUtil(WebDriver driver) {
		this.driver = driver;
		}
	
    public void highlightElement(By locator) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style', 'border: 2px solid blue;');", driver.findElement(locator));
    }

    public void unhighlightElement(By locator) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style', '');", driver.findElement(locator));
    }
}
