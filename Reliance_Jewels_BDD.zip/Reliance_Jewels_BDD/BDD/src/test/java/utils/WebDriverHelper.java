package utils;
import java.time.Duration;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.junit.Assert.assertTrue;

public class WebDriverHelper {
    WebDriver driver;
    Actions action;

    public WebDriverHelper(WebDriver driver){
        this.driver = driver;
        action = new Actions(driver);
    }

    public void clickOn(By loc){
        driver.findElement(loc).click();
    }

    public void jsClick(By loc){
        WebElement elem = driver.findElement(loc);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", elem);
    }

    public void sendText(By loc, String text){
        driver.findElement(loc).sendKeys(text);
    }

    public void switchWindow(){
        String parent = driver.getWindowHandle();
        Set<String> allWindowSet = driver.getWindowHandles();
        for(String child: allWindowSet){
            if(!parent.equalsIgnoreCase(child)){
                driver.switchTo().window(child);
                break;
            }
        }
    }

    public void switchToParentWindow(){
        String parent = driver.getWindowHandle();
        Set<String> allWindowSet = driver.getWindowHandles();
        for(String child: allWindowSet){
            if(!parent.equalsIgnoreCase(child)){
                driver.switchTo().window(parent);
                break;
            }
        }
    }

    public void switchFrame(By loc){
        WebElement frameElement = driver.findElement(loc);
        driver.switchTo().frame(frameElement);
    }

    public void hoverOverElement(By loc){
        WebElement elem = driver.findElement(loc);
        action.moveToElement(elem).perform();
    }

    public void enterKey(By loc){
        driver.findElement(loc).sendKeys(Keys.ENTER);
    }
    
    public void enterAction(By locator) {
        driver.findElement(locator).sendKeys(Keys.ENTER);
    }

    public void selectFromDropdown(By locator, String value) {
        WebElement dropdown = driver.findElement(locator);
        dropdown.click();
        dropdown.sendKeys(value);
        dropdown.sendKeys(Keys.ENTER);
    }
    
    public void scrollToElement(By locator) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(locator));
    }

    public void scrollToTop() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, 0)");
    }
    
    public void scrollByPixel(int pixels) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, " + pixels + ");");
    }

    public void verifyTextContains(By locator, String expectedText) {
        String actualText = driver.findElement(locator).getText();
        System.out.println(actualText);
        System.out.println(expectedText);
        assertTrue("Expected text not found: " + expectedText, actualText.contains(expectedText));
    }

    public void verifyPageTitle(String expectedTitle) {
        String actualTitle = driver.getTitle();
        System.out.println(actualTitle);
        System.out.println(expectedTitle);
        assertTrue("Expected title not found: " + expectedTitle, actualTitle.contains(expectedTitle));
    }

    public void waitForElementVisible(By locator) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public void verifyUrlContains(String expectedUrlPart) {
        String currentUrl = driver.getCurrentUrl();
        System.out.println("Current URL: " + currentUrl);
        System.out.println("Expected URL part: " + expectedUrlPart);
        assertTrue("Expected URL part not found: " + expectedUrlPart, currentUrl.contains(expectedUrlPart));
    }

    public List<WebElement> getElementsByXPath(String xpath) {
        return driver.findElements(By.xpath(xpath));
    }

    public void verifyLinkText(String expectedLinkText) {
        String actualLinkText = driver.getCurrentUrl();
        System.out.println(actualLinkText);
        System.out.println(expectedLinkText);
        assertTrue("Expected link text not found: " + expectedLinkText, actualLinkText.contains(expectedLinkText));
    }

    public void verifyLogoLink(By logoLocator, String expectedHref) {
        WebElement logoLink = driver.findElement(logoLocator);
        String actualHref = logoLink.getAttribute("href");
        System.out.println("Actual href: " + actualHref);
        System.out.println("Expected href: " + expectedHref);
        assertTrue("Expected href not found: " + expectedHref, actualHref != null && actualHref.contains(expectedHref));
    }

    public void verifyLocatorText(By locator, String expectedText) {
        String actualText = driver.findElement(locator).getText();
        System.out.println(actualText);
        System.out.println(expectedText);
        assertTrue("Expected text not found: " + expectedText, actualText.contains(expectedText));
    }

    public void navigateBack() {
        driver.navigate().back();
    }
}
