package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesReader {
    private static Properties properties;
    public static String browserName;
    public static String baseUrl;
    public static String reportPath;
    public static String screenshotPath = "screenshots/";
    public static String errorScreenshotPath = "reports/errorScreenshots/";

    static {
        try {
            properties = new Properties();
            FileInputStream file = new FileInputStream("config/browser.properties");
            properties.load(file);
            
            browserName = properties.getProperty("browser", "chrome");
            baseUrl = properties.getProperty("baseUrl", "https://www.reliancejewels.com");
            reportPath = properties.getProperty("reportPath", "reports/execution-report.html");
            
            file.close();
        } catch (IOException e) {
            LoggerHandler.error("Failed to load properties file: " + e.getMessage());
            throw new RuntimeException("Failed to load properties file", e);
        }
    }

    public static String getProperty(String key) {
        return properties.getProperty(key);
    }
}
