package uistore;

import org.openqa.selenium.By;

public class TC010L {
    public static final By Guest = By.id("signInHeaderLink");
    public static final By id = By.id("loginId");
    public static final By password = By.id("password");
    public static final By signIn = By.id("signin");
    public static final By Invalid = By.xpath("//h4[text()='Please Enter valid email id ']");
}
