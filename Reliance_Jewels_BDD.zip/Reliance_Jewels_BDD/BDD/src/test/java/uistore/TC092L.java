package uistore;

import org.openqa.selenium.By;

public class TC092L {
    public static final By Footer = By.className("copyright-bar");
    public static final By Youtube = By.xpath("//a[@title='Youtube']");
}
