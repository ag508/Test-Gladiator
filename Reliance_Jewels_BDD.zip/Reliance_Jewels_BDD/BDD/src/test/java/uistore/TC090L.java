package uistore;

import org.openqa.selenium.By;

public class TC090L {
    public static final By Footer = By.className("copyright-bar");
    public static final By NachBtn = By.xpath("//a[text()='NACH CANCELLATION']");
    public static final By GssInput = By.id("gssnumber");
    public static final By GssSubmit = By.id("submit");
    public static final By GssMsg = By.id("msg_gssnumber");
}
