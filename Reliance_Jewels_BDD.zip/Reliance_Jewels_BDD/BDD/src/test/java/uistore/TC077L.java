package uistore;

import org.openqa.selenium.By;

public class TC077L {
    public static By WhatDropdown = By.xpath("//a[contains(text(), 'What')]");
    public static By Thanjavur = By.xpath("//a[contains(text(), 'Thanjavur')]");
    public static By POOMPUHAR = By.xpath("//h1[contains(text(), 'POOMPUHAR')]");
    public static By exploreBtn = By.xpath("//a[contains(@href, 'poombuhar')]");
    public static By FirstProduct  = By.xpath("//a[contains(@class, 'tooltip_18')]");
    public static By verifyProduct = By.xpath("//li[contains(text(), 'Poompuhar Collection')]");
}


