package uistore;

import org.openqa.selenium.By;

public class TC091L {
    public static final By Footer = By.className("copyright-bar");
    public static final By TrackBtn = By.xpath("//a[text()='Track An Order']");
    public static final By OrderIdInput = By.id("orderId");
    public static final By GoBtn = By.id("btnBuyNow");
    public static final By InvalidMsg = By.xpath("//h5[contains(text(), 'Order number')]");
}
