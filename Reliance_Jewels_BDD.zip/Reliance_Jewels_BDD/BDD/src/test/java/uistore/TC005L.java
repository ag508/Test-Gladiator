package uistore;

import org.openqa.selenium.By;

public class TC005L {
    public static final By Guest = By.xpath("//*[@id='signInHeaderLink']");
    public static final By Register = By.className("anchor_sign_up");
    public static final By mobileNum = By.id("mobileNumber");
    public static final By emailId = By.id("emailId");
    public static final By password = By.id("newpassword");
    public static final By ContinueBtn = By.id("signUpCont");
    public static final By MobileOTP = By.id("otp");
    public static final By EmailOTP = By.id("emailOtp");
    public static final By Continue2Btn = By.id("signup");
    public static final By OTP = By.xpath("//h5[contains(text(), 'Incorrect one time password.')]");
}
