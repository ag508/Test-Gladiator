package uistore;

import org.openqa.selenium.By;

public class TC094L {
    public static final By Footer = By.className("copyright-bar");
    public static final By Media = By.xpath("//a[text()='Media']");
    public static final By Yr = By.xpath("//a[text()='2022']");
    public static final By MediaImg = By.xpath("//a[@data-fancybox='grpup1']");
    public static final By NextBtn = By.xpath("//button[@title='Next']");
    public static final By MediaImg_1st = By.xpath("//div[@class='fancybox-placeholder'][1]");
    public static final By PreviousBtn = By.xpath("//button[@title='Previous']");
    public static final By MediaImg_2nd = By.xpath("//div[@class='fancybox-placeholder']");

}
