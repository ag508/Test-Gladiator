package uistore;

import org.openqa.selenium.By;

public class TC009L {
    public static final By Guest = By.id("signInHeaderLink");
    public static final By id = By.id("loginId");
    public static final By password = By.id("password");
    public static final By signIn = By.id("signin");
    public static final By LoginName = By.id("signInHeaderLink");
}
