package uistore;

import org.openqa.selenium.By;

public class TC013L {
    public static final By Guest = By.id("signInHeaderLink");
    public static final By id = By.id("loginId");
    public static final By forgotPassword = By.id("forgotPwd");
    public static final By OTP = By.id("otp");
    public static final By NewPassword = By.id("newpassword");
    public static final By Submit = By.id("forgot-pwd-submit");
    public static final By Invalid = By.xpath("//h5[contains(text(), 'Incorrect one time password.')]");
}
