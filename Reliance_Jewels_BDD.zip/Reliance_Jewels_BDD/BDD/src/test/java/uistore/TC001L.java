package uistore;

import org.openqa.selenium.By;

public class TC001L {
    public static final By Guest = By.xpath("//*[@id='signInHeaderLink']");
    public static final By Register = By.className("anchor_sign_up");
    public static final By mobileNum = By.id("mobileNumber");
    public static final By emailId = By.id("emailId");
    public static final By password = By.id("newpassword");
    public static final By ContinueBtn = By.id("signUpCont");
    public static final By OTP = By.id("otpMsg");
}
