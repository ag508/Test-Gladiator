package uistore;

import org.openqa.selenium.By;

public class TC050L {
    public static final By Other = By.xpath("//a[text()='Other']");
    public static final By Anklet = By.xpath("//a[text()='Anklets']");
    public static final By Anklet_1stProd = By.xpath("//p[contains(@class, 'product_title')]");
    public static final By LocateStore = By.id("btnInStore");
    public static final By StoreInput = By.id("OutletSearch");
    public static final By StoreSuggestion = By.xpath("//li[contains(text(), 'Bhubaneswar')]");
    public static final By SearchBtn = By.xpath("//span[contains(text(), 'Search')]");
    public static final By StoreName = By.xpath("//span[contains(text(), 'Bhubaneswar')]");
}
